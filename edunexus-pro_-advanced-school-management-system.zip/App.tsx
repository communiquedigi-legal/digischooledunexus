
import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import StudentManagement from './components/StudentManagement';
import AttendanceManagement from './components/AttendanceManagement';
import LibraryManagement from './components/LibraryManagement';
import HRManagement from './components/HRManagement';
import NoticeBoard from './components/NoticeBoard';
import AcademicManagement from './components/AcademicManagement';
import TransportManagement from './components/TransportManagement';
import ExamsManagement from './components/ExamsManagement';
import FeesManagement from './components/FeesManagement';
import PhilanthropyHub from './components/PhilanthropyHub';
import CertificateManagement from './components/CertificateManagement';
import AlumniManagement from './components/AlumniManagement';
import SettingsManagement from './components/SettingsManagement';
import FinanceHub from './components/FinanceHub';
import CommunicationHub from './components/CommunicationHub';
import AcademicCalendar from './components/AcademicCalendar';
import TeacherPanel from './components/TeacherPanel';
import ParentPanel from './components/ParentPanel';
import PrincipalPanel from './components/PrincipalPanel';
import SecurityVault from './components/SecurityVault';
import { Search, Bell, Settings, LogOut, CalendarDays, ChevronDown, Sparkles, Shield, User, GraduationCap, Users2, Building, Menu, X, Key, Info, Lock, Fingerprint, ArrowRight, AlertCircle, Cpu } from 'lucide-react';
import { AcademicSession, UserRole } from './types';
import { supabase } from './lib/supabase';

const SESSIONS: AcademicSession[] = [
  { id: '2526', label: '2025-26 (Current)', startDate: '2025-04-01', endDate: '2026-03-15', isActive: true, status: 'Academic' },
  { id: '2627', label: '2026-27 (Upcoming)', startDate: '2026-04-01', endDate: '2027-03-15', isActive: false, status: 'Admission' },
  { id: '2425', label: '2024-25 (Archive)', startDate: '2024-04-01', endDate: '2025-03-15', isActive: false, status: 'Closing' },
];

const App: React.FC = () => {
  const [userRole, setUserRole] = useState<UserRole | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [currentSession, setCurrentSession] = useState(SESSIONS[0]);
  const [showSessionMenu, setShowSessionMenu] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Login Form States
  const [loginId, setLoginId] = useState('');
  const [loginPass, setLoginPass] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setIsLoggingIn(true);

    try {
      const { data, error } = await supabase
        .from('credentials')
        .select('*')
        .ilike('uid', loginId)
        .eq('password', loginPass)
        .single();

      if (error || !data) {
        setLoginError('Invalid Institutional UID or Access Key. Verification failed.');
      } else {
        const role = data.role as UserRole;
        setUserRole(role);
        if (role === UserRole.TEACHER) setActiveTab('teacher_panel');
        else if (role === UserRole.PARENT) setActiveTab('parent_panel');
        else setActiveTab('dashboard');
      }
    } catch (err) {
      setLoginError('Database connection error. Please try again.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  if (!userRole) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col relative overflow-hidden">
        {/* Decorative Background Elements */}
        <div className="absolute top-0 right-0 w-full md:w-[800px] h-[800px] bg-indigo-500/10 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/4 -z-0"></div>
        <div className="absolute bottom-0 left-0 w-full md:w-[600px] h-[600px] bg-rose-500/10 rounded-full blur-[120px] translate-y-1/2 -translate-x-1/4 -z-0"></div>
        
        {/* Main Login Content */}
        <div className="flex-1 flex items-center justify-center p-4 md:p-8 z-10">
          <div className="max-w-6xl w-full grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center py-10">
            <div className="space-y-6 md:space-y-10 text-center lg:text-left">
              <div className="flex items-center justify-center lg:justify-start gap-4">
                <div className="w-12 h-12 md:w-16 md:h-16 bg-indigo-600 rounded-2xl md:rounded-3xl flex items-center justify-center text-white shadow-2xl shadow-indigo-500/30 font-black text-2xl md:text-3xl italic">E</div>
                <h1 className="text-2xl md:text-4xl font-black text-white tracking-tighter uppercase italic">EduNexus Pro</h1>
              </div>
              <h2 className="text-4xl md:text-7xl font-black text-white leading-none tracking-tight">Institutional <span className="text-indigo-400">Gateway</span></h2>
              <p className="text-slate-400 text-base md:text-xl leading-relaxed font-medium max-w-lg mx-auto lg:mx-0">Universal access protocol for all school stakeholders. Please provide your digital identity credentials to enter the ecosystem.</p>
              
              <div className="p-6 md:p-8 bg-white/5 border border-white/10 rounded-[2rem] md:rounded-[3rem] backdrop-blur-xl text-left hidden lg:block">
                 <p className="text-slate-400 text-xs md:text-sm font-medium leading-relaxed flex items-start gap-3">
                   <Info size={16} className="text-indigo-400 shrink-0 mt-0.5" />
                   Unauthorized access is strictly prohibited. Identity verification and session logging are active on this node.
                 </p>
              </div>
            </div>

            <div className="flex justify-center lg:justify-end">
              <div className="w-full max-w-[450px] bg-white/5 border border-white/10 p-8 md:p-12 rounded-[3rem] backdrop-blur-2xl shadow-2xl relative overflow-hidden">
                 <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
                 
                 <form onSubmit={handleLogin} className="space-y-8 relative z-10">
                    <div className="text-center lg:text-left mb-4">
                      <h3 className="text-2xl font-black text-white uppercase italic tracking-tighter">Sign In</h3>
                      <p className="text-slate-500 text-xs font-bold uppercase tracking-widest mt-1">Authorized Access Only</p>
                    </div>

                    {loginError && (
                      <div className="p-4 bg-rose-500/10 border border-rose-500/20 rounded-2xl flex items-start gap-3 animate-in fade-in slide-in-from-top-2">
                         <AlertCircle size={18} className="text-rose-500 shrink-0 mt-0.5"/>
                         <p className="text-[11px] font-bold text-rose-200 leading-relaxed uppercase tracking-tight">{loginError}</p>
                      </div>
                    )}

                    <div className="space-y-6">
                      <div className="space-y-2">
                         <label className="text-[10px] font-black text-indigo-300 uppercase px-4 tracking-[0.2em]">Institutional ID</label>
                         <div className="relative group">
                            <Fingerprint className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-indigo-400 transition-colors" size={20} />
                            <input 
                              required
                              value={loginId}
                              onChange={(e) => setLoginId(e.target.value)}
                              placeholder="e.g. ADMIN01, S1001" 
                              className="w-full pl-14 pr-6 py-4 bg-white/5 border border-white/10 rounded-2xl font-black text-white outline-none focus:bg-white/10 focus:border-indigo-500 transition-all placeholder:text-slate-700" 
                            />
                         </div>
                      </div>

                      <div className="space-y-2">
                         <label className="text-[10px] font-black text-indigo-300 uppercase px-4 tracking-[0.2em]">Access Key</label>
                         <div className="relative group">
                            <Lock className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-emerald-400 transition-colors" size={20} />
                            <input 
                              required
                              type="password"
                              value={loginPass}
                              onChange={(e) => setLoginPass(e.target.value)}
                              placeholder="••••••••" 
                              className="w-full pl-14 pr-6 py-4 bg-white/5 border border-white/10 rounded-2xl font-black text-white outline-none focus:bg-white/10 focus:border-emerald-500 transition-all placeholder:text-slate-700" 
                            />
                         </div>
                      </div>
                    </div>

                    <button 
                      disabled={isLoggingIn}
                      type="submit" 
                      className="w-full py-5 bg-indigo-600 text-white rounded-[2rem] font-black text-sm uppercase tracking-widest shadow-2xl shadow-indigo-900/50 hover:bg-indigo-500 transition-all active:scale-95 flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-wait group"
                    >
                      {isLoggingIn ? (
                        <span className="flex items-center gap-2">
                          <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin"></div>
                          Authenticating...
                        </span>
                      ) : (
                        <>
                          Secure Sign In
                          <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
                        </>
                      )}
                    </button>

                    <div className="pt-4 text-center">
                      <a href="#" className="text-[10px] font-black text-slate-500 hover:text-indigo-400 uppercase tracking-widest transition-colors">Forgot Credentials?</a>
                    </div>
                 </form>
              </div>
            </div>
          </div>
        </div>

        {/* Dynamic Digital Footer */}
        <footer className="w-full py-6 md:py-8 border-t border-white/5 bg-slate-900/20 backdrop-blur-sm z-10">
          <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-4">
             <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-indigo-500/10 rounded-lg flex items-center justify-center text-indigo-400">
                   <Cpu size={18} />
                </div>
                <div>
                   <p className="text-[11px] font-black text-white uppercase tracking-wider">EduNexus Intelligence Node</p>
                   <p className="text-[9px] text-slate-500 font-bold uppercase tracking-tighter">Verified Architecture Tier</p>
                </div>
             </div>
             <div className="flex items-center gap-6">
                <span className="text-[9px] font-black text-slate-600 uppercase tracking-[0.2em]">© 2025 EN-LEGAL-NODE</span>
                <div className="flex items-center gap-2">
                   <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
                   <span className="text-[9px] font-black text-emerald-500 uppercase">Core Systems Active</span>
                </div>
             </div>
          </div>
        </footer>
      </div>
    );
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': 
        return userRole === UserRole.PRINCIPAL ? <PrincipalPanel /> : <Dashboard session={currentSession} onNavigate={setActiveTab} />;
      case 'teacher_panel': return <TeacherPanel />;
      case 'parent_panel': return <ParentPanel />;
      case 'planner': return <AcademicCalendar session={currentSession} />;
      case 'students': return <StudentManagement />;
      case 'attendance': return <AttendanceManagement />;
      case 'academics': return <AcademicManagement />;
      case 'exams': return <ExamsManagement />;
      case 'fees': return <FeesManagement session={currentSession} />;
      case 'philanthropy': return <PhilanthropyHub />;
      case 'hr': return <HRManagement />;
      case 'finance': return <FinanceHub />;
      case 'library': return <LibraryManagement />;
      case 'transport': return <TransportManagement />;
      case 'messages': return <CommunicationHub />;
      case 'documents': return <CertificateManagement session={currentSession} />;
      case 'notices': return <NoticeBoard />;
      case 'alumni': return <AlumniManagement />;
      case 'settings': return <SettingsManagement />;
      case 'credentials': return <SecurityVault userRole={userRole} />;
      default: return <Dashboard session={currentSession} onNavigate={setActiveTab} />;
    }
  };

  return (
    <div className="min-h-screen flex bg-slate-50 overflow-x-hidden selection:bg-indigo-100">
      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={(id) => { setActiveTab(id); setIsSidebarOpen(false); }} 
        userRole={userRole} 
        isOpen={isSidebarOpen} 
        onClose={() => setIsSidebarOpen(false)} 
      />
      
      {isSidebarOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[55] lg:hidden" onClick={() => setIsSidebarOpen(false)}></div>
      )}

      <main className={`flex-1 transition-all duration-300 bg-slate-50/50 ${userRole ? 'lg:ml-64' : ''}`}>
        <header className="sticky top-0 z-50 h-16 md:h-20 bg-white/80 backdrop-blur-xl border-b border-slate-200/60 px-4 md:px-8 flex items-center justify-between no-print shadow-sm">
          <div className="flex items-center gap-3 md:gap-6">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="lg:hidden p-2 text-slate-500 hover:bg-slate-100 rounded-xl"
            >
              <Menu size={20} />
            </button>

            <div className="hidden md:flex relative w-72 group">
              <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" />
              <input 
                type="text" 
                placeholder="Global search..." 
                className="w-full pl-11 pr-4 py-2.5 bg-slate-100/50 border border-slate-200/50 focus:bg-white focus:border-indigo-500/50 focus:ring-4 focus:ring-indigo-500/5 rounded-2xl text-xs font-medium transition-all focus:outline-none"
              />
            </div>

            <div className="relative">
              <button 
                onClick={() => setShowSessionMenu(!showSessionMenu)}
                className="flex items-center gap-2 md:gap-3 px-3 md:px-4 py-1.5 md:py-2 bg-indigo-50/50 hover:bg-indigo-50 text-indigo-700 rounded-xl transition-all border border-indigo-100/50 group"
              >
                <CalendarDays size={14} className="text-indigo-500 hidden sm:block" />
                <span className="text-[9px] md:text-[11px] font-black uppercase tracking-wider">{currentSession.label.split(' ')[0]}</span>
                <ChevronDown size={12} className={`text-indigo-400 transition-transform ${showSessionMenu ? 'rotate-180' : ''}`} />
              </button>
              
              {showSessionMenu && (
                <>
                  <div className="fixed inset-0 z-10" onClick={() => setShowSessionMenu(false)}></div>
                  <div className="absolute top-full left-0 mt-2 w-56 md:w-64 bg-white rounded-2xl shadow-2xl border border-slate-100 p-2 z-20 animate-in fade-in slide-in-from-top-2">
                    <p className="px-4 py-2 text-[9px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-50 mb-1">Academic Sessions</p>
                    {SESSIONS.map(session => (
                      <button 
                        key={session.id}
                        onClick={() => { setCurrentSession(session); setShowSessionMenu(false); }}
                        className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-xs font-bold transition-colors ${currentSession.id === session.id ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' : 'text-slate-600 hover:bg-slate-50'}`}
                      >
                        {session.label}
                        {currentSession.id === session.id && <Sparkles size={12} className="text-indigo-200" />}
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>
          
          <div className="flex items-center gap-2 md:gap-4">
             <div className="px-2 md:px-4 py-1.5 md:py-2 bg-slate-900 rounded-xl md:rounded-2xl flex items-center gap-2 md:gap-3">
               <div className="w-1.5 md:w-2 h-1.5 md:h-2 rounded-full bg-emerald-500 animate-pulse"></div>
               <span className="text-[8px] md:text-[10px] font-black text-white uppercase tracking-widest">{userRole}</span>
             </div>
             <div className="h-6 md:h-8 w-px bg-slate-200/60 mx-1 md:mx-2"></div>
             <button onClick={() => { setUserRole(null); setLoginId(''); setLoginPass(''); }} className="flex items-center gap-2 md:gap-3 px-3 md:px-5 py-1.5 md:py-2.5 bg-white border border-slate-200 text-slate-900 font-black text-[9px] md:text-[11px] hover:bg-slate-50 rounded-xl md:rounded-2xl transition-all shadow-sm uppercase tracking-widest">
               <LogOut size={14} className="text-rose-500" />
               <span className="hidden sm:inline">Logout</span>
             </button>
          </div>
        </header>

        <div className="pb-10 md:pb-20">
          {renderContent()}
        </div>
      </main>

      <style>{`
        .animate-spin-slow { animation: spin 8s linear infinite; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        ::-webkit-scrollbar { width: 4px; height: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #e2e8f0; border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: #cbd5e1; }
      `}</style>
    </div>
  );
};

export default App;
