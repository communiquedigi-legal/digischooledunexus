
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://kqptjoqxnzzfpndkvbvk.supabase.co';
const supabaseAnonKey = 'sb_publishable_M5YDZanyvjJv0jSKNIw8-w_8Eg9NWAP';

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn('Supabase credentials missing. Data sync will be disabled.');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
