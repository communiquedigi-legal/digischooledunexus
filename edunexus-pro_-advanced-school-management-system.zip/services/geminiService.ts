import { GoogleGenAI, Type } from "@google/genai";

export const generateSchoolNotice = async (topic: string) => {
  // Fix: Move GoogleGenAI instantiation inside function to ensure latest API key usage from process.env.API_KEY
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Generate a formal school notice about: ${topic}. Include date, title, body, and signatory (Principal).`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            content: { type: Type.STRING },
            date: { type: Type.STRING }
          },
          required: ["title", "content", "date"]
        }
      }
    });
    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("AI Generation failed", error);
    return null;
  }
};

export const generateQuizQuestions = async (subject: string, topic: string, type: string = 'MCQ') => {
  // Fix: Move GoogleGenAI instantiation inside function to ensure latest API key usage from process.env.API_KEY
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const prompt = `Generate a 5-question ${type} assessment for ${subject} on ${topic}. 
    
    Format Rules:
    - For MCQ: provide 4 distinct 'options' and a 'correctAnswer' (one of the options).
    - For Short Answer: provide a concise 'question' and a 'modelAnswer' (2-3 sentences).
    - For Long Answer: provide a descriptive 'question' and a comprehensive 'modelAnswer' (key points).
    - For One-word: provide a 'question' that has a single-word 'modelAnswer'. 

    Return as a JSON array.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              question: { type: Type.STRING },
              options: { 
                type: Type.ARRAY, 
                items: { type: Type.STRING }, 
                description: "Required for MCQ type only" 
              },
              correctAnswer: { 
                type: Type.STRING, 
                description: "Required for MCQ type only" 
              },
              modelAnswer: { 
                type: Type.STRING, 
                description: "Required for Descriptive/One-word types" 
              }
            },
            required: ["question"]
          }
        }
      }
    });
    return JSON.parse(response.text || "[]");
  } catch (error) {
    console.error("Quiz generation failed", error);
    return [];
  }
};