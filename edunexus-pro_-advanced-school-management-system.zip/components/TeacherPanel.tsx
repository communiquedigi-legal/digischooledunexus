
import React, { useState, useMemo } from 'react';
import { 
  GraduationCap, BookOpen, FileText, CheckCircle2, Clock, 
  Plus, IndianRupee, Bell, Users, MessageSquare, 
  Upload, UserCheck, AlertCircle, FileUp, Sparkles, Pencil,
  ChevronRight, CheckSquare, ShieldCheck, LayoutGrid, Award,
  Activity, Star
} from 'lucide-react';
import { MOCK_SALARY, MOCK_HOMEWORK, MOCK_CREDENTIALS } from '../constants';
// Fix: Missing interface export will be available in types.ts
import { TeacherAssignment } from '../types';

const TeacherPanel: React.FC = () => {
  // Simulating logged in teacher Priya Verma (T003)
  const teacherProfile = MOCK_CREDENTIALS.find(c => c.uid === 'T003')!;
  const assignments = teacherProfile.assignments || [];
  
  const [activeSubView, setActiveSubView] = useState<'classroom' | 'personal' | 'support'>('classroom');
  const [selectedAssignment, setSelectedAssignment] = useState<TeacherAssignment>(assignments[0]);

  const homeroomAssignment = useMemo(() => assignments.find(a => a.isClassTeacher), [assignments]);

  return (
    <div className="p-4 md:p-8 space-y-6 md:space-y-10 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-6">
        <div>
          <h1 className="text-3xl md:text-4xl font-black text-slate-900 italic uppercase tracking-tighter">Faculty Workspace</h1>
          <p className="text-slate-500 font-medium italic text-xs md:text-sm">Welcome, {teacherProfile.name} • {teacherProfile.category}</p>
        </div>
        <div className="flex bg-white p-1 rounded-2xl border border-slate-200 shadow-sm overflow-x-auto no-print">
           <button onClick={() => setActiveSubView('classroom')} className={`px-4 md:px-8 py-2 md:py-2.5 rounded-xl text-[10px] md:text-xs font-black transition-all whitespace-nowrap ${activeSubView === 'classroom' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}>Academic Hub</button>
           <button onClick={() => setActiveSubView('personal')} className={`px-4 md:px-8 py-2 md:py-2.5 rounded-xl text-[10px] md:text-xs font-black transition-all whitespace-nowrap ${activeSubView === 'personal' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}>My Records</button>
           <button onClick={() => setActiveSubView('support')} className={`px-4 md:px-8 py-2 md:py-2.5 rounded-xl text-[10px] md:text-xs font-black transition-all whitespace-nowrap ${activeSubView === 'support' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}>Support</button>
        </div>
      </div>

      {activeSubView === 'classroom' && (
        <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
           {/* Assignment Selector */}
           <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                 <div className="p-4 bg-indigo-50 text-indigo-600 rounded-2xl shadow-sm"><LayoutGrid size={24}/></div>
                 <div>
                    <h3 className="text-xl font-black text-slate-900">Current View Context</h3>
                    <p className="text-xs font-medium text-slate-400 uppercase tracking-widest">Select an assigned class to manage</p>
                 </div>
              </div>
              <div className="flex gap-3 overflow-x-auto w-full md:w-auto p-1">
                 {assignments.map((a, i) => (
                   <button 
                    key={i} 
                    onClick={() => setSelectedAssignment(a)}
                    className={`px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all border-2 flex items-center gap-2 whitespace-nowrap ${selectedAssignment === a ? 'bg-indigo-600 text-white border-indigo-600 shadow-xl' : 'bg-slate-50 text-slate-400 border-transparent hover:border-indigo-100'}`}
                   >
                     {a.isClassTeacher && <Star size={12} fill="currentColor"/>}
                     Grade {a.class}-{a.section} • {a.subject}
                   </button>
                 ))}
              </div>
           </div>

           <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-8">
                 {/* Homeroom Overview - Only visible if Class Teacher */}
                 {selectedAssignment.isClassTeacher && (
                   <div className="bg-slate-900 p-10 rounded-[3.5rem] text-white shadow-2xl relative overflow-hidden group">
                      <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform rotate-12"><GraduationCap size={120}/></div>
                      <div className="bg-emerald-500/20 text-emerald-400 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest inline-flex items-center gap-2 mb-6 border border-emerald-500/20">
                         <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse"></div>
                         Homeroom Authority (Class Teacher)
                      </div>
                      <h3 className="text-4xl font-black mb-8 leading-tight tracking-tighter">Class 10-A Sync Cockpit</h3>
                      <div className="grid grid-cols-3 gap-6">
                         <div className="p-6 bg-white/5 border border-white/10 rounded-3xl">
                            <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-1">Strength</p>
                            <p className="text-2xl font-black">24 St.</p>
                         </div>
                         <div className="p-6 bg-white/5 border border-white/10 rounded-3xl">
                            <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-1">Today Att.</p>
                            <p className="text-2xl font-black text-emerald-400">92%</p>
                         </div>
                         <div className="p-6 bg-white/5 border border-white/10 rounded-3xl">
                            <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-1">Fees Due</p>
                            <p className="text-2xl font-black text-rose-400">₹8.4k</p>
                         </div>
                      </div>
                   </div>
                 )}

                 <div className="bg-white p-8 md:p-10 rounded-[3rem] border border-slate-100 shadow-sm">
                    <div className="flex justify-between items-center mb-10">
                       <h3 className="text-2xl font-black text-slate-900 flex items-center gap-3"><Pencil className="text-indigo-600"/> Homework Console</h3>
                       <button onClick={() => alert(`Uploading Homework for Grade ${selectedAssignment.class}-${selectedAssignment.section} • ${selectedAssignment.subject}`)} className="px-5 py-2.5 bg-indigo-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg flex items-center gap-2 hover:bg-indigo-700 transition-all">
                          <Plus size={16}/> New Mission
                       </button>
                    </div>
                    <div className="space-y-4">
                       {MOCK_HOMEWORK.filter(hw => hw.class === selectedAssignment.class && hw.section === selectedAssignment.section && (selectedAssignment.isClassTeacher || hw.subject === selectedAssignment.subject)).map((hw) => (
                         <div key={hw.id} className="p-6 bg-slate-50 border border-slate-100 rounded-[2rem] hover:bg-white hover:border-indigo-200 transition-all flex items-start justify-between group">
                            <div className="flex gap-6">
                               <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-sm shrink-0 ${hw.subject === selectedAssignment.subject ? 'bg-indigo-600' : 'bg-slate-300'}`}><FileText size={20}/></div>
                               <div>
                                  <h4 className="font-black text-slate-900">{hw.title}</h4>
                                  <p className="text-[10px] font-bold text-slate-400 uppercase mt-1">{hw.subject} • by {hw.teacher}</p>
                                  <div className="flex items-center gap-4 mt-3">
                                     <span className="text-[9px] font-black text-indigo-400 uppercase tracking-widest flex items-center gap-1"><Clock size={10}/> Due: {hw.dueDate}</span>
                                     <span className="text-[9px] font-black text-emerald-500 uppercase tracking-widest flex items-center gap-1"><Users size={10}/> 18/24 Turned in</span>
                                  </div>
                               </div>
                            </div>
                            <button className="p-2 text-slate-300 hover:text-indigo-600 transition-colors"><ChevronRight size={20}/></button>
                         </div>
                       ))}
                    </div>
                 </div>

                 <div className="bg-white p-8 md:p-10 rounded-[3rem] border border-slate-100 shadow-sm">
                    <div className="flex justify-between items-center mb-8">
                      <h3 className="text-xl font-black text-slate-900 flex items-center gap-3"><Award className="text-rose-500" /> Exam & Grade Authority</h3>
                      <button className="text-[10px] font-black text-indigo-600 uppercase hover:underline">View Gradebook</button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                       {[
                         { label: 'Unit Test Results', info: `Finalize for ${selectedAssignment.subject}`, status: 'Pending Mark Entry', icon: <CheckCircle2 size={18}/> },
                         { label: 'Conduct Online Quiz', info: `AI Generated for ${selectedAssignment.subject}`, status: 'Draft', icon: <Activity size={18}/> }
                       ].map((act, i) => (
                         <div key={i} className="p-6 bg-slate-50 border border-slate-100 rounded-3xl hover:bg-white hover:border-rose-200 transition-all cursor-pointer group shadow-sm">
                           <div className="flex items-center gap-4 mb-4">
                              <div className="p-3 bg-white rounded-xl text-slate-300 group-hover:text-rose-500 transition-colors shadow-sm">{act.icon}</div>
                              <div>
                                 <p className="text-xs font-black text-slate-900">{act.label}</p>
                                 <p className="text-[9px] font-bold text-slate-400 uppercase">{act.info}</p>
                              </div>
                           </div>
                           <span className="text-[8px] font-black uppercase tracking-widest px-2 py-1 bg-amber-50 text-amber-600 rounded">{act.status}</span>
                         </div>
                       ))}
                    </div>
                 </div>
              </div>

              <div className="space-y-8">
                 <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
                    <div className="flex justify-between items-center mb-8">
                       <h3 className="text-xl font-black text-slate-900">Communication</h3>
                       <span className="p-2 bg-rose-50 text-rose-500 rounded-full animate-bounce"><Bell size={18}/></span>
                    </div>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-6 italic">Notifications for Grade {selectedAssignment.class}-{selectedAssignment.section}</p>
                    <div className="space-y-6">
                       {[
                         { parent: 'Mr. Gupta', topic: 'Medical Leave (Aarav)', time: '10m ago' },
                         { parent: 'Mrs. Sharma', topic: 'Marks Verification', time: '1h ago' }
                       ].map((req, i) => (
                         <div key={i} className="p-6 bg-slate-50 rounded-3xl border border-slate-100 hover:shadow-lg transition-all cursor-pointer group">
                            <div className="flex justify-between mb-2">
                               <p className="text-sm font-black text-slate-900 group-hover:text-indigo-600 transition-colors">{req.parent}</p>
                               <span className="text-[9px] font-bold text-slate-400 uppercase">{req.time}</span>
                            </div>
                            <p className="text-xs font-medium text-slate-500 leading-relaxed mb-4">{req.topic}</p>
                            <div className="flex gap-2">
                               <button className="flex-1 py-2 bg-indigo-600 text-white rounded-xl text-[9px] font-black uppercase tracking-widest shadow-md">Approve</button>
                               <button className="px-3 py-2 bg-white border border-slate-200 text-slate-400 rounded-xl hover:text-indigo-600 transition-colors"><MessageSquare size={12}/></button>
                            </div>
                         </div>
                       ))}
                    </div>
                 </div>

                 {/* Personal Quick Stat */}
                 <div className="bg-indigo-600 p-8 rounded-[3rem] text-white shadow-xl">
                    <p className="text-[10px] font-black text-indigo-200 uppercase mb-4">Personal Attendance Summary</p>
                    <div className="flex items-center justify-between">
                       <h4 className="text-4xl font-black">98.2%</h4>
                       <CheckSquare size={40} className="text-indigo-400" />
                    </div>
                    <p className="text-[10px] text-indigo-100 mt-2 uppercase">21 of 22 Days Registered</p>
                 </div>
              </div>
           </div>
        </div>
      )}

      {activeSubView === 'personal' && (
        <div className="space-y-10 animate-in fade-in duration-300">
           <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <div className="bg-white p-12 rounded-[3.5rem] border border-slate-100 shadow-sm relative overflow-hidden">
                 <div className="absolute top-0 right-0 p-10 opacity-5"><IndianRupee size={120}/></div>
                 <div className="flex justify-between items-start mb-10">
                    <div>
                       <p className="text-[10px] font-black text-indigo-600 uppercase tracking-[0.2em] mb-2">Earnings Registry</p>
                       <h3 className="text-3xl font-black text-slate-900">Digital Salary Payslip</h3>
                    </div>
                    <button className="px-6 py-3 bg-slate-900 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl shadow-slate-900/10 flex items-center gap-2 hover:bg-indigo-600 transition-all">
                       <Upload size={14}/> Download PDF
                    </button>
                 </div>
                 {/* Fix: Corrected property access to match the nested structure of MOCK_SALARY.earnings */}
                 <div className="grid grid-cols-3 gap-6 border-t border-slate-100 pt-10">
                    <div><p className="text-[10px] font-black text-slate-400 uppercase">Base</p><p className="text-xl font-black text-slate-900 mt-1">₹{MOCK_SALARY.earnings.basic.toLocaleString()}</p></div>
                    <div><p className="text-[10px] font-black text-slate-400 uppercase">Allowances</p><p className="text-xl font-black text-indigo-600 mt-1">₹{(MOCK_SALARY.earnings.hra + MOCK_SALARY.earnings.conveyance).toLocaleString()}</p></div>
                    <div className="bg-slate-50 p-4 rounded-2xl"><p className="text-[9px] font-black text-slate-400 uppercase">Net Disbursed</p><p className="text-2xl font-black text-emerald-600 mt-1">₹{MOCK_SALARY.net.toLocaleString()}</p></div>
                 </div>
              </div>

              <div className="bg-white p-12 rounded-[3.5rem] border border-slate-100 shadow-sm">
                 <h3 className="text-2xl font-black text-slate-900 mb-8">Contract Details</h3>
                 <div className="space-y-6">
                    <div className="flex justify-between items-center py-2 border-b border-slate-50">
                       <span className="text-xs font-bold text-slate-400 uppercase">Employee ID</span>
                       <span className="text-sm font-black text-slate-900">EDU-T003</span>
                    </div>
                    <div className="flex justify-between items-center py-2 border-b border-slate-50">
                       <span className="text-xs font-bold text-slate-400 uppercase">Designation</span>
                       <span className="text-sm font-black text-indigo-600">Senior Faculty & Class Teacher</span>
                    </div>
                    <div className="flex justify-between items-center py-2 border-b border-slate-50">
                       <span className="text-xs font-bold text-slate-400 uppercase">D.O.J</span>
                       <span className="text-sm font-black text-slate-900">01 April 2021</span>
                    </div>
                 </div>
              </div>
           </div>
        </div>
      )}

      {activeSubView === 'support' && (
        <div className="max-w-4xl mx-auto space-y-10 animate-in zoom-in-95">
           <div className="bg-rose-50 p-12 rounded-[3.5rem] border-2 border-rose-100 text-center relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 opacity-10 -rotate-12"><AlertCircle size={100} className="text-rose-500"/></div>
              <h3 className="text-3xl font-black text-rose-900 mb-4 italic">Portal Non-Responsive?</h3>
              <p className="text-rose-700/70 font-medium text-base md:text-lg leading-relaxed max-w-2xl mx-auto mb-10">If you experience technical issues with the grading module or student sync, raise an immediate high-priority ticket with the Institutional IT Node.</p>
              <button 
                 onClick={() => alert('IT Incident Report Dispatched: Grading Module Latency')}
                 className="px-8 md:px-12 py-4 md:py-6 bg-rose-600 text-white rounded-[2.5rem] font-black text-sm uppercase tracking-widest shadow-2xl shadow-rose-200 hover:bg-rose-700 transition-all flex items-center justify-center gap-4 mx-auto"
              >
                 <ShieldCheck size={20}/> LOG IT INCIDENT
              </button>
           </div>
        </div>
      )}
    </div>
  );
};

export default TeacherPanel;
