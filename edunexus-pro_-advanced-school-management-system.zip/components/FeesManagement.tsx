
import React, { useState, useMemo, useEffect } from 'react';
import { 
  CreditCard, Wallet, Receipt, Filter, Plus, 
  FileText, Send, Bell, CheckCircle, Search, X, Printer, Download, 
  QrCode, Layers, Info, Trash2, Save, ShieldCheck,
  IndianRupee, Edit3, Check, PlusCircle, MinusCircle, FileDown, BellRing,
  Smartphone, Share2, Tag, Percent, Bus, Home, BadgePercent,
  History, ArrowRight, User, Loader2, Calendar, Settings2,
  Clock, AlertTriangle, MessageCircle, Building2, Beaker, Utensils,
  Landmark, DownloadCloud, Lock, ShieldAlert, HeartHandshake,
  UsersRound, Venus, LayoutGrid, Box, GraduationCap, Building, UserPlus
} from 'lucide-react';
import { CLASS_LIST, SECTION_LIST, STUDENT_GROUPS, SOCIAL_CATEGORIES } from '../constants';
import { AcademicSession, Student, ClassGroup } from '../types';
import { supabase } from '../lib/supabase';

type FeeFrequency = 'Monthly' | 'Quarterly' | 'Half-Yearly' | 'Yearly' | 'One-Time';
type FeeType = 'Admission' | 'Tuition' | 'Examination' | 'Library' | 'Laboratory' | 'Transport' | 'Development' | 'Hostel' | 'Security-Deposit' | 'Other';

interface FeeHead {
  id: string;
  name: string;
  type: FeeType;
  amount: number;
  frequency: FeeFrequency;
  dueDate: string; 
  targetType: 'Global' | 'SpecificClass' | 'ClassGroup';
  targetValue: string; 
  targetGender: 'All' | 'Male' | 'Female';
  targetCategory: 'All' | 'General' | 'OBC' | 'SC' | 'ST' | 'EWS' | 'BPL';
}

interface Transaction {
  id: string;
  studentId: string;
  studentName: string;
  studentClass: string;
  studentSection: string;
  items: Array<{ name: string; amount: number }>;
  amount: number;
  discount: number;
  discountReason?: string;
  mode: string;
  date: string;
  status: 'Success' | 'Pending';
  isRefund?: boolean;
}

const FeesManagement: React.FC<{ session?: AcademicSession }> = ({ session }) => {
  const [activeTab, setActiveTab] = useState<'collection' | 'master' | 'groups' | 'ledger'>('collection');
  const [loading, setLoading] = useState(true);
  const [students, setStudents] = useState<any[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  
  const [classGroups, setClassGroups] = useState<ClassGroup[]>([
    { id: 'cg1', name: 'Primary Wing', classes: ['1', '2', '3', '4', '5'] },
    { id: 'cg2', name: 'Middle School', classes: ['6', '7', '8'] },
    { id: 'cg3', name: 'Senior Secondary', classes: ['9', '10', '11', '12'] },
    { id: 'cg4', name: 'Foundation', classes: ['Nursery', 'LKG', 'UKG'] },
  ]);

  const [feeHeads, setFeeHeads] = useState<FeeHead[]>([
    { id: 'fh1', name: 'Base Tuition (Primary)', type: 'Tuition', amount: 25000, frequency: 'Yearly', dueDate: '10', targetType: 'ClassGroup', targetValue: 'cg1', targetGender: 'All', targetCategory: 'All' },
    { id: 'fh2', name: 'Base Tuition (Senior)', type: 'Tuition', amount: 45000, frequency: 'Yearly', dueDate: '10', targetType: 'ClassGroup', targetValue: 'cg3', targetGender: 'All', targetCategory: 'All' },
    { id: 'fh3', name: 'Admission Protocol Fee', type: 'Admission', amount: 15000, frequency: 'One-Time', dueDate: '01', targetType: 'Global', targetValue: 'All', targetGender: 'All', targetCategory: 'All' },
  ]);

  // Selection/Filter States
  const [classFilter, setClassFilter] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  // Modal & Editing States
  const [showAddHead, setShowAddHead] = useState(false);
  const [editingFeeHead, setEditingFeeHead] = useState<FeeHead | null>(null);
  
  const [showAddGroup, setShowAddGroup] = useState(false);
  const [editingGroup, setEditingGroup] = useState<ClassGroup | null>(null);

  const [showCollectModal, setShowCollectModal] = useState<any>(null);
  const [showReceiptModal, setShowReceiptModal] = useState<Transaction | null>(null);

  useEffect(() => {
    fetchFinancialData();
  }, []);

  const fetchFinancialData = async () => {
    setLoading(true);
    try {
      const { data: stds } = await supabase.from('students').select('*');
      const { data: txns } = await supabase.from('fee_transactions').select('*').order('date', { ascending: false });
      setStudents(stds || []);
      setTransactions(txns || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const getStudentDues = (student: any) => {
    const studentTxns = transactions.filter(t => t.studentId === student.id && !t.isRefund);
    const paidAmount = studentTxns.reduce((sum, t) => sum + t.amount, 0);
    
    let totalExpected = 0;
    feeHeads.forEach(head => {
      let isUnitApplicable = false;
      if (head.targetType === 'Global') isUnitApplicable = true;
      else if (head.targetType === 'SpecificClass') isUnitApplicable = head.targetValue === student.class;
      else if (head.targetType === 'ClassGroup') {
        const group = classGroups.find(g => g.id === head.targetValue);
        isUnitApplicable = group ? group.classes.includes(student.class) : false;
      }

      if (!isUnitApplicable) return;
      const isGenderApplicable = head.targetGender === 'All' || head.targetGender === student.gender;
      const isCategoryApplicable = head.targetCategory === 'All' || head.targetCategory === student.category;
      if (!isGenderApplicable || !isCategoryApplicable) return;

      let multiplier = 1;
      if (head.frequency === 'Monthly') multiplier = 12;
      else if (head.frequency === 'Quarterly') multiplier = 4;
      else if (head.frequency === 'Half-Yearly') multiplier = 2;

      totalExpected += (head.amount * multiplier);
    });

    const dues = totalExpected - paidAmount;
    return { totalExpected, paidAmount, dues };
  };

  const handleProcessPayment = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const amount = Number(fd.get('amount'));
    const discount = Number(fd.get('discount'));
    
    const newTxn: Transaction = {
      id: `TXN-${Math.random().toString(36).substr(2, 6).toUpperCase()}`,
      studentId: showCollectModal.id,
      studentName: showCollectModal.name,
      studentClass: showCollectModal.class,
      studentSection: showCollectModal.section,
      amount: amount - discount,
      discount,
      discountReason: fd.get('discountReason') as string,
      mode: fd.get('mode') as string,
      date: new Date().toISOString(),
      items: [{ name: 'Institutional Fee Settlement', amount: amount - discount }],
      status: 'Success'
    };

    const { error } = await supabase.from('fee_transactions').insert([newTxn]);
    if (!error) {
      fetchFinancialData();
      setShowCollectModal(null);
      setShowReceiptModal(newTxn);
    } else {
      alert('Sync Failure: ' + error.message);
    }
  };

  const filteredStudents = useMemo(() => {
    return students.filter(s => {
      const classMatch = classFilter === 'All' || s.class === classFilter;
      const searchMatch = s.name.toLowerCase().includes(searchQuery.toLowerCase()) || (s.id && s.id.toLowerCase().includes(searchQuery.toLowerCase()));
      return classMatch && searchMatch;
    });
  }, [students, classFilter, searchQuery]);

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-7xl mx-auto min-h-screen">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-6 no-print">
        <div>
          <h1 className="text-3xl md:text-5xl font-black text-slate-900 italic uppercase tracking-tighter leading-none">Fiscal Hub</h1>
          <p className="text-slate-500 font-medium uppercase text-[10px] tracking-widest mt-1 tracking-[0.2em]">Institutional Governance Node</p>
        </div>
        <div className="flex bg-white p-1 rounded-2xl border border-slate-200 shadow-sm overflow-x-auto scrollbar-hide">
          {[
            { id: 'collection', label: 'Dues & Collection', icon: <CreditCard size={14}/> },
            { id: 'master', label: 'Fee Architect', icon: <Settings2 size={14}/> },
            { id: 'groups', label: 'Structure Units', icon: <Box size={14}/> },
            { id: 'ledger', label: 'Global Ledger', icon: <History size={14}/> },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-6 py-2.5 font-black text-[10px] uppercase tracking-widest flex items-center gap-2 rounded-xl transition-all whitespace-nowrap ${activeTab === tab.id ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-50'}`}
            >
              {tab.icon} {tab.label}
            </button>
          ))}
        </div>
      </div>

      {activeTab === 'collection' && (
        <div className="space-y-8 animate-in fade-in">
          <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm flex flex-col md:flex-row justify-between items-center gap-6 no-print">
            <div className="flex items-center gap-4 w-full md:w-auto">
              <select 
                value={classFilter} 
                onChange={(e) => setClassFilter(e.target.value)}
                className="px-6 py-3 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-[10px] uppercase outline-none focus:bg-white transition-all"
              >
                <option value="All">All Grades</option>
                {CLASS_LIST.map(c => <option key={c} value={c}>Grade {c}</option>)}
              </select>
              <div className="relative flex-1 md:w-80 group">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18}/>
                <input 
                  type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Filter student or UID..." 
                  className="w-full pl-12 pr-4 py-3 bg-slate-50 border-2 border-slate-100 rounded-2xl text-xs font-black outline-none focus:bg-white transition-all"
                />
              </div>
            </div>
            <button className="w-full md:w-auto px-8 py-4 bg-rose-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 shadow-xl shadow-rose-200">
               <BellRing size={16}/> Blast Due Notifications
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredStudents.map(student => {
              const { totalExpected, paidAmount, dues } = getStudentDues(student);
              return (
                <div key={student.id} className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm hover:shadow-2xl transition-all group relative overflow-hidden">
                   <div className="absolute top-0 right-0 p-8 opacity-5"><IndianRupee size={80}/></div>
                   <div className="flex items-center gap-5 mb-8">
                      <img src={student.photo_url || student.photoUrl} className="w-16 h-16 rounded-[1.5rem] object-cover border-4 border-slate-50 shadow-inner" />
                      <div>
                        <h4 className="text-xl font-black text-slate-900 leading-tight truncate max-w-[140px]">{student.name}</h4>
                        <div className="flex items-center gap-2 mt-1">
                          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">G{student.class}-{student.section}</p>
                          <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase ${student.gender === 'Female' ? 'bg-rose-50 text-rose-600' : 'bg-blue-50 text-blue-600'}`}>{student.gender}</span>
                        </div>
                        <p className="text-[9px] font-black text-indigo-500 uppercase mt-1">Cat: {student.category}</p>
                      </div>
                   </div>
                   <div className="space-y-4">
                      <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest">
                         <span className="text-slate-400">Total Billed</span>
                         <span className="text-slate-900">₹{totalExpected.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest">
                         <span className="text-slate-400">Paid to Ledger</span>
                         <span className="text-emerald-600">₹{paidAmount.toLocaleString()}</span>
                      </div>
                      <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                         <div className="h-full bg-indigo-600 transition-all duration-1000" style={{ width: `${Math.min((paidAmount/totalExpected)*100, 100)}%` }}></div>
                      </div>
                      <div className="pt-4 border-t border-slate-50 flex justify-between items-end">
                         <div>
                            <p className="text-[9px] font-black text-rose-500 uppercase tracking-tighter">Outstanding Dues</p>
                            <p className="text-3xl font-black text-slate-900">₹{dues.toLocaleString()}</p>
                         </div>
                         <button onClick={() => setShowCollectModal(student)} disabled={dues <= 0} className="px-6 py-3 bg-indigo-600 disabled:bg-slate-100 disabled:text-slate-300 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-indigo-100 transition-all active:scale-95">Collect</button>
                      </div>
                   </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {activeTab === 'groups' && (
        <div className="space-y-10 animate-in fade-in">
           <div className="bg-white p-10 md:p-16 rounded-[4rem] border border-slate-100 shadow-sm flex flex-col lg:flex-row justify-between items-center gap-12 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-10 opacity-5 rotate-12"><LayoutGrid size={200}/></div>
              <div className="relative z-10 space-y-6">
                 <div className="bg-indigo-500/20 text-indigo-400 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] inline-block border border-white/5">Units Engine</div>
                 <h2 className="text-4xl md:text-6xl font-black italic uppercase tracking-tighter leading-none">Structure Units</h2>
                 <p className="text-slate-500 max-w-xl font-medium">Designate logical clusters of classes (e.g. Primary, Secondary, Science-Stream) to apply unified fee architectures efficiently.</p>
              </div>
              <button onClick={() => { setEditingGroup(null); setShowAddGroup(true); }} className="relative z-10 px-10 py-5 bg-slate-900 text-white rounded-[2rem] font-black text-xs uppercase tracking-widest flex items-center gap-3 shadow-2xl hover:scale-105 active:scale-95 transition-all">
                 <Plus size={20}/> Establish New Unit
              </button>
           </div>

           <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {classGroups.map(group => (
                <div key={group.id} className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm hover:shadow-xl transition-all group relative overflow-hidden">
                   <div className="absolute top-0 right-0 p-8 opacity-5"><Building size={80}/></div>
                   <div className="flex justify-between items-start mb-10 border-b border-slate-50 pb-6">
                      <div>
                        <h4 className="text-3xl font-black text-slate-900 uppercase italic leading-none">{group.name}</h4>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-2">{group.classes.length} Registered Levels</p>
                      </div>
                      <div className="flex gap-2">
                        <button onClick={() => { setEditingGroup(group); setShowAddGroup(true); }} className="p-3 bg-slate-50 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all shadow-sm">
                          <Edit3 size={18}/>
                        </button>
                        <button onClick={() => { if(confirm('Delete this unit?')) setClassGroups(classGroups.filter(g => g.id !== group.id)); }} className="p-3 bg-rose-50 text-rose-400 rounded-xl hover:bg-rose-600 hover:text-white transition-all">
                          <Trash2 size={18}/>
                        </button>
                      </div>
                   </div>
                   
                   <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Constituent Classes</p>
                   <div className="flex flex-wrap gap-2">
                      {group.classes.map(c => (
                        <span key={c} className="px-4 py-2 bg-indigo-50 border border-indigo-100 rounded-xl text-[10px] font-black text-indigo-700 uppercase tracking-widest">Grade {c}</span>
                      ))}
                   </div>
                </div>
              ))}
           </div>
        </div>
      )}

      {activeTab === 'master' && (
        <div className="space-y-10 animate-in fade-in">
          <div className="bg-indigo-600 p-10 md:p-16 rounded-[4rem] text-white flex flex-col lg:flex-row justify-between items-center gap-12 relative overflow-hidden">
             <div className="absolute top-0 right-0 p-10 opacity-10 rotate-12"><Settings2 size={200}/></div>
             <div className="relative z-10 space-y-6">
                <div className="bg-white/20 text-white px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] inline-block border border-white/10">Architecture Node</div>
                <h2 className="text-4xl md:text-6xl font-black italic uppercase tracking-tighter leading-none text-white">Fee Blueprint</h2>
                <p className="text-indigo-100 max-w-xl font-medium">Engineer specialized fee types (Admission, Tuition, Assessment) and bind them to specific classes or class units.</p>
             </div>
             <button onClick={() => { setEditingFeeHead(null); setShowAddHead(true); }} className="relative z-10 px-10 py-5 bg-white text-indigo-600 rounded-[2rem] font-black text-xs uppercase tracking-widest flex items-center gap-3 shadow-2xl hover:scale-105 active:scale-95 transition-all">
                <Plus size={20}/> Establish Fee Head
             </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
             {feeHeads.map(head => {
               const targetDisplay = head.targetType === 'Global' ? 'Universal' : head.targetType === 'SpecificClass' ? `Grade ${head.targetValue}` : classGroups.find(g => g.id === head.targetValue)?.name || 'Unknown Unit';
               return (
                <div key={head.id} className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm group hover:shadow-2xl transition-all relative overflow-hidden">
                   <div className="flex justify-between items-start mb-10 border-b border-slate-50 pb-6">
                      <div className="flex items-center gap-4">
                        <div className={`p-4 rounded-2xl shadow-sm ${
                            head.type === 'Admission' ? 'bg-amber-50 text-amber-600' :
                            head.type === 'Tuition' ? 'bg-indigo-50 text-indigo-600' :
                            head.type === 'Examination' ? 'bg-rose-50 text-rose-600' :
                            'bg-slate-50 text-slate-600'
                        }`}>
                            {head.type === 'Admission' ? <UserPlus size={24}/> :
                             head.type === 'Tuition' ? <GraduationCap size={24}/> :
                             head.type === 'Examination' ? <FileText size={24}/> : <Info size={24}/>}
                        </div>
                        <div>
                           <h4 className="text-xl font-black text-slate-900 uppercase italic leading-none">{head.name}</h4>
                           <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-2">{head.type} Type</p>
                        </div>
                      </div>
                      <span className="text-[9px] font-black text-slate-300 uppercase tracking-widest">{head.id}</span>
                   </div>
                   <div className="space-y-5">
                      <div className="flex justify-between items-center text-xs font-bold text-slate-400 uppercase tracking-[0.1em]">
                         <span>Base Rate</span>
                         <span className="text-slate-900 font-black text-lg">₹{head.amount.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between items-center text-xs font-bold text-slate-400 uppercase">
                         <span>Billing Unit</span>
                         <span className="text-indigo-600 font-black">{targetDisplay}</span>
                      </div>
                      <div className="flex justify-between items-center text-xs font-bold text-slate-400 uppercase">
                         <span>Cycle</span>
                         <span className="text-slate-900 font-black">{head.frequency}</span>
                      </div>
                   </div>
                   <div className="mt-8 pt-8 border-t border-slate-50 flex gap-2 opacity-0 group-hover:opacity-100 transition-all">
                      <button onClick={() => { setEditingFeeHead(head); setShowAddHead(true); }} className="flex-1 py-3 bg-slate-50 text-[10px] font-black uppercase text-slate-400 rounded-xl hover:bg-indigo-600 hover:text-white transition-all">
                        Edit
                      </button>
                      <button onClick={() => { if(confirm('Permanently delete this fee head?')) setFeeHeads(feeHeads.filter(f => f.id !== head.id)); }} className="p-3 bg-rose-50 text-rose-400 rounded-xl hover:bg-rose-600 hover:text-white transition-all">
                        <Trash2 size={16}/>
                      </button>
                   </div>
                </div>
               );
             })}
          </div>
        </div>
      )}

      {activeTab === 'ledger' && (
        <div className="bg-white rounded-[4rem] border border-slate-100 shadow-sm overflow-hidden animate-in fade-in">
           <div className="p-10 bg-slate-50/30 border-b border-slate-100 flex justify-between items-center">
              <div>
                <h3 className="text-2xl font-black text-slate-900 italic uppercase">Global Transaction Ledger</h3>
                <p className="text-xs font-bold text-slate-400 mt-1 uppercase tracking-widest">Cloud Native Sync • Permanent Audit Trail</p>
              </div>
              <button className="p-3 bg-white border border-slate-200 rounded-2xl text-slate-400 hover:text-indigo-600 transition-all shadow-sm"><Download size={20}/></button>
           </div>
           <div className="overflow-x-auto">
              <table className="w-full text-left whitespace-nowrap">
                 <thead className="bg-slate-50 text-slate-400 text-[10px] font-black uppercase tracking-[0.2em] border-b border-slate-100">
                    <tr>
                       <th className="px-10 py-7">Registry Ref</th>
                       <th className="px-10 py-7">Student Context</th>
                       <th className="px-10 py-7">Settled Amount</th>
                       <th className="px-10 py-7">Sync Mode</th>
                       <th className="px-10 py-7 text-right">Certificate</th>
                    </tr>
                 </thead>
                 <tbody className="divide-y divide-slate-100">
                    {transactions.map(txn => (
                      <tr key={txn.id} className="hover:bg-slate-50/50 transition-colors">
                         <td className="px-10 py-7 font-black text-xs text-indigo-600 font-mono tracking-tighter">#{txn.id}</td>
                         <td className="px-10 py-7">
                            <p className="font-black text-slate-900">{txn.studentName}</p>
                            <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{txn.studentClass}-{txn.studentSection}</p>
                         </td>
                         <td className="px-10 py-7 font-black text-slate-900">₹{txn.amount.toLocaleString()}</td>
                         <td className="px-10 py-7"><span className="px-3 py-1 bg-slate-100 text-slate-600 rounded-lg text-[9px] font-black uppercase tracking-widest border border-slate-200">{txn.mode}</span></td>
                         <td className="px-10 py-7 text-right">
                            <button onClick={() => setShowReceiptModal(txn)} className="p-3 bg-indigo-50 text-indigo-600 rounded-xl hover:bg-indigo-600 hover:text-white transition-all shadow-sm"><FileText size={18}/></button>
                         </td>
                      </tr>
                    ))}
                 </tbody>
              </table>
           </div>
        </div>
      )}

      {/* MODALS */}
      {showAddHead && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in" onClick={() => { setShowAddHead(false); setEditingFeeHead(null); }}>
           <div className="bg-white rounded-[4rem] p-12 max-w-2xl w-full shadow-2xl relative overflow-hidden" onClick={(e) => e.stopPropagation()}>
              <div className="absolute top-0 left-0 w-3 h-full bg-indigo-600"></div>
              <div className="flex justify-between items-start mb-10">
                 <div>
                   <h3 className="text-4xl font-black text-slate-900 tracking-tighter uppercase italic leading-none">{editingFeeHead ? 'Modify Protocol' : 'Establish Fee Head'}</h3>
                   <p className="text-sm font-medium text-slate-400 mt-2 uppercase tracking-widest">Architectural Registry Node</p>
                 </div>
                 <button onClick={() => { setShowAddHead(false); setEditingFeeHead(null); }} className="p-3 hover:bg-slate-100 rounded-full text-slate-400 transition-colors"><X size={32}/></button>
              </div>

              <form onSubmit={(e) => {
                e.preventDefault();
                const fd = new FormData(e.currentTarget);
                const targetType = fd.get('targetType') as any;
                const newHead: FeeHead = {
                  id: editingFeeHead?.id || `FH-${Date.now().toString().slice(-4)}`,
                  name: fd.get('name') as string,
                  type: fd.get('type') as any,
                  amount: Number(fd.get('amount')),
                  frequency: fd.get('frequency') as any,
                  dueDate: fd.get('due') as string,
                  targetType,
                  targetValue: fd.get('targetValue') as string,
                  targetGender: fd.get('targetGender') as any,
                  targetCategory: fd.get('targetCategory') as any,
                };
                
                if (editingFeeHead) {
                  setFeeHeads(feeHeads.map(f => f.id === editingFeeHead.id ? newHead : f));
                } else {
                  setFeeHeads([...feeHeads, newHead]);
                }
                setShowAddHead(false);
                setEditingFeeHead(null);
              }} className="space-y-6">
                 <div className="grid grid-cols-2 gap-8">
                    <div className="space-y-3">
                       <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest px-3">Protocol Label</label>
                       <input name="name" required defaultValue={editingFeeHead?.name} placeholder="e.g. Science Lab Surcharge" className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none focus:bg-white focus:border-indigo-500 transition-all shadow-inner" />
                    </div>
                    <div className="space-y-3">
                       <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest px-3">Registry Type</label>
                       <select name="type" defaultValue={editingFeeHead?.type} className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none focus:bg-white transition-all">
                          <option value="Admission">Admission Fee</option>
                          <option value="Tuition">Tuition Protocol</option>
                          <option value="Examination">Assessment (Exam)</option>
                          <option value="Laboratory">Laboratory Asset</option>
                          <option value="Security-Deposit">Refundable Security</option>
                          <option value="Other">Special Provision</option>
                       </select>
                    </div>
                 </div>

                 <div className="grid grid-cols-2 gap-8">
                    <div className="space-y-3">
                       <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest px-3">Targeting Model</label>
                       <select id="targetTypeSelect" name="targetType" defaultValue={editingFeeHead?.targetType} className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none focus:bg-white transition-all">
                          <option value="Global">Global (All Units)</option>
                          <option value="ClassGroup">Unit (Class Group)</option>
                          <option value="SpecificClass">Node (Specific Class)</option>
                       </select>
                    </div>
                    <div className="space-y-3">
                       <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest px-3">Assign Unit/Node</label>
                       <select name="targetValue" defaultValue={editingFeeHead?.targetValue} className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none focus:bg-white transition-all">
                          <option value="All">Standard Selection</option>
                          <optgroup label="UNITS (GROUPS)">
                             {classGroups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
                          </optgroup>
                          <optgroup label="NODES (CLASSES)">
                             {CLASS_LIST.map(c => <option key={c} value={c}>Grade {c}</option>)}
                          </optgroup>
                       </select>
                    </div>
                 </div>

                 <div className="grid grid-cols-3 gap-6">
                    <div className="space-y-3">
                       <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest px-2">Base Rate (₹)</label>
                       <input name="amount" type="number" defaultValue={editingFeeHead?.amount} required className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none focus:bg-white shadow-inner" />
                    </div>
                    <div className="space-y-3">
                       <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest px-2">Frequency</label>
                       <select name="frequency" defaultValue={editingFeeHead?.frequency} className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none focus:bg-white">
                          <option value="Monthly">Monthly</option>
                          <option value="Yearly">Annual</option>
                          <option value="Half-Yearly">Semi-Annual</option>
                          <option value="One-Time">Single Node</option>
                       </select>
                    </div>
                    <div className="space-y-3">
                       <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest px-2">Due Day</label>
                       <input name="due" type="number" defaultValue={editingFeeHead?.dueDate} placeholder="1-31" className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none focus:bg-white shadow-inner" />
                    </div>
                 </div>

                 <div className="grid grid-cols-2 gap-8 pt-4 border-t border-slate-100">
                    <div className="space-y-2">
                       <label className="text-[9px] font-black text-slate-400 uppercase px-2">Demographic Provision</label>
                       <select name="targetGender" defaultValue={editingFeeHead?.targetGender} className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-[10px] uppercase outline-none">
                          <option value="All">All Genders</option>
                          <option value="Female">Girls Provision</option>
                          <option value="Male">Boys Provision</option>
                       </select>
                    </div>
                    <div className="space-y-2">
                       <label className="text-[9px] font-black text-slate-400 uppercase px-2">Social Segment</label>
                       <select name="targetCategory" defaultValue={editingFeeHead?.targetCategory} className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-[10px] uppercase outline-none">
                          <option value="All">All Categories</option>
                          {SOCIAL_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                       </select>
                    </div>
                 </div>

                 <button type="submit" className="w-full py-6 bg-indigo-600 text-white rounded-[2.5rem] font-black text-lg shadow-2xl hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-4">
                    <Save size={24}/> {editingFeeHead ? 'Update Protocol' : 'Authorize Registry Entry'}
                 </button>
              </form>
           </div>
        </div>
      )}

      {showAddGroup && (
        <div className="fixed inset-0 z-[210] flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in" onClick={() => { setShowAddGroup(false); setEditingGroup(null); }}>
           <div className="bg-white rounded-[4rem] p-12 max-w-xl w-full shadow-2xl relative overflow-hidden" onClick={(e) => e.stopPropagation()}>
              <div className="absolute top-0 left-0 w-3 h-full bg-emerald-600"></div>
              <div className="flex justify-between items-start mb-10">
                 <div>
                   <h3 className="text-3xl font-black text-slate-900 tracking-tighter uppercase italic leading-none">{editingGroup ? 'Modify Unit' : 'Engineer Unit'}</h3>
                   <p className="text-sm font-medium text-slate-400 mt-2 uppercase tracking-widest">Group-Based Architecture</p>
                 </div>
                 <button onClick={() => { setShowAddGroup(false); setEditingGroup(null); }} className="p-3 hover:bg-slate-100 rounded-full text-slate-400 transition-colors"><X size={32}/></button>
              </div>

              <form onSubmit={(e) => {
                e.preventDefault();
                const fd = new FormData(e.currentTarget);
                const selectedClasses = Array.from(fd.getAll('classes') as string[]);
                const newGroup: ClassGroup = {
                  id: editingGroup?.id || `CG-${Date.now().toString().slice(-4)}`,
                  name: fd.get('name') as string,
                  classes: selectedClasses
                };
                
                if (editingGroup) {
                  setClassGroups(classGroups.map(g => g.id === editingGroup.id ? newGroup : g));
                } else {
                  setClassGroups([...classGroups, newGroup]);
                }
                setShowAddGroup(false);
                setEditingGroup(null);
              }} className="space-y-8">
                 <div className="space-y-3">
                    <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest px-3">Unit Label</label>
                    <input name="name" required defaultValue={editingGroup?.name} placeholder="e.g. Science Block Grades" className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none focus:bg-white focus:border-emerald-500 shadow-inner" />
                 </div>
                 <div className="space-y-3">
                    <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest px-3">Constituent Constituents (Select multiple)</label>
                    <div className="grid grid-cols-3 gap-3 p-6 bg-slate-50 border-2 border-slate-100 rounded-[2.5rem] max-h-48 overflow-y-auto scrollbar-hide shadow-inner">
                       {CLASS_LIST.map(c => (
                         <label key={c} className="flex items-center gap-2 p-2 hover:bg-white rounded-lg cursor-pointer group">
                            <input type="checkbox" name="classes" value={c} defaultChecked={editingGroup?.classes.includes(c)} className="w-4 h-4 rounded text-indigo-600" />
                            <span className="text-[10px] font-black text-slate-400 uppercase group-hover:text-indigo-600 transition-colors">{c}</span>
                         </label>
                       ))}
                    </div>
                 </div>
                 <button type="submit" className="w-full py-6 bg-emerald-600 text-white rounded-[2.5rem] font-black text-lg shadow-2xl hover:scale-105 active:scale-95 transition-all">
                   {editingGroup ? 'Apply Re-Configuration' : 'Authorize Unit Node'}
                 </button>
              </form>
           </div>
        </div>
      )}

      {showCollectModal && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in" onClick={() => setShowCollectModal(null)}>
           <div className="bg-white rounded-[4rem] p-12 max-w-2xl w-full shadow-2xl relative overflow-hidden" onClick={(e) => e.stopPropagation()}>
              <div className="absolute top-0 left-0 w-3 h-full bg-indigo-600"></div>
              <div className="flex justify-between items-start mb-12">
                 <div>
                   <h3 className="text-4xl font-black text-slate-900 tracking-tighter italic uppercase leading-none">Receive Payment</h3>
                   <p className="text-sm font-medium text-slate-400 mt-2 uppercase tracking-widest">Identity: {showCollectModal.name} ({showCollectModal.id})</p>
                 </div>
                 <button onClick={() => setShowCollectModal(null)} className="p-3 hover:bg-slate-100 rounded-full text-slate-400 transition-colors"><X size={36}/></button>
              </div>

              <form onSubmit={handleProcessPayment} className="space-y-10">
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-3">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-3">Received Amount (₹)</label>
                       <input 
                         name="amount" type="number" required autoFocus
                         defaultValue={getStudentDues(showCollectModal).dues}
                         className="w-full p-6 bg-slate-50 border-2 border-slate-100 rounded-[2.5rem] font-black text-3xl outline-none focus:bg-white focus:border-indigo-500 transition-all shadow-inner" 
                       />
                    </div>
                    <div className="space-y-3">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-3">Sync Mode</label>
                       <select name="mode" className="w-full p-6 bg-slate-50 border-2 border-slate-100 rounded-[2.5rem] font-black text-sm outline-none focus:bg-white transition-all">
                          <option value="Digital">Digital (UPI/Card)</option>
                          <option value="Cash">Physical Ledger (Cash)</option>
                          <option value="Cheque">Banking Instrument</option>
                       </select>
                    </div>
                 </div>

                 <div className="space-y-3">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-3">Institutional Discount (₹)</label>
                    <input name="discount" type="number" defaultValue={0} className="w-full p-5 bg-indigo-50/50 border-2 border-indigo-100 rounded-[2rem] font-black text-lg outline-none focus:bg-white transition-all shadow-inner" />
                 </div>

                 <div className="p-8 bg-slate-900 rounded-[3rem] text-white relative overflow-hidden shadow-2xl flex items-center justify-between">
                    <div className="absolute top-0 right-0 p-6 opacity-10"><ShieldCheck size={100}/></div>
                    <div className="flex-1 pr-8">
                      <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-2">Protocol Verified</p>
                      <p className="text-sm font-medium text-slate-400 leading-relaxed italic">By committing this entry, you authorize an immutable change to the institutional cloud ledger.</p>
                    </div>
                 </div>

                 <button type="submit" className="w-full py-8 bg-indigo-600 text-white rounded-[3rem] font-black text-xl shadow-[0_30px_60px_-15px_rgba(79,70,229,0.5)] hover:scale-105 active:scale-95 transition-all">
                    COMMIT TRANSACTION §
                 </button>
              </form>
           </div>
        </div>
      )}

      {showReceiptModal && (
        <div className="fixed inset-0 z-[250] flex items-center justify-center bg-slate-950/90 backdrop-blur-xl p-4 no-print animate-in zoom-in-95" onClick={() => setShowReceiptModal(null)}>
           <div className="bg-white rounded-[4rem] p-12 max-w-xl w-full shadow-2xl relative" onClick={(e) => e.stopPropagation()}>
              <button onClick={() => setShowReceiptModal(null)} className="absolute top-8 right-8 p-3 text-slate-400 hover:bg-slate-100 rounded-full transition-all"><X size={32}/></button>
              
              <div className="text-center space-y-6 mb-12">
                 <div className="w-20 h-20 bg-emerald-500 rounded-[2rem] flex items-center justify-center text-white mx-auto shadow-2xl shadow-emerald-500/30">
                    <Check size={48} strokeWidth={4} />
                 </div>
                 <div>
                   <h2 className="text-3xl font-black text-slate-900 uppercase italic tracking-tighter">Settlement Authorized</h2>
                   <p className="text-slate-400 font-bold uppercase tracking-widest text-[10px] mt-1">Transaction Node: {showReceiptModal.id}</p>
                 </div>
              </div>

              <div className="bg-slate-50 rounded-[3rem] p-10 space-y-6 shadow-inner border border-slate-100">
                 <div className="flex justify-between border-b border-slate-200 pb-3">
                    <span className="text-[10px] font-black text-slate-400 uppercase">Registry Node</span>
                    <span className="text-sm font-black text-slate-900">{showReceiptModal.studentName}</span>
                 </div>
                 <div className="flex justify-between border-b border-slate-200 pb-3">
                    <span className="text-[10px] font-black text-slate-400 uppercase">Context</span>
                    <span className="text-sm font-black text-slate-900">Grade {showReceiptModal.studentClass}-{showReceiptModal.studentSection}</span>
                 </div>
                 <div className="flex justify-between border-b border-slate-200 pb-3">
                    <span className="text-[10px] font-black text-slate-400 uppercase">Net Paid</span>
                    <span className="text-2xl font-black text-indigo-600 italic">₹{showReceiptModal.amount.toLocaleString()}</span>
                 </div>
                 <div className="pt-4 flex justify-between items-center">
                    <QrCode size={64} className="text-slate-900" />
                    <div className="text-right">
                       <p className="text-[8px] font-black text-slate-300 uppercase tracking-widest italic">EduNexus Pro Ledger node</p>
                       <p className="text-[10px] font-black text-emerald-600 mt-1 uppercase">VERIFIED STATUS</p>
                    </div>
                 </div>
              </div>

              <div className="grid grid-cols-3 gap-4 mt-12">
                 <button onClick={() => window.print()} className="flex flex-col items-center gap-2 p-6 bg-slate-50 rounded-[2rem] hover:bg-slate-900 hover:text-white transition-all group">
                    <Printer size={24}/>
                    <span className="text-[8px] font-black uppercase tracking-widest">Print</span>
                 </button>
                 <button className="flex flex-col items-center gap-2 p-6 bg-emerald-50 text-emerald-600 rounded-[2rem] hover:bg-emerald-600 hover:text-white transition-all group">
                    <MessageCircle size={24}/>
                    <span className="text-[8px] font-black uppercase tracking-widest">Digital WhatsApp</span>
                 </button>
                 <button className="flex flex-col items-center gap-2 p-6 bg-indigo-50 text-indigo-600 rounded-[2rem] hover:bg-indigo-600 hover:text-white transition-all group">
                    <DownloadCloud size={24}/>
                    <span className="text-[8px] font-black uppercase tracking-widest">Manifest</span>
                 </button>
              </div>
           </div>
        </div>
      )}

      <style>{`
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </div>
  );
};

export default FeesManagement;
