import React, { useState, useEffect, useMemo } from 'react';
import { 
  Layers, Plus, Edit3, Trash2, X, ChevronRight, 
  BookOpen, PlusCircle, Layout, ListPlus, MapPin, 
  Loader2, RefreshCw, UserCheck, Calendar, Clock, 
  Save, ShieldCheck, GraduationCap, Users, BookMarked,
  Printer, Download, ShieldAlert, Sparkles, UserPlus,
  ArrowRight, Landmark, Building2, Book, ChevronDown, ListTree,
  FileText, Zap, MoreHorizontal, CheckCircle2, LayoutGrid,
  Shield, Box, Settings, Rocket, Activity, Info, FileSignature,
  FileCheck, LayoutTemplate, PenTool
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { CLASS_LIST, SECTION_LIST } from '../constants';

interface ClassRecord {
  id: string;
  name: string;
  wing: string;
}

interface SectionRecord {
  id: string;
  class_id: string;
  name: string;
  class_teacher_id?: string;
}

interface SubjectRecord {
  id: string;
  class_id: string;
  name: string;
  code: string;
}

interface StaffRecord {
  id: string;
  name: string;
}

interface ChapterRecord {
  id: string;
  subject_id: string;
  name: string;
  order_index: number;
}

interface LessonRecord {
  id: string;
  chapter_id: string;
  name: string;
  content?: string;
  summary?: string;
}

const AcademicManagement: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'classes' | 'subjects' | 'timetable' | 'assignments' | 'curriculum'>('classes');
  const [classes, setClasses] = useState<ClassRecord[]>([]);
  const [sections, setSections] = useState<SectionRecord[]>([]);
  const [subjects, setSubjects] = useState<SubjectRecord[]>([]);
  const [staff, setStaff] = useState<StaffRecord[]>([]);
  const [timetable, setTimetable] = useState<any[]>([]);
  const [chapters, setChapters] = useState<ChapterRecord[]>([]);
  const [lessons, setLessons] = useState<LessonRecord[]>([]);
  const [loading, setLoading] = useState(true);

  // Selection States
  const [selectedClassId, setSelectedClassId] = useState<string>('');
  const [selectedSectionId, setSelectedSectionId] = useState<string>('');
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>('');

  // Modal States
  const [showAddClass, setShowAddClass] = useState<boolean>(false);
  const [showAddSubject, setShowAddSubject] = useState<boolean>(false);
  const [showAddSection, setShowAddSection] = useState<ClassRecord | null>(null);
  const [showAddChapter, setShowAddChapter] = useState<boolean>(false);
  const [showWriteLesson, setShowWriteLesson] = useState<ChapterRecord | null>(null);

  useEffect(() => {
    fetchCoreData();
  }, []);

  const fetchCoreData = async () => {
    setLoading(true);
    try {
      const { data: cls } = await supabase.from('classes').select('*').order('id');
      const { data: sec } = await supabase.from('sections').select('*').order('name');
      const { data: sub } = await supabase.from('subjects').select('*').order('name');
      const { data: stf } = await supabase.from('staff').select('id, name');
      const { data: tt } = await supabase.from('timetable').select('*, subjects(name), staff(name)');
      const { data: chp } = await supabase.from('chapters').select('*').order('order_index');
      const { data: lsn } = await supabase.from('lessons').select('*');

      setClasses(cls || []);
      setSections(sec || []);
      setSubjects(sub || []);
      setStaff(stf || []);
      setTimetable(tt || []);
      setChapters(chp || []);
      setLessons(lsn || []);
      
      if (cls && cls.length > 0 && !selectedClassId) {
        setSelectedClassId(cls[0].id);
      }
    } catch (err) {
      console.error("Supabase Sync Error:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleAddClass = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const { error } = await supabase.from('classes').insert([{ 
      name: fd.get('name'), 
      wing: fd.get('wing') 
    }]);
    if (!error) { fetchCoreData(); setShowAddClass(false); }
  };

  const handleAddChapter = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedSubjectId) {
      alert("Please select a subject context before deploying a chapter.");
      return;
    }
    const fd = new FormData(e.currentTarget);
    const chapterName = fd.get('name');
    
    try {
      const { error } = await supabase.from('chapters').insert([{ 
        subject_id: selectedSubjectId,
        name: chapterName,
        order_index: (chapters || []).filter(c => c.subject_id === selectedSubjectId).length + 1
      }]);
      
      if (error) {
        console.error("DB Error Detail:", error);
        throw error;
      }
      
      await fetchCoreData();
      setShowAddChapter(false);
      alert("Chapter Registered in Ledger.");
    } catch (err: any) {
      alert("Deployment Failure: " + (err.message || "Database mismatch. Ensure you ran the updated SQL script."));
    }
  };

  const handleWriteLesson = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!showWriteLesson) return;
    const fd = new FormData(e.currentTarget);
    
    try {
      const { error } = await supabase.from('lessons').insert([{ 
        chapter_id: showWriteLesson.id,
        name: fd.get('name'),
        content: fd.get('content'),
        summary: fd.get('summary')
      }]);
      
      if (error) throw error;
      
      await fetchCoreData();
      setShowWriteLesson(null);
      alert("Lesson Module Synchronized.");
    } catch (err: any) {
      alert("Lesson Sync Failure: " + err.message);
    }
  };

  const handleInitializeSchool = async () => {
    if (!confirm('Establish standard academic levels (Nursery to 12)?')) return;
    const setup = [
      { wing: 'Foundation', classes: ['Nursery', 'LKG', 'UKG'] },
      { wing: 'Primary', classes: ['1', '2', '3', '4', '5'] },
      { wing: 'Middle', classes: ['6', '7', '8'] },
      { wing: 'Senior', classes: ['9', '10', '11', '12'] },
    ];
    const toAdd: any[] = [];
    const existingNames = (classes || []).map(c => c.name);
    setup.forEach(group => {
      group.classes.forEach(clsName => {
        if (!existingNames.includes(clsName)) toAdd.push({ name: clsName, wing: group.wing });
      });
    });
    if (toAdd.length === 0) return alert('Levels already synchronized.');
    const { error } = await supabase.from('classes').insert(toAdd);
    if (!error) {
      alert("Institutional Structure established.");
      fetchCoreData();
    }
  };

  const handleQuickDeploySections = async (clsId: string) => {
    const existing = (sections || []).filter(s => s.class_id === clsId).map(s => s.name);
    const targets = ['A', 'B', 'C', 'D'];
    const toAdd = targets.filter(t => !existing.includes(t)).map(t => ({ class_id: clsId, name: t }));
    if (toAdd.length === 0) return alert('Standard sections already active.');
    const { error } = await supabase.from('sections').insert(toAdd);
    if (!error) fetchCoreData();
  };

  const handleAddSubject = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const { error } = await supabase.from('subjects').insert([{ 
      class_id: selectedClassId,
      name: fd.get('name'),
      code: fd.get('code')
    }]);
    if (!error) { fetchCoreData(); setShowAddSubject(false); }
  };

  const handleAddSection = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!showAddSection) return;
    const fd = new FormData(e.currentTarget);
    const { error } = await supabase.from('sections').insert([{ 
      class_id: showAddSection.id,
      name: fd.get('name')
    }]);
    if (!error) { fetchCoreData(); setShowAddSection(null); }
  };

  const handleAssignTeacher = async (sectionId: string, teacherId: string) => {
    const { error } = await supabase.from('sections').update({ class_teacher_id: teacherId }).eq('id', sectionId);
    if (!error) fetchCoreData();
  };

  const handleTimetableSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = {
      class_id: selectedClassId,
      section_id: selectedSectionId,
      subject_id: fd.get('subject_id'),
      teacher_id: fd.get('teacher_id'),
      day: fd.get('day'),
      period_no: parseInt(fd.get('period') as string),
      start_time: fd.get('start'),
      end_time: fd.get('end')
    };
    const { error } = await supabase.from('timetable').upsert([payload]);
    if (!error) fetchCoreData();
    else alert(error.message);
  };

  const WINGS = ['Foundation', 'Primary', 'Middle', 'Senior'];
  const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const PERIODS = [1, 2, 3, 4, 5, 6, 7, 8];

  const groupedClasses = useMemo(() => {
    return WINGS.reduce((acc, wing) => {
      acc[wing] = (classes || []).filter(c => c.wing === wing);
      return acc;
    }, {} as Record<string, ClassRecord[]>);
  }, [classes]);

  const filteredSubjects = useMemo(() => {
    return (subjects || []).filter(sub => sub.class_id === selectedClassId);
  }, [subjects, selectedClassId]);

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-7xl mx-auto min-h-screen">
      {/* HEADER & TABS */}
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-6 no-print">
        <div>
          <h1 className="text-3xl md:text-5xl font-black text-slate-900 italic uppercase tracking-tighter leading-none">Academic Architecture</h1>
          <p className="text-slate-500 font-medium uppercase text-[10px] tracking-widest mt-1 flex items-center gap-2">
            Governance Node • {loading ? <Loader2 size={12} className="animate-spin" /> : <span className="text-emerald-500">Cloud Ledger Active</span>}
          </p>
        </div>
        <div className="flex bg-white p-1 rounded-2xl border border-slate-200 shadow-sm overflow-x-auto scrollbar-hide">
          {[
            { id: 'classes', label: 'Wings & classes', icon: <Layers size={14}/> },
            { id: 'subjects', label: 'Subjects', icon: <BookOpen size={14}/> },
            { id: 'curriculum', label: 'Lessons Plan', icon: <Book size={14}/> },
            { id: 'timetable', label: 'Schedule builder', icon: <Calendar size={14}/> },
            { id: 'assignments', label: 'Teacher assign', icon: <UserCheck size={14}/> },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-6 py-2.5 font-black text-[10px] uppercase tracking-widest flex items-center gap-2 rounded-xl transition-all whitespace-nowrap ${activeTab === tab.id ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-50'}`}
            >
              {tab.icon} {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab Content Rendering */}
      {activeTab === 'classes' && (
        <div className="space-y-12 animate-in fade-in">
          <div className="flex flex-col lg:flex-row justify-between items-center bg-white p-6 md:p-10 rounded-[2.5rem] md:rounded-[4rem] border border-slate-100 shadow-sm gap-6">
             <div className="flex items-center gap-6">
                <div className="w-16 h-16 bg-indigo-50 text-indigo-600 rounded-[1.5rem] flex items-center justify-center shadow-inner">
                   <Building2 size={32} />
                </div>
                <div>
                   <h3 className="text-2xl font-black text-slate-900 uppercase italic">Grade Hub</h3>
                   <p className="text-xs font-medium text-slate-400 uppercase tracking-widest mt-1">Institutional Wing Registry</p>
                </div>
             </div>
             <div className="flex flex-wrap gap-4">
                <button onClick={handleInitializeSchool} className="px-8 py-4 bg-white border-2 border-indigo-100 text-indigo-600 rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 hover:bg-indigo-50 transition-all">
                   <Rocket size={18}/> Initialize All Levels
                </button>
                <button onClick={() => setShowAddClass(true)} className="px-10 py-4 bg-indigo-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 shadow-2xl shadow-indigo-500/30 hover:scale-105 active:scale-95 transition-all">
                   <Plus size={18}/> Establish Level
                </button>
             </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            {WINGS.map(wing => (
              <div key={wing} className="bg-white p-8 md:p-12 rounded-[3.5rem] border border-slate-100 shadow-sm relative overflow-hidden group">
                 <div className="absolute top-0 right-0 p-8 opacity-5 rotate-12 group-hover:scale-110 transition-transform"><Building2 size={120}/></div>
                 <div className="flex justify-between items-center mb-10 border-b border-slate-50 pb-6">
                    <div>
                       <h4 className="text-3xl font-black text-slate-900 italic uppercase">{wing} Wing</h4>
                       <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">{groupedClasses[wing]?.length || 0} Registered Levels</p>
                    </div>
                 </div>
                 
                 <div className="grid grid-cols-1 gap-4">
                    {groupedClasses[wing]?.map(cls => (
                      <div key={cls.id} className="p-6 md:p-8 bg-slate-50 rounded-[2.5rem] border border-slate-100 hover:border-indigo-300 hover:bg-white transition-all group/item hover:shadow-xl">
                         <div className="flex justify-between items-start">
                            <div>
                               <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Grade Identifier</p>
                               <h5 className="text-3xl font-black text-slate-900 italic uppercase mt-1">{cls.name}</h5>
                            </div>
                            <div className="flex gap-2">
                               <button type="button" onClick={() => handleQuickDeploySections(cls.id)} title="Deploy A-D Sections" className="p-3 bg-white border border-slate-200 text-indigo-500 hover:bg-indigo-600 hover:text-white rounded-xl shadow-sm transition-all">
                                  <LayoutTemplate size={18}/>
                                </button>
                               <button type="button" onClick={() => setShowAddSection(cls)} title="Add Custom Section" className="p-3 bg-white border border-slate-200 text-slate-300 hover:text-indigo-600 rounded-xl shadow-sm transition-all">
                                  <Plus size={18}/>
                               </button>
                            </div>
                         </div>
                         <div className="mt-8">
                            <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-3">Active Section Nodes</p>
                            <div className="flex flex-wrap gap-3">
                               {sections.filter(s => s.class_id === cls.id).map(sec => (
                                 <div key={sec.id} className="px-5 py-2 bg-white border border-slate-200 rounded-[1rem] text-sm font-black text-slate-800 uppercase tracking-widest flex items-center gap-2 group/sec shadow-sm hover:border-indigo-400">
                                    <span className="text-indigo-600">§</span> {sec.name}
                                    <button onClick={async () => { if(confirm('Wipe section node?')) await supabase.from('sections').delete().eq('id', sec.id); fetchCoreData(); }} className="opacity-0 group-hover/sec:opacity-100 p-1 text-slate-300 hover:text-rose-500 transition-all"><X size={12}/></button>
                                 </div>
                               ))}
                               {sections.filter(s => s.class_id === cls.id).length === 0 && (
                                 <button onClick={() => handleQuickDeploySections(cls.id)} className="text-[10px] font-black text-indigo-500 uppercase italic hover:underline">
                                    Deploy Sectional Architecture §
                                 </button>
                               )}
                            </div>
                         </div>
                      </div>
                    ))}
                 </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'subjects' && (
        <div className="space-y-8 animate-in fade-in">
          <div className="flex flex-col lg:flex-row justify-between items-center bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm gap-6">
             <div className="flex items-center gap-4">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Select Grade Context</label>
                <select value={selectedClassId} onChange={(e) => setSelectedClassId(e.target.value)} className="px-8 py-4 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none focus:bg-white shadow-inner">
                   {classes.map(c => <option key={c.id} value={c.id}>Grade {c.name}</option>)}
                </select>
             </div>
             <button disabled={classes.length === 0} onClick={() => setShowAddSubject(true)} className="px-10 py-4 bg-indigo-600 disabled:opacity-50 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 shadow-2xl hover:scale-105 active:scale-95 transition-all">
                <Plus size={18}/> Add Subject Node
             </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
             {filteredSubjects.map(sub => (
               <div key={sub.id} className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm group hover:shadow-2xl transition-all relative overflow-hidden">
                  <div className="flex justify-between items-start mb-6">
                     <div className="p-4 bg-indigo-50 text-indigo-600 rounded-2xl group-hover:bg-indigo-600 group-hover:text-white transition-all"><BookOpen size={24}/></div>
                     <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">Code: {sub.code}</span>
                  </div>
                  <h4 className="text-2xl font-black text-slate-900 uppercase italic leading-none">{sub.name}</h4>
                  <div className="mt-8 flex gap-2">
                     <button className="flex-1 py-3 bg-slate-50 text-[10px] font-black text-slate-400 rounded-xl hover:bg-slate-100 uppercase transition-all">Edit</button>
                     <button onClick={async () => { if(confirm('Delete subject node?')) await supabase.from('subjects').delete().eq('id', sub.id); fetchCoreData(); }} className="px-4 py-3 bg-rose-50 text-rose-400 rounded-xl hover:bg-rose-600 hover:text-white transition-all"><Trash2 size={16}/></button>
                  </div>
               </div>
             ))}
          </div>
        </div>
      )}

      {activeTab === 'curriculum' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10 animate-in slide-in-from-bottom-4">
           <div className="lg:col-span-1 space-y-6">
              <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm">
                 <h3 className="text-xl font-black mb-6 uppercase italic text-slate-900">Curriculum Scope</h3>
                 <div className="space-y-4">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Subject Context</label>
                    <select 
                      value={selectedSubjectId} 
                      onChange={(e) => setSelectedSubjectId(e.target.value)}
                      className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-sm outline-none focus:border-indigo-500 shadow-inner"
                    >
                       <option value="">Choose Subject...</option>
                       {subjects.map(s => <option key={s.id} value={s.id}>{s.name} (Grade {classes.find(c => c.id === s.class_id)?.name || '?'})</option>)}
                    </select>
                 </div>
                 {selectedSubjectId ? (
                    <button onClick={() => setShowAddChapter(true)} className="w-full mt-8 py-5 bg-indigo-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl flex items-center justify-center gap-2 hover:scale-[1.02] transition-all">
                       <Plus size={16}/> New Chapter Node
                    </button>
                 ) : (
                    <div className="mt-8 p-4 bg-amber-50 text-amber-600 border border-amber-100 rounded-2xl text-[10px] font-bold uppercase text-center">Identify Subject context</div>
                 )}
              </div>
           </div>

           <div className="lg:col-span-2 space-y-8">
              {(chapters || []).filter(c => c.subject_id === selectedSubjectId).map(chp => (
                <div key={chp.id} className="bg-white rounded-[3rem] border border-slate-100 shadow-sm overflow-hidden group">
                   <div className="p-8 bg-slate-50/50 border-b border-slate-100 flex justify-between items-center group-hover:bg-slate-50 transition-colors">
                      <div className="flex items-center gap-4">
                         <span className="w-10 h-10 bg-slate-900 text-white rounded-xl flex items-center justify-center font-black text-sm italic">{chp.order_index}</span>
                         <h4 className="text-lg font-black text-slate-900 uppercase italic">{chp.name}</h4>
                      </div>
                      <div className="flex gap-2">
                        <button onClick={() => setShowWriteLesson(chp)} className="px-4 py-2 bg-white border border-slate-200 rounded-lg text-[9px] font-black uppercase text-indigo-600 hover:bg-indigo-600 hover:text-white transition-all shadow-sm flex items-center gap-2">
                           <PenTool size={12}/> Write Lesson
                        </button>
                        <button onClick={async () => { if(confirm('Delete chapter?')) await supabase.from('chapters').delete().eq('id', chp.id); fetchCoreData(); }} className="p-2 text-slate-300 hover:text-rose-600 transition-colors"><Trash2 size={16}/></button>
                      </div>
                   </div>
                   <div className="p-6 space-y-3">
                      {(lessons || []).filter(l => l.chapter_id === chp.id).map(lsn => (
                        <div key={lsn.id} className="p-6 bg-white border border-slate-100 rounded-[2rem] flex items-center justify-between group/lsn hover:border-indigo-300 hover:bg-indigo-50/10 transition-all shadow-sm">
                           <div className="flex items-center gap-6">
                              <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600 group-hover/lsn:bg-indigo-600 group-hover/lsn:text-white transition-all">
                                 <FileText size={18}/>
                              </div>
                              <div>
                                 <p className="text-base font-black text-slate-800 leading-none">{lsn.name}</p>
                                 {lsn.summary && <p className="text-[10px] text-slate-400 font-medium mt-1 truncate max-w-sm">{lsn.summary}</p>}
                              </div>
                           </div>
                           <div className="flex gap-2">
                              <button onClick={() => alert("Opening Lesson Content Editor...")} className="p-2 text-slate-300 hover:text-indigo-600 transition-colors"><Edit3 size={16}/></button>
                              <button onClick={async () => { if(confirm('Delete lesson module?')) await supabase.from('lessons').delete().eq('id', lsn.id); fetchCoreData(); }} className="opacity-0 group-hover/lsn:opacity-100 p-2 text-slate-300 hover:text-rose-500 transition-all"><Trash2 size={16}/></button>
                           </div>
                        </div>
                      ))}
                   </div>
                </div>
              ))}
           </div>
        </div>
      )}

      {/* TIMETABLE TAB */}
      {activeTab === 'timetable' && (
        <div className="space-y-12 animate-in fade-in">
           <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm flex flex-wrap gap-8 items-center justify-between">
              <div className="flex gap-4">
                 <select value={selectedClassId} onChange={(e) => setSelectedClassId(e.target.value)} className="px-6 py-3 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-xs outline-none focus:border-indigo-500">
                    {classes.map(c => <option key={c.id} value={c.id}>Grade {c.name}</option>)}
                 </select>
                 <select value={selectedSectionId} onChange={(e) => setSelectedSectionId(e.target.value)} className="px-6 py-3 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-xs outline-none focus:border-indigo-500">
                    <option value="">Select Section...</option>
                    {sections.filter(s => s.class_id === selectedClassId).map(s => <option key={s.id} value={s.id}>§ {s.name}</option>)}
                 </select>
              </div>
              <button onClick={() => window.print()} className="px-8 py-3 bg-slate-900 text-white rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 shadow-xl hover:bg-indigo-600 transition-all">
                 <Printer size={16}/> Print Schedule
              </button>
           </div>
           <div className="bg-white rounded-[3rem] border border-slate-100 shadow-sm overflow-hidden no-print">
              <div className="p-10 border-b border-slate-50">
                 <h3 className="text-xl font-black uppercase italic">Schedule Builder Matrix</h3>
              </div>
              <div className="p-10">
                 <form onSubmit={handleTimetableSubmit} className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-7 gap-4 items-end">
                    <div className="space-y-1"><label className="text-[9px] font-black text-slate-400 uppercase px-2">Day</label>
                       <select name="day" className="w-full p-3 bg-slate-50 rounded-xl font-bold text-xs border border-slate-100 outline-none">{DAYS.map(d => <option key={d} value={d}>{d}</option>)}</select>
                    </div>
                    <div className="space-y-1"><label className="text-[9px] font-black text-slate-400 uppercase px-2">Period</label>
                       <select name="period" className="w-full p-3 bg-slate-50 rounded-xl font-bold text-xs border border-slate-100 outline-none">{PERIODS.map(p => <option key={p} value={p}>#{p}</option>)}</select>
                    </div>
                    <div className="space-y-1"><label className="text-[9px] font-black text-slate-400 uppercase px-2">Subject</label>
                       <select name="subject_id" className="w-full p-3 bg-slate-50 rounded-xl font-bold text-xs border border-slate-100 outline-none">{filteredSubjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}</select>
                    </div>
                    <div className="space-y-1"><label className="text-[9px] font-black text-slate-400 uppercase px-2">Faculty</label>
                       <select name="teacher_id" className="w-full p-3 bg-slate-50 rounded-xl font-bold text-xs border border-slate-100 outline-none">{staff.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}</select>
                    </div>
                    <div className="space-y-1"><label className="text-[9px] font-black text-slate-400 uppercase px-2">Start</label><input name="start" type="time" className="w-full p-3 bg-slate-50 rounded-xl font-bold text-xs border border-slate-100 outline-none" /></div>
                    <div className="space-y-1"><label className="text-[9px] font-black text-slate-400 uppercase px-2">End</label><input name="end" type="time" className="w-full p-3 bg-slate-50 rounded-xl font-bold text-xs border border-slate-100 outline-none" /></div>
                    <button type="submit" className="p-3 bg-indigo-600 text-white rounded-xl font-black text-[10px] uppercase shadow-lg active:scale-95 transition-all">Commit Slot §</button>
                 </form>
              </div>
           </div>
           <div className="overflow-x-auto bg-white rounded-[3rem] border border-slate-100 shadow-sm">
              <table className="w-full border-collapse">
                 <thead className="bg-slate-900 text-white">
                    <tr>
                       <th className="p-6 text-center border-r border-slate-800 text-[10px] font-black uppercase tracking-[0.2em]">DAY / PRD</th>
                       {PERIODS.map(p => <th key={p} className="p-6 text-center border-r border-slate-800 text-[10px] font-black uppercase">Period {p}</th>)}
                    </tr>
                 </thead>
                 <tbody className="divide-y divide-slate-100">
                    {DAYS.map(day => (
                      <tr key={day} className="hover:bg-slate-50/50 transition-colors">
                         <td className="p-6 bg-slate-50 text-slate-900 font-black text-xs uppercase border-r border-slate-100">{day}</td>
                         {PERIODS.map(p => {
                           const slot = (timetable || []).find(t => t.day === day && t.period_no === p && t.class_id === selectedClassId && t.section_id === selectedSectionId);
                           return (
                             <td key={p} className="p-4 border-r border-slate-50 text-center min-w-[140px]">
                                {slot ? (
                                  <div className="bg-indigo-50 p-4 rounded-[1.5rem] border border-indigo-100 group relative">
                                     <button onClick={async () => { if(confirm('Delete slot?')) await supabase.from('timetable').delete().eq('id', slot.id); fetchCoreData(); }} className="absolute -top-2 -right-2 w-6 h-6 bg-rose-500 text-white rounded-full opacity-0 group-hover:opacity-100 flex items-center justify-center shadow-lg transition-all"><X size={12}/></button>
                                     <p className="text-[10px] font-black text-indigo-700 uppercase leading-tight">{slot.subjects?.name || 'Unknown'}</p>
                                     <p className="text-[8px] font-bold text-slate-400 uppercase mt-1 italic">{slot.staff?.name || 'N/A'}</p>
                                     <p className="text-[7px] font-black text-indigo-300 mt-2 uppercase tracking-tighter">{slot.start_time} - {slot.end_time}</p>
                                  </div>
                                ) : <div className="text-[8px] font-black text-slate-200 uppercase italic tracking-widest">Free Node</div>}
                             </td>
                           );
                         })}
                      </tr>
                    ))}
                 </tbody>
              </table>
           </div>
        </div>
      )}

      {/* ASSIGNMENTS TAB */}
      {activeTab === 'assignments' && (
        <div className="space-y-12 animate-in fade-in">
           <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm flex flex-wrap gap-8 items-center">
              <div className="flex gap-4">
                 <select value={selectedClassId} onChange={(e) => setSelectedClassId(e.target.value)} className="px-8 py-4 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none focus:border-indigo-500">
                    {classes.map(c => <option key={c.id} value={c.id}>Grade {c.name}</option>)}
                 </select>
              </div>
           </div>
           <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              {sections.filter(s => s.class_id === selectedClassId).map(sec => (
                <div key={sec.id} className="bg-white p-10 rounded-[3.5rem] border border-slate-100 shadow-sm relative overflow-hidden group">
                   <div className="absolute top-0 right-0 p-8 opacity-5"><UserCheck size={100}/></div>
                   <h3 className="text-3xl font-black text-slate-900 italic uppercase mb-10 pb-6 border-b border-slate-50">§ {sec.name} <span className="text-slate-400 not-italic ml-2 text-base">Node</span></h3>
                   <div className="p-8 bg-slate-950 rounded-[2.5rem] text-white shadow-2xl relative overflow-hidden group/card">
                      <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform"><Shield size={48} className="text-indigo-400"/></div>
                      <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-4">Authority: Class Teacher</p>
                      <select 
                        value={sec.class_teacher_id || ''} 
                        onChange={(e) => handleAssignTeacher(sec.id, e.target.value)}
                        className="w-full p-5 bg-white/5 border border-white/10 rounded-[1.5rem] font-black text-sm outline-none text-white focus:bg-white/10 transition-all"
                      >
                         <option value="" className="text-slate-900">Assign Coordinator...</option>
                         {staff.map(s => <option key={s.id} value={s.id} className="text-slate-900">{s.name}</option>)}
                      </select>
                      <p className="text-[9px] text-slate-500 mt-4 italic uppercase tracking-tighter">Node oversees attendance and behavioral logs for Section {sec.name}.</p>
                   </div>
                </div>
              ))}
           </div>
        </div>
      )}

      {/* MODALS RENDERING */}
      {showAddClass && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in" onClick={() => setShowAddClass(false)}>
           <div className="bg-white rounded-[3.5rem] p-12 max-w-xl w-full shadow-2xl relative overflow-hidden" onClick={(e) => e.stopPropagation()}>
              <div className="absolute top-0 left-0 w-3 h-full bg-indigo-600"></div>
              <div className="flex justify-between items-start mb-10">
                 <div><h3 className="text-3xl font-black text-slate-900 uppercase italic leading-none">Establish Level</h3></div>
                 <button onClick={() => setShowAddClass(false)} className="p-3 hover:bg-slate-100 rounded-full text-slate-400 transition-colors"><X size={32}/></button>
              </div>
              <form onSubmit={handleAddClass} className="space-y-8">
                 <div className="space-y-3">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-3">Institutional Wing</label>
                    <select name="wing" required className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none focus:border-indigo-500">
                       {WINGS.map(w => <option key={w} value={w}>{w} Wing</option>)}
                    </select>
                 </div>
                 <div className="space-y-3">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-3">Grade Designation</label>
                    <input name="name" required placeholder="e.g. 10" className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-lg outline-none focus:bg-white focus:border-indigo-500 shadow-inner" />
                 </div>
                 <button type="submit" className="w-full py-6 bg-indigo-600 text-white rounded-[2.5rem] font-black text-lg shadow-2xl hover:scale-[1.02] active:scale-95 transition-all">Authorize Node</button>
              </form>
           </div>
        </div>
      )}

      {showAddSubject && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in" onClick={() => setShowAddSubject(false)}>
           <div className="bg-white rounded-[3.5rem] p-12 max-w-xl w-full shadow-2xl relative overflow-hidden" onClick={(e) => e.stopPropagation()}>
              <div className="absolute top-0 left-0 w-3 h-full bg-indigo-600"></div>
              <div className="flex justify-between items-start mb-10">
                 <div><h3 className="text-3xl font-black text-slate-900 tracking-tighter uppercase italic">Register Subject</h3></div>
                 <button onClick={() => setShowAddSubject(false)} className="p-3 hover:bg-slate-100 rounded-full text-slate-400 transition-colors"><X size={32}/></button>
              </div>
              <form onSubmit={handleAddSubject} className="space-y-8">
                 <div className="space-y-3">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-3">Subject Identity</label>
                    <input name="name" required placeholder="e.g. Mathematics" className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-lg outline-none focus:bg-white focus:border-indigo-500 shadow-inner" />
                 </div>
                 <div className="space-y-3">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-3">Institutional Code</label>
                    <input name="code" required placeholder="e.g. MATH-10" className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none uppercase focus:border-indigo-500 shadow-inner" />
                 </div>
                 <button type="submit" className="w-full py-6 bg-indigo-600 text-white rounded-[2.5rem] font-black text-lg shadow-2xl active:scale-95 transition-all">Authorize Subject</button>
              </form>
           </div>
        </div>
      )}

      {showAddChapter && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in" onClick={() => setShowAddChapter(false)}>
           <div className="bg-white rounded-[3.5rem] p-12 max-w-xl w-full shadow-2xl relative overflow-hidden" onClick={(e) => e.stopPropagation()}>
              <div className="absolute top-0 left-0 w-3 h-full bg-indigo-600"></div>
              <div className="flex justify-between items-start mb-12">
                 <div>
                   <h3 className="text-5xl font-black text-slate-900 tracking-tighter uppercase italic leading-none">DEPLOY CHAPTER</h3>
                 </div>
                 <button onClick={() => setShowAddChapter(false)} className="p-3 hover:bg-slate-100 rounded-full text-slate-400 transition-colors"><X size={44}/></button>
              </div>
              <form onSubmit={handleAddChapter} className="space-y-12">
                 <div className="space-y-4">
                    <label className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] px-4">CHAPTER LABEL</label>
                    <input name="name" required autoFocus placeholder="e.g. Intro to Algebra" className="w-full p-8 bg-slate-50 border-2 border-slate-100 rounded-[2.5rem] font-black text-2xl outline-none focus:bg-white focus:border-indigo-500 transition-all shadow-inner" />
                 </div>
                 <button type="submit" className="w-full py-7 bg-indigo-600 text-white rounded-full font-black text-xl shadow-[0_20px_40px_-10px_rgba(79,70,229,0.5)] hover:scale-[1.02] active:scale-95 transition-all">Register Chapter</button>
              </form>
           </div>
        </div>
      )}

      {showWriteLesson && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in" onClick={() => setShowWriteLesson(null)}>
           <div className="bg-white rounded-[4rem] p-12 md:p-16 max-w-4xl w-full shadow-2xl relative overflow-hidden" onClick={(e) => e.stopPropagation()}>
              <div className="absolute top-0 left-0 w-3 h-full bg-emerald-600"></div>
              <div className="flex justify-between items-start mb-12">
                 <div>
                    <h3 className="text-5xl font-black text-slate-900 tracking-tighter uppercase italic leading-none">LESSON ARCHITECT</h3>
                    <p className="text-sm font-bold text-slate-400 mt-4 uppercase tracking-widest flex items-center gap-2">
                       <Zap size={18} className="text-amber-500"/> TARGET: {showWriteLesson.name}
                    </p>
                 </div>
                 <button onClick={() => setShowWriteLesson(null)} className="p-3 hover:bg-slate-100 rounded-full text-slate-400 transition-colors"><X size={44}/></button>
              </div>
              <form onSubmit={handleWriteLesson} className="space-y-8">
                 <div className="space-y-3">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-4">MODULE IDENTITY</label>
                    <input name="name" required placeholder="e.g. Fundamental Theorem" className="w-full p-6 bg-slate-50 border-2 border-slate-100 rounded-[2.5rem] font-black text-lg outline-none focus:bg-white focus:border-emerald-500 shadow-inner" />
                 </div>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-3">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-4">SUMMARY</label>
                       <textarea name="summary" rows={3} placeholder="Briefly define the learning outcomes..." className="w-full p-6 bg-slate-50 border-2 border-slate-100 rounded-[2.5rem] font-black text-sm outline-none resize-none focus:bg-white h-32"></textarea>
                    </div>
                    <div className="space-y-3">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-4">CONTENT / NOTES</label>
                       <textarea name="content" rows={3} placeholder="Detailed academic notes for students..." className="w-full p-6 bg-slate-50 border-2 border-slate-100 rounded-[2.5rem] font-black text-sm outline-none resize-none focus:bg-white h-32"></textarea>
                    </div>
                 </div>
                 <button type="submit" className="w-full py-8 bg-emerald-600 text-white rounded-full font-black text-xl shadow-[0_20px_40px_-10px_rgba(16,185,129,0.5)] hover:bg-emerald-700 hover:scale-[1.02] active:scale-95 transition-all uppercase tracking-widest">
                    Synchronize Module §
                 </button>
              </form>
           </div>
        </div>
      )}

      {showAddSection && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in" onClick={() => setShowAddSection(null)}>
           <div className="bg-white rounded-[3.5rem] p-12 max-w-md w-full shadow-2xl relative overflow-hidden" onClick={(e) => e.stopPropagation()}>
              <div className="absolute top-0 left-0 w-3 h-full bg-emerald-600"></div>
              <div className="flex justify-between items-start mb-10">
                 <div>
                   <h3 className="text-3xl font-black text-slate-900 tracking-tighter uppercase italic leading-none">Deploy Section</h3>
                   <p className="text-sm font-medium text-slate-400 mt-2 uppercase tracking-widest">Target: Grade {showAddSection.name}</p>
                 </div>
                 <button onClick={() => setShowAddSection(null)} className="p-3 hover:bg-slate-100 rounded-full text-slate-400 transition-colors"><X size={32}/></button>
              </div>
              <form onSubmit={handleAddSection} className="space-y-8">
                 <div className="space-y-3">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-3">Identity §</label>
                    <input name="name" required placeholder="e.g. A" className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-5xl text-center uppercase outline-none focus:bg-white focus:border-emerald-500 shadow-inner" />
                 </div>
                 <button type="submit" className="w-full py-6 bg-emerald-600 text-white rounded-[2.5rem] font-black text-lg shadow-2xl active:scale-95 transition-all">Establish § Node</button>
              </form>
           </div>
        </div>
      )}

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #e2e8f0; border-radius: 10px; }
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </div>
  );
};

export default AcademicManagement;
