import React, { useState, useMemo } from 'react';
import { 
  Heart, Wallet, HandHelping, Leaf, Dumbbell, Theater, 
  Target, IndianRupee, Rocket, ShieldCheck, Calendar,
  Plus, X, Send, Filter, ChevronRight, TrendingUp,
  Landmark, Sparkles, Quote, Award, Globe, Users,
  CheckCircle2, Info, ArrowUpRight, FileText, BellRing, Share2, 
  Handshake, Building2
} from 'lucide-react';

interface PhilanthropyActivity {
  id: string;
  type: 'Charity' | 'Donation' | 'Environmental' | 'Sports' | 'Drama';
  title: string;
  description: string;
  amount?: number;
  isPrivileged?: boolean; // Fund for underprivileged students
  date: string;
  impact?: string;
  donorName?: string;
}

const PhilanthropyHub: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'overview' | 'donations' | 'activities'>('overview');
  const [showDonationModal, setShowDonationModal] = useState<boolean | 'privileged'>(false);
  const [showActivityModal, setShowActivityModal] = useState(false);

  const [activities, setActivities] = useState<PhilanthropyActivity[]>([
    { id: '1', type: 'Donation', title: 'Merit-Aid Scholarship', description: 'Monthly tuition coverage for 12 students in the rural block.', amount: 120000, isPrivileged: true, date: '2023-10-15', impact: '12 Futures Secured', donorName: 'Global Alumni Assoc.' },
    { id: '2', type: 'Environmental', title: 'Vertical Garden Installation', description: 'Eco-friendly green walls in the primary wing cafeteria.', date: '2023-09-20', impact: '2.4 Tons CO2 Offset', donorName: 'EcoTrust India' },
    { id: '3', type: 'Charity', title: 'Community Literacy Drive', description: 'Teaching basic numeracy to local vocational staff families.', date: '2023-11-01', impact: '84 Adults Educated' },
    { id: '4', type: 'Sports', title: 'Indoor Badminton Arena', description: 'Rubberized flooring and equipment for the new court.', date: '2023-12-05', amount: 350000, impact: 'Pro-grade Facilities' },
    { id: '5', type: 'Drama', title: 'Digital Arts Masterclass', description: 'Guest workshop by professional theater directors.', date: '2024-01-10', amount: 45000, impact: '500 Students Engaged' }
  ]);

  const stats = useMemo(() => {
    const totalDonations = activities.reduce((acc, a) => acc + (a.amount || 0), 0);
    const privilegedFund = activities.filter(a => a.isPrivileged).reduce((acc, a) => acc + (a.amount || 0), 0);
    return {
      totalDonations,
      privilegedFund,
      totalImpact: activities.length,
      livesTouched: 1240 // Mock data
    };
  }, [activities]);

  const handleAddDonation = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const newActivity: PhilanthropyActivity = {
      id: Date.now().toString(),
      type: 'Donation',
      title: formData.get('title') as string,
      description: formData.get('description') as string,
      amount: Number(formData.get('amount')),
      isPrivileged: formData.get('isPrivileged') === 'on',
      donorName: formData.get('donor') as string,
      date: new Date().toISOString().split('T')[0],
      impact: formData.get('impact') as string
    };
    setActivities([newActivity, ...activities]);
    setShowDonationModal(false);
    alert('Donation successfully registered in the institutional ledger.');
  };

  const handleAddActivity = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const newActivity: PhilanthropyActivity = {
      id: Date.now().toString(),
      type: formData.get('type') as any,
      title: formData.get('title') as string,
      description: formData.get('description') as string,
      date: new Date().toISOString().split('T')[0],
      impact: formData.get('impact') as string
    };
    setActivities([newActivity, ...activities]);
    setShowActivityModal(false);
    alert('Impact activity has been logged and published to the portal.');
  };

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-6 no-print">
        <div>
          <h1 className="text-4xl font-black text-slate-900 italic uppercase tracking-tighter">Philanthropy & Social Impact</h1>
          <p className="text-slate-500 font-medium italic">Institutional contributions to social equity, ecology, and cultural heritage.</p>
        </div>
        <div className="flex bg-white p-1 rounded-2xl border border-slate-200 shadow-sm overflow-x-auto">
          {[
            { id: 'overview', label: 'Impact Overview', icon: <Globe size={16} /> },
            { id: 'donations', label: 'Donation Registry', icon: <Landmark size={16} /> },
            { id: 'activities', label: 'Impact Domains', icon: <Rocket size={16} /> },
          ].map(tab => (
            <button 
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`px-8 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 whitespace-nowrap ${activeSubTab === tab.id ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}
            >
              {tab.icon} {tab.label}
            </button>
          ))}
        </div>
      </div>

      {activeSubTab === 'overview' && (
        <div className="space-y-10 animate-in slide-in-from-bottom-4 duration-500">
           <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm relative overflow-hidden group hover:shadow-xl transition-all">
                 <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:scale-110 transition-transform"><Heart size={80}/></div>
                 <p className="text-[10px] font-black text-rose-500 uppercase tracking-widest mb-1">Fiscal Equity Raised</p>
                 <h3 className="text-3xl font-black text-slate-900">₹{(stats.totalDonations / 100000).toFixed(2)}L</h3>
                 <p className="text-[10px] font-bold text-slate-400 mt-2 uppercase flex items-center gap-1"><ArrowUpRight size={12}/> Global Contributions</p>
              </div>
              <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm relative overflow-hidden group hover:shadow-xl transition-all">
                 <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:scale-110 transition-transform"><Target size={80}/></div>
                 <p className="text-[10px] font-black text-amber-600 uppercase tracking-widest mb-1">Privileged Fund</p>
                 <h3 className="text-3xl font-black text-slate-900">₹{(stats.privilegedFund / 100000).toFixed(2)}L</h3>
                 <p className="text-[10px] font-bold text-slate-400 mt-2 uppercase">Aiding Disadvantaged Stars</p>
              </div>
              <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm relative overflow-hidden group hover:shadow-xl transition-all">
                 <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:scale-110 transition-transform"><Users size={80}/></div>
                 <p className="text-[10px] font-black text-indigo-600 uppercase tracking-widest mb-1">Lives Impacted</p>
                 <h3 className="text-3xl font-black text-slate-900">{stats.livesTouched.toLocaleString()}</h3>
                 <p className="text-[10px] font-bold text-slate-400 mt-2 uppercase tracking-tight">Verified Reach Metric</p>
              </div>
              <div className="bg-indigo-600 p-8 rounded-[2.5rem] text-white shadow-2xl shadow-indigo-500/20 flex flex-col justify-between group overflow-hidden">
                 <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:rotate-12 transition-transform"><Sparkles size={60}/></div>
                 <p className="text-[10px] font-black text-indigo-200 uppercase tracking-widest">Active Community</p>
                 <h3 className="text-3xl font-black">Impact Node</h3>
                 <button onClick={() => alert('Generating full institutional social impact audit...')} className="mt-4 py-2.5 bg-white/10 rounded-xl text-[10px] font-black uppercase tracking-widest border border-white/5 hover:bg-white/20 transition-all">Audit Impact Ledger</button>
              </div>
           </div>

           <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-8">
                 <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm relative overflow-hidden">
                    <div className="flex justify-between items-center mb-10">
                       <h3 className="text-2xl font-black text-slate-900 flex items-center gap-3"><HandHelping className="text-rose-500" /> Institution Impact Ledger</h3>
                       <div className="flex gap-2">
                          <button onClick={() => alert('Opening filter presets...')} className="p-2.5 bg-slate-50 text-slate-400 rounded-xl hover:text-indigo-600 transition-all"><Filter size={18}/></button>
                       </div>
                    </div>
                    <div className="space-y-6">
                       {activities.slice(0, 3).map(act => (
                         <div key={act.id} className="p-8 bg-slate-50 rounded-[2.5rem] border border-slate-100 flex items-start justify-between group hover:bg-white hover:border-indigo-200 transition-all hover:shadow-2xl">
                            <div className="flex gap-8">
                               <div className={`w-16 h-16 rounded-[1.5rem] flex items-center justify-center text-white shadow-2xl shrink-0 group-hover:scale-105 transition-transform ${
                                 act.type === 'Charity' ? 'bg-rose-500' : 
                                 act.type === 'Donation' ? 'bg-emerald-500' : 
                                 act.type === 'Environmental' ? 'bg-teal-500' : 
                                 act.type === 'Sports' ? 'bg-amber-500' : 'bg-purple-500'
                               }`}>
                                  {act.type === 'Charity' ? <Heart size={28}/> : 
                                   act.type === 'Donation' ? <Wallet size={28}/> : 
                                   act.type === 'Environmental' ? <Leaf size={28}/> : 
                                   act.type === 'Sports' ? <Dumbbell size={28}/> : <Theater size={28}/>}
                               </div>
                               <div>
                                  <div className="flex flex-wrap items-center gap-3">
                                     <h4 className="text-xl font-black text-slate-900 tracking-tight">{act.title}</h4>
                                     <span className="text-[10px] font-black px-3 py-1 bg-white border border-slate-200 rounded-full text-slate-400 uppercase tracking-widest">{act.type}</span>
                                  </div>
                                  <p className="text-sm font-medium text-slate-500 mt-2 leading-relaxed max-w-lg">{act.description}</p>
                                  <div className="flex flex-wrap items-center gap-6 mt-6 pt-6 border-t border-slate-200/50 text-[10px] font-black uppercase tracking-[0.1em]">
                                     <span className="flex items-center gap-2 text-slate-400 bg-white px-3 py-1.5 rounded-xl shadow-sm"><Calendar size={14}/> {act.date}</span>
                                     {act.impact && <span className="flex items-center gap-2 text-indigo-600 bg-indigo-50 px-3 py-1.5 rounded-xl shadow-sm"><Rocket size={14}/> {act.impact}</span>}
                                     {act.isPrivileged && <span className="flex items-center gap-2 text-rose-500 bg-rose-50 px-3 py-1.5 rounded-xl shadow-sm border border-rose-100"><ShieldCheck size={14}/> Privileged Fund</span>}
                                  </div>
                               </div>
                            </div>
                            <button onClick={() => alert(`Opening detailed report for: ${act.title}`)} className="p-3 opacity-0 group-hover:opacity-100 bg-indigo-50 text-indigo-600 rounded-2xl transition-all hover:bg-indigo-600 hover:text-white"><ChevronRight size={24}/></button>
                         </div>
                       ))}
                    </div>
                 </div>
              </div>

              <div className="space-y-8">
                 <div className="bg-slate-900 p-12 rounded-[4rem] text-white shadow-2xl relative overflow-hidden group border border-white/5">
                    <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform"><Building2 size={120} /></div>
                    <div className="bg-indigo-500/20 text-indigo-400 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] inline-block mb-6">Financial Bridge</div>
                    <h3 className="text-4xl font-black mb-6 leading-[1.1] tracking-tighter">Contribution Console</h3>
                    <p className="text-sm text-slate-400 leading-relaxed mb-10 font-medium max-w-[280px]">Support the upcoming sports complex or fund a scholarship for our top performers who need aid.</p>
                    
                    <div className="space-y-4 relative z-10">
                       <button onClick={() => setShowActivityModal(true)} className="w-full py-6 bg-indigo-600 rounded-[2.5rem] font-black text-sm uppercase tracking-widest flex items-center justify-center gap-4 hover:bg-indigo-700 transition-all shadow-2xl shadow-indigo-900/50 active:scale-95 group/btn">
                          <Handshake size={20} className="group-hover/btn:rotate-12 transition-transform" /> NEW CHARITY WORK
                       </button>
                       <button onClick={() => setShowDonationModal(true)} className="w-full py-6 bg-white/5 hover:bg-white/10 rounded-[2.5rem] font-black text-sm uppercase tracking-widest flex items-center justify-center gap-4 transition-all border border-white/10 active:scale-95 group/btn">
                          <Wallet size={20} className="group-hover/btn:scale-110 transition-transform" /> ACCEPT DONATION
                       </button>
                    </div>
                 </div>

                 <div className="bg-rose-600 p-10 rounded-[3.5rem] text-white shadow-2xl shadow-rose-500/40 relative overflow-hidden group border-2 border-rose-500/50">
                    <div className="absolute top-4 right-6 opacity-20 transition-transform duration-700 group-hover:rotate-12 group-hover:scale-110">
                       <Quote size={80} fill="currentColor" className="text-white" />
                    </div>
                    
                    <div className="relative z-10">
                      <h4 className="text-3xl font-black mb-4 tracking-tighter">Privileged Student Fund</h4>
                      <p className="text-sm text-rose-50 font-medium mb-12 leading-relaxed opacity-90 max-w-[280px]">Direct support for tuition and kits for high-achieving students from low-income backgrounds.</p>
                      
                      <div className="bg-rose-700/40 p-8 rounded-[2.5rem] border border-white/10 mb-10 backdrop-blur-sm shadow-inner">
                         <div className="flex justify-between items-center mb-4">
                            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-rose-200">Fund Target</span>
                            <span className="text-2xl font-black tracking-tight text-white">₹15,00,000</span>
                         </div>
                         <div className="w-full h-2.5 bg-rose-900/40 rounded-full overflow-hidden shadow-inner">
                            <div className="h-full bg-white rounded-full shadow-[0_0_20px_rgba(255,255,255,0.5)] transition-all duration-1000" style={{width: `${Math.min((stats.privilegedFund / 1500000) * 100, 100)}%`}}></div>
                         </div>
                      </div>
                      
                      <button 
                        onClick={() => setShowDonationModal('privileged')} 
                        className="w-full py-6 bg-white text-rose-600 rounded-[2.5rem] font-black text-sm uppercase tracking-[0.2em] hover:bg-rose-50 transition-all active:scale-95 shadow-2xl shadow-rose-900/20"
                      >
                         CONTRIBUTE NOW
                      </button>
                    </div>
                 </div>
              </div>
           </div>
        </div>
      )}

      {activeSubTab === 'donations' && (
        <div className="space-y-8 animate-in fade-in duration-300">
          <div className="bg-white rounded-[3.5rem] border border-slate-100 shadow-sm overflow-hidden">
            <div className="p-10 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
               <h3 className="text-xl font-black text-slate-900 uppercase italic tracking-tighter">Institutional Donation Registry</h3>
               <div className="flex gap-4">
                  <button onClick={() => setShowDonationModal(true)} className="px-8 py-4 bg-indigo-600 text-white rounded-[1.5rem] text-xs font-black uppercase tracking-widest flex items-center gap-2 shadow-xl shadow-indigo-500/20">
                     <Plus size={18}/> Accept New Entry
                  </button>
               </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-slate-50 text-slate-400 text-[10px] font-black uppercase tracking-[0.2em]">
                  <tr>
                    <th className="px-10 py-7">Donor Specification</th>
                    <th className="px-10 py-7">Fiscal Impact</th>
                    <th className="px-10 py-7">Target Allocation</th>
                    <th className="px-10 py-7 text-right">Verification</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {activities.filter(a => a.type === 'Donation').map(don => (
                    <tr key={don.id} className="hover:bg-slate-50/50 transition-colors group">
                      <td className="px-10 py-7">
                        <div className="flex items-center gap-5">
                          <div className="w-14 h-14 bg-indigo-50 rounded-[1.5rem] flex items-center justify-center text-indigo-600 font-black text-2xl shadow-sm">{don.donorName ? don.donorName[0] : 'A'}</div>
                          <div>
                            <p className="text-lg font-black text-slate-900 leading-none">{don.donorName || 'Anonymous Donor'}</p>
                            <p className="text-[10px] font-bold text-slate-400 uppercase mt-1.5">{don.title}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-10 py-7">
                         <p className="text-xl font-black text-slate-800 leading-tight">₹{don.amount?.toLocaleString()}</p>
                         <p className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest mt-1">Processed: {don.date}</p>
                      </td>
                      <td className="px-10 py-7">
                         <span className={`px-4 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest ${don.isPrivileged ? 'bg-rose-100 text-rose-600 border border-rose-200' : 'bg-indigo-50 text-indigo-600 border border-indigo-100'}`}>{don.isPrivileged ? 'Privileged Student Fund' : 'General Institution Fund'}</span>
                      </td>
                      <td className="px-10 py-7 text-right">
                         <div className="flex items-center justify-end gap-4">
                            <button onClick={() => alert('Downloading official tax receipt...')} className="p-2 text-slate-300 hover:text-indigo-600 transition-colors"><FileText size={18}/></button>
                            <div className="flex items-center gap-2 text-emerald-500 font-black text-[10px] uppercase whitespace-nowrap">
                               <CheckCircle2 size={16}/> Ledger Verified
                            </div>
                         </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {activeSubTab === 'activities' && (
        <div className="space-y-10 animate-in fade-in duration-300">
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                { type: 'Environmental', icon: <Leaf size={32}/>, color: 'emerald', label: 'Ecology & Green Campus', desc: 'Solar transition, waste recycling, and bio-diversity drives.' },
                { type: 'Sports', icon: <Dumbbell size={32}/>, color: 'amber', label: 'Athletic Impact', desc: 'Stadium upgrades, kit distribution, and alumni tournaments.' },
                { type: 'Drama', icon: <Theater size={32}/>, color: 'purple', label: 'Cultural Heritage', desc: 'Arts masterclasses, auditorium tech, and heritage preservation.' }
              ].map(domain => (
                <div key={domain.type} className={`bg-white p-10 rounded-[3.5rem] border-2 border-${domain.color}-50 shadow-sm hover:shadow-2xl transition-all group overflow-hidden relative`}>
                   <div className={`absolute top-0 right-0 w-32 h-32 bg-${domain.color}-50 rounded-bl-[4rem] -translate-y-4 translate-x-4 flex items-center justify-center opacity-40 group-hover:opacity-100 transition-opacity`}>
                      <div className={`text-${domain.color}-500`}>{domain.icon}</div>
                   </div>
                   <h3 className={`text-2xl font-black text-slate-900 mb-2 leading-tight pr-12 group-hover:text-${domain.color}-600 transition-colors`}>{domain.label}</h3>
                   <p className="text-sm font-medium text-slate-400 mb-8 leading-relaxed italic">{domain.desc}</p>
                   <div className="space-y-4 mb-8">
                      {activities.filter(a => a.type === domain.type).slice(0, 2).map(act => (
                        <div key={act.id} className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                           <p className="text-xs font-black text-slate-800 truncate">{act.title}</p>
                           <p className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter mt-1">{act.impact}</p>
                        </div>
                      ))}
                      {activities.filter(a => a.type === domain.type).length === 0 && (
                        <p className="text-[10px] font-black text-slate-300 uppercase italic">No active logs in this domain.</p>
                      )}
                   </div>
                   <button onClick={() => setShowActivityModal(true)} className={`w-full py-4 bg-${domain.color}-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-${domain.color}-200/50 hover:scale-[1.02] transition-all`}>
                      Log {domain.type} Action
                   </button>
                </div>
              ))}
           </div>
        </div>
      )}

      {showDonationModal && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-900/80 backdrop-blur-md p-4 animate-in fade-in" onClick={() => setShowDonationModal(false)}>
          <div className="bg-white rounded-[4rem] p-12 max-w-2xl w-full shadow-2xl relative overflow-hidden" onClick={(e) => e.stopPropagation()}>
             <div className={`absolute top-0 left-0 w-3 h-full ${showDonationModal === 'privileged' ? 'bg-rose-600' : 'bg-indigo-600'}`}></div>
             <div className="flex justify-between items-start mb-12">
                <div>
                   <h3 className="text-4xl font-black text-slate-900 tracking-tighter">Accept Donation</h3>
                   <p className="text-sm text-slate-500 font-medium italic mt-1">Accept contributions for general growth or specific aid.</p>
                </div>
                <button onClick={() => setShowDonationModal(false)} className="p-3 hover:bg-slate-100 rounded-full text-slate-400 transition-colors"><X size={36}/></button>
             </div>

             <form onSubmit={handleAddDonation} className="space-y-8">
                <div className="grid grid-cols-2 gap-8">
                   <div className="space-y-3">
                      <label className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] px-3">Donor Legal Name</label>
                      <input name="donor" required placeholder="Name or Organization" className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none focus:bg-white focus:border-indigo-500 transition-all" />
                   </div>
                   <div className="space-y-3">
                      <label className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] px-3">Contribution (₹)</label>
                      <div className="relative">
                        <IndianRupee className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                        <input name="amount" type="number" required placeholder="0.00" className="w-full pl-12 pr-6 py-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-lg outline-none focus:bg-white focus:border-indigo-500 transition-all" />
                      </div>
                   </div>
                </div>

                <div className="space-y-3">
                   <label className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] px-3">Legacy Purpose (Title)</label>
                   <input name="title" required defaultValue={showDonationModal === 'privileged' ? 'Contribution to Privileged Student Fund' : ''} placeholder="e.g. Science Lab Upgrade" className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-lg outline-none focus:bg-white transition-all shadow-inner" />
                </div>

                <div className="space-y-3">
                   <label className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] px-3">Description & Impact Vision</label>
                   <textarea name="description" required rows={3} defaultValue={showDonationModal === 'privileged' ? 'Support for tuition and kits for high-achieving low-income students.' : ''} placeholder="Describe the goal and achievement..." className="w-full p-6 bg-slate-50 border-2 border-slate-100 rounded-[2.5rem] font-black text-sm outline-none focus:bg-white resize-none transition-all shadow-inner"></textarea>
                </div>

                <div className={`p-8 rounded-[3rem] border-2 flex items-center justify-between transition-all ${showDonationModal === 'privileged' ? 'bg-rose-50 border-rose-200' : 'bg-rose-50/50 border-rose-100/50'}`}>
                   <div className="flex items-center gap-4">
                      <div className="relative">
                        <input 
                          type="checkbox" 
                          name="isPrivileged" 
                          id="priv_check_don" 
                          defaultChecked={showDonationModal === 'privileged'}
                          className="w-8 h-8 rounded-xl text-rose-500 border-2 border-rose-200 focus:ring-rose-500 cursor-pointer" 
                        />
                      </div>
                      <div>
                        <label htmlFor="priv_check_don" className="text-xs font-black text-slate-600 uppercase tracking-widest cursor-pointer">
                           Allocate to <span className="text-rose-500 underline decoration-rose-200 underline-offset-4">Privileged Student Fund</span>
                        </label>
                        <p className="text-[9px] font-bold text-slate-400 mt-1 uppercase">Direct aid for under-resourced students.</p>
                      </div>
                   </div>
                   <Target className={showDonationModal === 'privileged' ? "text-rose-500" : "text-rose-200"} size={40} />
                </div>

                <button type="submit" className="w-full py-6 bg-slate-900 text-white rounded-[3rem] font-black text-lg shadow-2xl hover:bg-emerald-600 transition-all uppercase tracking-widest flex items-center justify-center gap-4 active:scale-95">
                   <Send size={24}/> Process Donation Receipt
                </button>
             </form>
          </div>
        </div>
      )}

      {/* ACTIVITY MODAL */}
      {showActivityModal && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-900/80 backdrop-blur-md p-4 animate-in fade-in" onClick={() => setShowActivityModal(false)}>
          <div className="bg-white rounded-[4rem] p-12 max-w-2xl w-full shadow-2xl relative overflow-hidden" onClick={(e) => e.stopPropagation()}>
             <div className="absolute top-0 left-0 w-3 h-full bg-emerald-600"></div>
             <div className="flex justify-between items-start mb-12">
                <div>
                   <h3 className="text-4xl font-black text-slate-900 tracking-tighter">Impact Activity Log</h3>
                   <p className="text-sm text-slate-500 font-medium italic mt-1">Record institutional impact across specialized domains.</p>
                </div>
                <button onClick={() => setShowActivityModal(false)} className="p-3 hover:bg-slate-100 rounded-full text-slate-400 transition-colors"><X size={36}/></button>
             </div>

             <form onSubmit={handleAddActivity} className="space-y-8">
                <div className="grid grid-cols-2 gap-8">
                   <div className="space-y-3">
                      <label className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] px-3">Primary Domain</label>
                      <select name="type" required className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none focus:bg-white transition-all">
                         <option value="Charity">Social Charity Work</option>
                         <option value="Environmental">Environmental Drive</option>
                         <option value="Sports">Sports Engagement</option>
                         <option value="Drama">Drama & Arts Masterclass</option>
                      </select>
                   </div>
                   <div className="space-y-3">
                      <label className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] px-3">Verified Impact Metric</label>
                      <input name="impact" required placeholder="e.g. 50 Trees Planted" className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none focus:bg-white transition-all" />
                   </div>
                </div>

                <div className="space-y-3">
                   <label className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] px-3">Project / Event Title</label>
                   <input name="title" required placeholder="Official Registry Title" className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-lg outline-none focus:bg-white transition-all shadow-inner" />
                </div>

                <div className="space-y-3">
                   <label className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] px-3">Vision & Detailed Achievement</label>
                   <textarea name="description" required rows={4} placeholder="Summarize the work done, volunteers involved, and the long-term benefit..." className="w-full p-6 bg-slate-50 border-2 border-slate-100 rounded-[2.5rem] font-black text-sm outline-none focus:bg-white resize-none transition-all shadow-inner"></textarea>
                </div>

                <div className="p-8 bg-emerald-50/50 rounded-[3rem] border-2 border-emerald-100/50 flex items-center gap-5">
                   <div className="p-3 bg-white rounded-2xl shadow-sm text-emerald-500"><Info size={28}/></div>
                   <p className="text-[10px] font-black text-emerald-800 uppercase leading-relaxed tracking-tight">Impact logs are published to the Institutional Annual Report and shared with the Alumni legacy network for accountability.</p>
                </div>

                <button type="submit" className="w-full py-6 bg-slate-900 text-white rounded-[3rem] font-black text-lg shadow-2xl hover:bg-emerald-600 transition-all uppercase tracking-widest flex items-center justify-center gap-4 active:scale-95">
                   <Send size={24}/> Finalize Impact Registry
                </button>
             </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default PhilanthropyHub;