
import React, { useState } from 'react';
import { 
  Settings, Box, Shield, PenTool, Upload, Save, 
  Trash2, Plus, Monitor, Armchair, Table2, Presentation, 
  Speaker, Wind, BookOpen, Beaker, FileText, Camera,
  Image as ImageIcon, CheckCircle2, X, AlertTriangle, Info,
  Search, Filter, Landmark
} from 'lucide-react';
// Fix: Corrected missing interface exports will be available in types.ts
import { SchoolAsset, SchoolBranding } from '../types';

const INITIAL_ASSETS: SchoolAsset[] = [
  { id: 'AS-01', name: 'Computer - Dell Optiplex', category: 'IT', totalQuantity: 45, availableQuantity: 42, associatedFee: 500, status: 'Available' },
  { id: 'AS-02', name: 'Student Bench & Desk Unit', category: 'Furniture', totalQuantity: 600, availableQuantity: 580, associatedFee: 200, status: 'Available' },
  { id: 'AS-03', name: 'Digital Projector - Epson', category: 'AudioVisual', totalQuantity: 12, availableQuantity: 10, associatedFee: 1500, status: 'Low Stock' },
  { id: 'AS-04', name: 'Split AC - 2 Ton (Daikin)', category: 'Infrastructure', totalQuantity: 25, availableQuantity: 24, associatedFee: 2000, status: 'Maintenance' },
  { id: 'AS-05', name: 'Smart White Board 75"', category: 'Infrastructure', totalQuantity: 15, availableQuantity: 15, associatedFee: 3000, status: 'Available' },
  { id: 'AS-06', name: 'Compound Microscope', category: 'Lab', totalQuantity: 30, availableQuantity: 28, associatedFee: 400, status: 'Available' },
  { id: 'AS-07', name: 'PA Column Speakers', category: 'AudioVisual', totalQuantity: 10, availableQuantity: 8, associatedFee: 1000, status: 'Available' },
  { id: 'AS-08', name: 'Lab Instrument: Spectrometer', category: 'Lab', totalQuantity: 5, availableQuantity: 4, associatedFee: 800, status: 'Available' },
  { id: 'AS-09', name: 'Faculty Executive Table', category: 'Furniture', totalQuantity: 40, availableQuantity: 35, associatedFee: 0, status: 'Available' },
  { id: 'AS-10', name: 'Stationery Bulk Pack', category: 'Stationery', totalQuantity: 200, availableQuantity: 142, associatedFee: 50, status: 'Available' },
];

const SettingsManagement: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'assets' | 'branding' | 'general'>('assets');
  const [assets, setAssets] = useState<SchoolAsset[]>(INITIAL_ASSETS);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddAsset, setShowAddAsset] = useState(false);
  const [editingAsset, setEditingAsset] = useState<SchoolAsset | null>(null);

  const [branding, setBranding] = useState<SchoolBranding>({
    logoUrl: 'https://picsum.photos/seed/edu-logo/200',
    directorSignUrl: '',
    principalSignUrl: '',
    coordinatorSignUrl: ''
  });

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'IT': return <Monitor size={18} />;
      case 'Furniture': return <Armchair size={18} />;
      case 'Infrastructure': return <Presentation size={18} />;
      case 'Lab': return <Beaker size={18} />;
      case 'AudioVisual': return <Speaker size={18} />;
      case 'Stationery': return <BookOpen size={18} />;
      default: return <Box size={18} />;
    }
  };

  const handleFileUpload = (field: keyof SchoolBranding) => {
    const mockUrl = field === 'logoUrl' 
      ? 'https://picsum.photos/seed/logo-new/200' 
      : 'https://picsum.photos/seed/sign-auth/200';
    
    setBranding(prev => ({
      ...prev,
      // Fix: Explicitly wrap the field in String() to prevent symbol-to-string conversion errors
      [String(field)]: mockUrl
    }));
    alert(`Digital asset for ${field} uploaded and encrypted.`);
  };

  const handleDeleteAsset = (id: string) => {
    if (confirm('Permanently remove this asset from the institutional ledger?')) {
      setAssets(prev => prev.filter(a => a.id !== id));
    }
  };

  const handleAssetSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const total = parseInt(formData.get('total') as string) || 0;
    
    const assetData: SchoolAsset = {
      id: editingAsset?.id || `AS-${(assets.length + 1).toString().padStart(2, '0')}`,
      name: formData.get('name') as string,
      category: formData.get('category') as any,
      totalQuantity: total,
      availableQuantity: editingAsset ? (total - (editingAsset.totalQuantity - editingAsset.availableQuantity)) : total,
      associatedFee: parseInt(formData.get('fee') as string) || 0,
      status: 'Available'
    };

    if (editingAsset) {
      setAssets(prev => prev.map(a => a.id === editingAsset.id ? assetData : a));
    } else {
      setAssets(prev => [...prev, assetData]);
    }
    
    setShowAddAsset(false);
    setEditingAsset(null);
  };

  const filteredAssets = assets.filter(a => 
    a.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    a.id.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Institutional Settings</h1>
          <p className="text-slate-500">Global configurations, asset tracking, and authority branding.</p>
        </div>
        <div className="flex bg-white p-1 rounded-2xl border border-slate-200 shadow-sm overflow-x-auto">
          {[
            { id: 'assets', label: 'Asset Inventory', icon: <Box size={16} /> },
            { id: 'branding', label: 'Identity & Signs', icon: <Shield size={16} /> },
            { id: 'general', label: 'General Config', icon: <Settings size={16} /> },
          ].map(tab => (
            <button 
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`px-6 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 whitespace-nowrap ${activeSubTab === tab.id ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}
            >
              {tab.icon} {tab.label}
            </button>
          ))}
        </div>
      </div>

      {activeSubTab === 'assets' && (
        <div className="space-y-8 animate-in fade-in duration-300">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
             <div className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Total Assets</p>
                <h3 className="text-2xl font-black text-slate-900">{assets.length} Categories</h3>
             </div>
             <div className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">In Maintenance</p>
                <h3 className="text-2xl font-black text-rose-600">{assets.filter(a => a.status === 'Maintenance').length} Units</h3>
             </div>
             <div className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Inventory Value</p>
                <h3 className="text-2xl font-black text-indigo-600">₹42.8L</h3>
             </div>
             <button 
               onClick={() => { setEditingAsset(null); setShowAddAsset(true); }}
               className="bg-indigo-600 p-6 rounded-[2rem] text-white shadow-xl shadow-indigo-500/20 flex items-center justify-center gap-3 hover:bg-indigo-700 transition-all"
             >
                <Plus size={24} />
                <span className="font-black text-sm uppercase">Catalog Asset</span>
             </button>
          </div>

          <div className="bg-white rounded-[3rem] border border-slate-100 shadow-sm overflow-hidden">
            <div className="p-8 border-b border-slate-100 flex flex-col lg:flex-row lg:justify-between lg:items-center gap-6 bg-slate-50/50">
               <div>
                 <h3 className="text-2xl font-black text-slate-900">Inventory Ledger</h3>
                 <p className="text-sm font-medium text-slate-500 italic">Tracking computers, furniture, climate control, and laboratory tools.</p>
               </div>
               <div className="flex gap-4">
                  <div className="relative">
                    <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input 
                      type="text" 
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search items..." 
                      className="pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-2xl text-sm font-black outline-none focus:border-indigo-500 w-64 shadow-sm" 
                    />
                  </div>
                  <button className="p-3 bg-white border border-slate-200 rounded-2xl text-slate-400 hover:text-indigo-600 transition-colors shadow-sm">
                    <Filter size={18}/>
                  </button>
               </div>
            </div>

            <div className="overflow-x-auto">
               <table className="w-full text-left">
                  <thead className="bg-slate-50 text-slate-400 text-[10px] uppercase font-black tracking-widest">
                     <tr>
                        <th className="px-8 py-6">Asset Specification</th>
                        <th className="px-8 py-6">Category</th>
                        <th className="px-8 py-6 text-center">Availability Matrix</th>
                        <th className="px-8 py-6">Usage Fee (₹)</th>
                        <th className="px-8 py-6">Operational Status</th>
                        <th className="px-8 py-6 text-right">Actions</th>
                     </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                     {filteredAssets.map(asset => (
                       <tr key={asset.id} className="hover:bg-slate-50/30 transition-colors group">
                          <td className="px-8 py-6">
                             <div>
                                <p className="font-black text-slate-900">{asset.name}</p>
                                <p className="text-[10px] text-slate-400 font-bold uppercase">{asset.id}</p>
                             </div>
                          </td>
                          <td className="px-8 py-6">
                             <div className="flex items-center gap-2 text-indigo-600">
                                {getCategoryIcon(asset.category)}
                                <span className="text-xs font-black uppercase tracking-wider">{asset.category}</span>
                             </div>
                          </td>
                          <td className="px-8 py-6">
                             <div className="flex flex-col items-center">
                                <div className="text-sm font-black text-slate-900">{asset.availableQuantity} / {asset.totalQuantity}</div>
                                <div className="w-24 h-1.5 bg-slate-100 rounded-full mt-1.5 overflow-hidden">
                                   <div 
                                     className={`h-full rounded-full transition-all duration-1000 ${asset.availableQuantity / asset.totalQuantity < 0.2 ? 'bg-rose-500' : 'bg-emerald-500'}`} 
                                     style={{ width: `${(asset.availableQuantity / asset.totalQuantity) * 100}%` }}
                                   ></div>
                                </div>
                             </div>
                          </td>
                          <td className="px-8 py-6">
                             <span className="font-mono text-sm font-black text-slate-600">₹{asset.associatedFee?.toLocaleString()}</span>
                          </td>
                          <td className="px-8 py-6">
                             <span className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase border ${
                               asset.status === 'Available' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' :
                               asset.status === 'Low Stock' ? 'bg-amber-50 text-amber-600 border-amber-100' :
                               'bg-rose-50 text-rose-600 border-rose-100'
                             }`}>
                                {asset.status}
                             </span>
                          </td>
                          <td className="px-8 py-6">
                             <div className="flex justify-end gap-2">
                                <button 
                                  onClick={() => { setEditingAsset(asset); setShowAddAsset(true); }}
                                  className="p-2 bg-slate-50 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all shadow-sm"
                                >
                                  <PenTool size={18}/>
                                </button>
                                <button 
                                  onClick={() => handleDeleteAsset(asset.id)}
                                  className="p-2 bg-slate-50 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-all shadow-sm"
                                >
                                  <Trash2 size={18}/>
                                </button>
                             </div>
                          </td>
                       </tr>
                     ))}
                  </tbody>
               </table>
            </div>
          </div>
        </div>
      )}

      {activeSubTab === 'branding' && (
        <div className="space-y-10 animate-in fade-in duration-300">
           <div className="bg-white p-12 rounded-[3.5rem] border border-slate-100 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-50/50 rounded-full blur-3xl -translate-y-32 translate-x-32"></div>
              <div className="max-w-3xl">
                 <h3 className="text-3xl font-black text-slate-900 mb-2">Authority Branding & Signs</h3>
                 <p className="text-slate-500 font-medium">Manage institutional identity assets used across all automated documents, certificates, and ID cards.</p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mt-12">
                 <div className="space-y-10">
                    <div className="space-y-4">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-2">Institutional Emblem (Logo)</label>
                       <div className="flex items-center gap-8">
                          <div className="w-44 h-44 bg-slate-50 border-4 border-dashed border-slate-200 rounded-[3rem] flex items-center justify-center relative overflow-hidden group transition-all hover:border-indigo-400 shadow-inner">
                             <img src={branding.logoUrl} className="w-full h-full object-contain p-6 transition-transform group-hover:scale-110" alt="Logo" />
                             <button onClick={() => handleFileUpload('logoUrl')} className="absolute inset-0 bg-indigo-600/60 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white transition-all backdrop-blur-sm">
                                <Camera size={40} />
                             </button>
                          </div>
                          <div className="space-y-4 flex-1">
                             <h4 className="font-black text-slate-900 text-xl leading-tight">EduNexus Global Academy Logo</h4>
                             <p className="text-xs text-slate-500 leading-relaxed font-medium">Recommended: 1024x1024px PNG with transparency. This logo appears on all official headers.</p>
                             <div className="flex gap-2">
                                <button onClick={() => handleFileUpload('logoUrl')} className="px-5 py-2.5 bg-slate-900 text-white rounded-xl text-[10px] font-black uppercase hover:bg-indigo-600 transition-all shadow-lg shadow-slate-900/10">Upload New</button>
                                <button className="px-5 py-2.5 bg-slate-100 text-slate-400 rounded-xl text-[10px] font-black uppercase">Remove</button>
                             </div>
                          </div>
                       </div>
                    </div>

                    <div className="bg-indigo-900 p-10 rounded-[3rem] text-white relative overflow-hidden shadow-2xl">
                       <div className="absolute top-0 right-0 p-8 opacity-10"><Landmark size={120}/></div>
                       <h4 className="text-2xl font-black mb-4 flex items-center gap-3"><Shield size={28} className="text-indigo-400"/> Cryptographic Verification</h4>
                       <p className="text-sm text-indigo-100 leading-relaxed font-medium mb-8">Digital signatures are embedded as encrypted layers in generated PDFs. Ensure signatures are performed on white paper for optimal background removal.</p>
                       <button className="flex items-center gap-2 text-xs font-black text-white bg-indigo-500 hover:bg-indigo-400 px-8 py-4 rounded-[1.5rem] transition-all shadow-xl shadow-indigo-900/50">
                          <CheckCircle2 size={18}/> Audit Current Auth Layers
                       </button>
                    </div>
                 </div>

                 <div className="space-y-8">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-2">Authorized Signatories</label>
                    <div className="grid grid-cols-1 gap-6">
                       {[
                         { field: 'directorSignUrl', label: 'Director Signature', title: 'Executive Oversight' },
                         { field: 'principalSignUrl', label: 'Principal Signature', title: 'Academic Authority' },
                         { field: 'coordinatorSignUrl', label: 'Coordinator Signature', title: 'Sectional Compliance' }
                       ].map(sign => (
                         <div key={sign.field} className="p-8 bg-slate-50 border border-slate-100 rounded-[2.5rem] flex items-center justify-between group hover:border-indigo-300 transition-all shadow-sm">
                            <div className="flex items-center gap-6">
                               <div className="w-28 h-16 bg-white border border-slate-200 rounded-2xl flex items-center justify-center overflow-hidden shadow-inner p-2">
                                  {branding[sign.field as keyof SchoolBranding] ? (
                                    <img src={branding[sign.field as keyof SchoolBranding]} className="h-full w-full object-contain mix-blend-multiply" />
                                  ) : (
                                    <ImageIcon className="text-slate-200" size={32} />
                                  )}
                               </div>
                               <div>
                                  <p className="font-black text-slate-900 text-base leading-none mb-1">{sign.label}</p>
                                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{sign.title}</p>
                               </div>
                            </div>
                            <button 
                              onClick={() => handleFileUpload(sign.field as keyof SchoolBranding)}
                              className="p-4 bg-white text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-2xl transition-all shadow-sm group-hover:scale-110"
                            >
                               <Upload size={24}/>
                            </button>
                         </div>
                       ))}
                    </div>
                 </div>
              </div>
              
              <div className="mt-12 pt-10 border-t border-slate-100 flex justify-end gap-4">
                 <button className="px-10 py-5 border-2 border-slate-100 rounded-[2rem] font-black text-slate-400 hover:bg-slate-50 transition-colors uppercase text-xs">Reset Changes</button>
                 <button className="px-12 py-5 bg-slate-900 text-white rounded-[2rem] font-black text-sm flex items-center gap-3 shadow-2xl shadow-slate-900/20 hover:scale-[1.02] transition-all uppercase tracking-widest">
                    <Save size={20}/> Save Global Branding Profile
                 </button>
              </div>
           </div>
        </div>
      )}

      {activeSubTab === 'general' && (
        <div className="p-32 text-center bg-white rounded-[4rem] border border-slate-100 shadow-sm animate-in zoom-in-95">
           <div className="w-24 h-24 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-8">
              <Settings className="text-slate-300 animate-spin-slow" size={48}/>
           </div>
           <h3 className="text-2xl font-black text-slate-900 mb-2">Academic Session Config</h3>
           <p className="text-slate-400 font-medium max-w-sm mx-auto italic">Configuration parameters for automatic roll number generation, holiday calendars, and ERP system endpoints are under administrative review.</p>
        </div>
      )}

      {showAddAsset && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-md p-4 animate-in fade-in duration-200" onClick={() => { setShowAddAsset(false); setEditingAsset(null); }}>
           <div className="bg-white rounded-[3.5rem] p-12 max-w-2xl w-full shadow-2xl relative overflow-hidden" onClick={(e) => e.stopPropagation()}>
              <div className="absolute top-0 left-0 w-3 h-full bg-indigo-600"></div>
              <div className="flex justify-between items-center mb-10">
                 <div>
                   <h3 className="text-3xl font-black text-slate-900 leading-tight">
                    {editingAsset ? 'Modify Asset Data' : 'Catalog New Asset'}
                   </h3>
                   <p className="text-sm text-slate-500 font-medium">Register equipment in the central ledger.</p>
                 </div>
                 <button onClick={() => { setShowAddAsset(false); setEditingAsset(null); }} className="p-3 hover:bg-slate-100 rounded-full text-slate-400 transition-colors"><X size={32}/></button>
              </div>

              <form className="space-y-8" onSubmit={handleAssetSubmit}>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-2">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Asset Name / Model</label>
                       <input name="name" defaultValue={editingAsset?.name || ''} required className="w-full p-5 bg-slate-50 border border-slate-200 rounded-2xl font-black outline-none focus:bg-white focus:border-indigo-500 transition-all shadow-inner" placeholder="e.g. Laser Projector 4K" />
                    </div>
                    <div className="space-y-2">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Department Category</label>
                       <select name="category" defaultValue={editingAsset?.category || 'IT'} className="w-full p-5 bg-slate-50 border border-slate-200 rounded-2xl font-black outline-none focus:bg-white focus:border-indigo-500 transition-all">
                          <option value="IT">IT & Digital Lab</option>
                          <option value="Infrastructure">Classroom Infrastructure</option>
                          <option value="Lab">Science Lab Instruments</option>
                          <option value="AudioVisual">Audio-Visual & Multi-Media</option>
                          <option value="Stationery">Bulk Stationery Supply</option>
                          <option value="Furniture">General Furniture</option>
                       </select>
                    </div>
                    <div className="space-y-2">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Total Units Procured</label>
                       <input name="total" type="number" defaultValue={editingAsset?.totalQuantity || 0} required className="w-full p-5 bg-slate-50 border border-slate-200 rounded-2xl font-black outline-none" placeholder="0" />
                    </div>
                    <div className="space-y-2">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Usage Fee (per semester)</label>
                       <input name="fee" type="number" defaultValue={editingAsset?.associatedFee || 0} className="w-full p-5 bg-slate-50 border border-slate-200 rounded-2xl font-black outline-none" placeholder="Optional (₹)" />
                    </div>
                 </div>

                 <div className="p-8 bg-slate-50 rounded-[2rem] border border-slate-200 flex items-start gap-5">
                    <div className="p-4 bg-white rounded-2xl shadow-sm text-amber-500"><Info size={28}/></div>
                    <div className="space-y-1">
                       <h4 className="text-base font-black text-slate-900 leading-none">Financial Compliance</h4>
                       <p className="text-xs text-slate-500 font-medium leading-relaxed">Assets added with a usage fee will be automatically appended to student invoices if their class/section uses the specific laboratory or equipment.</p>
                    </div>
                 </div>

                 <div className="flex gap-4 pt-6">
                    <button type="submit" className="flex-[2] py-6 bg-indigo-600 text-white rounded-[2.5rem] font-black text-lg shadow-2xl shadow-indigo-500/30 hover:bg-indigo-700 transition-all uppercase tracking-widest">
                      {editingAsset ? 'Apply Modifications' : 'Register into Ledger'}
                    </button>
                    <button type="button" onClick={() => { setShowAddAsset(false); setEditingAsset(null); }} className="flex-1 py-6 bg-slate-100 text-slate-400 rounded-[2.5rem] font-black text-sm hover:bg-slate-200 transition-all uppercase tracking-widest">Discard</button>
                 </div>
              </form>
           </div>
        </div>
      )}
    </div>
  );
};

export default SettingsManagement;
