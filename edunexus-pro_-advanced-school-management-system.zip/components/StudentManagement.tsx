
import React, { useState, useEffect, useMemo } from 'react';
import { CLASS_LIST, SECTION_LIST, STUDENT_GROUPS, SOCIAL_CATEGORIES } from '../constants';
import { supabase } from '../lib/supabase';
import { 
  Plus, Search, X, Camera, UserPlus, 
  Bus, Home, Loader2, User, Settings, Tag,
  FileText, ShieldCheck, Mail, Phone, MapPin, 
  Briefcase, Heart, Users, Key, Save, Upload,
  CheckCircle2, PlusCircle, Trash2, ArrowRight, ArrowLeft,
  Fingerprint, Smartphone, Landmark, Building2, Printer, 
  Download, QrCode, CreditCard, GraduationCap, Award,
  Activity, Zap, ShieldAlert, FileUp, FileCheck, Check,
  MoreVertical, Copy, Layers, Shield, Info, Venus, Mars
} from 'lucide-react';

const StudentManagement: React.FC = () => {
  const [view, setView] = useState<'list' | 'enroll'>('list');
  const [formStep, setFormStep] = useState(1);
  const [students, setStudents] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [isSelectionMode, setIsSelectionMode] = useState(false);
  const [modalMode, setModalMode] = useState<'profile' | 'idcard' | 'batch_id' | null>(null);
  const [selectedStudent, setSelectedStudent] = useState<any>(null);

  const [previews, setPreviews] = useState<Record<string, string>>({
    student: '', father: '', mother: '', birthCert: ''
  });

  useEffect(() => { fetchStudents(); }, []);

  const fetchStudents = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.from('students').select('*').order('name');
      if (error) throw error;
      setStudents(data || []);
    } catch (err) { console.error(err); } finally { setLoading(false); }
  };

  const handleEnroll = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    const fd = new FormData(e.currentTarget);
    const studentId = (fd.get('uid') as string) || `S${Date.now().toString().slice(-4)}`;
    
    const record = {
      id: studentId,
      name: fd.get('name'),
      class: fd.get('class'),
      section: fd.get('section'),
      roll_no: fd.get('roll_no'),
      group: fd.get('group'),
      gender: fd.get('gender'),
      category: fd.get('category'),
      dob: fd.get('dob'),
      blood_group: fd.get('blood_group'),
      father_name: fd.get('father_name'),
      mother_name: fd.get('mother_name'),
      photo_url: previews.student || `https://picsum.photos/seed/${studentId}/200`,
    };

    try {
      const { error } = await supabase.from('students').insert([record]);
      if (error) throw error;
      alert('Registry Entry Authorized.');
      fetchStudents();
      setView('list');
    } catch (err: any) { alert('Sync Failure: ' + err.message); } finally { setIsSubmitting(false); }
  };

  const filteredStudents = useMemo(() => students.filter(s => 
    s.name.toLowerCase().includes(searchQuery.toLowerCase()) || (s.id && s.id.toLowerCase().includes(searchQuery.toLowerCase()))
  ), [students, searchQuery]);

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-7xl mx-auto overflow-x-hidden relative min-h-screen">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-6 no-print">
        <div>
          <h1 className="text-3xl md:text-5xl font-black text-slate-900 italic uppercase tracking-tighter leading-none">Student Registry</h1>
          <p className="text-[10px] md:text-sm font-medium text-slate-500 uppercase tracking-widest mt-1">Institutional Node • {loading ? 'Syncing...' : 'Live'}</p>
        </div>
        <button onClick={() => setView('enroll')} className="px-10 py-5 bg-indigo-600 text-white rounded-[2rem] font-black text-xs uppercase tracking-widest flex items-center justify-center gap-3 shadow-2xl hover:scale-105 active:scale-95 transition-all">
          <UserPlus size={20} /> Enroll New Node
        </button>
      </div>

      {view === 'list' && (
        <div className="space-y-8 animate-in fade-in">
           <div className="relative group">
              <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300" size={24} />
              <input 
                type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search Registry..." 
                className="w-full pl-16 pr-8 py-5 bg-white border-2 border-slate-100 rounded-[2.5rem] text-sm outline-none transition-all font-black"
              />
           </div>
           
           <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredStudents.map(student => (
                <div key={student.id} className="bg-white p-8 rounded-[3rem] border border-slate-100 hover:shadow-2xl transition-all relative overflow-hidden group">
                   <div className="flex items-center gap-6">
                      <img src={student.photo_url} className="w-20 h-20 rounded-[2rem] object-cover border-4 border-white shadow-lg" alt="" />
                      <div>
                        <h4 className="text-xl font-black text-slate-900 leading-tight truncate max-w-[180px]">{student.name}</h4>
                        <p className="text-[10px] font-black text-indigo-600 uppercase mt-1.5 flex items-center gap-2">
                           {student.gender === 'Female' ? <Venus size={12}/> : <Mars size={12}/>}
                           G{student.class}-{student.section} • {student.category}
                        </p>
                        <p className="text-[9px] text-slate-400 font-bold uppercase mt-1">Group: {student.group}</p>
                      </div>
                   </div>
                   <div className="mt-8 pt-8 border-t border-slate-50 flex gap-4">
                      <button className="flex-1 py-3 bg-slate-50 text-[10px] font-black uppercase text-slate-400 rounded-2xl hover:bg-slate-100 transition-all">View Profile</button>
                      <button className="flex-1 py-3 bg-indigo-50 text-[10px] font-black uppercase text-indigo-600 rounded-2xl hover:bg-indigo-600 hover:text-white transition-all">ID Card</button>
                   </div>
                </div>
              ))}
           </div>
        </div>
      )}

      {view === 'enroll' && (
        <div className="max-w-6xl mx-auto bg-white rounded-[3rem] md:rounded-[5rem] border border-slate-100 p-8 md:p-20 shadow-2xl relative animate-in zoom-in-95">
           <div className="absolute top-0 left-0 w-3 h-full bg-indigo-600"></div>
           <div className="flex justify-between items-center mb-16">
              <h2 className="text-4xl md:text-6xl font-black text-slate-900 italic uppercase tracking-tighter">Enrollment</h2>
              <button onClick={() => setView('list')} className="p-4 hover:bg-slate-100 rounded-full text-slate-400 transition-colors"><X size={48}/></button>
           </div>
           
           <form onSubmit={handleEnroll} className="space-y-12">
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
                <div className="space-y-3">
                   <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest px-2">Legal Full Name</label>
                   <input name="name" required placeholder="Full Name" className="w-full px-8 py-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none focus:bg-white focus:border-indigo-500" />
                </div>
                <div className="space-y-3">
                   <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest px-2">Grade / Level</label>
                   <select name="class" className="w-full px-6 py-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none">
                      {CLASS_LIST.map(c => <option key={c} value={c}>{c}</option>)}
                   </select>
                </div>
                <div className="space-y-3">
                   <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest px-2">Gender Identification</label>
                   <select name="gender" className="w-full px-6 py-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none">
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                   </select>
                </div>
                <div className="space-y-3">
                   <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest px-2">Institutional Group</label>
                   <select name="group" className="w-full px-6 py-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none">
                      {STUDENT_GROUPS.map(g => <option key={g} value={g}>{g}</option>)}
                   </select>
                </div>
                <div className="space-y-3">
                   <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest px-2">Social Category</label>
                   <select name="category" className="w-full px-6 py-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none">
                      {SOCIAL_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                   </select>
                </div>
                <div className="space-y-3">
                   <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest px-2">Date of Birth</label>
                   <input name="dob" type="date" required className="w-full px-8 py-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none" />
                </div>
             </div>
             <button type="submit" disabled={isSubmitting} className="w-full py-8 bg-indigo-600 text-white rounded-[3rem] font-black text-xl shadow-2xl flex items-center justify-center gap-4 hover:bg-indigo-700 transition-all">
                {isSubmitting ? <Loader2 className="animate-spin"/> : <Save size={28}/>} Authorize Registry Entry
             </button>
           </form>
        </div>
      )}
    </div>
  );
};

export default StudentManagement;
