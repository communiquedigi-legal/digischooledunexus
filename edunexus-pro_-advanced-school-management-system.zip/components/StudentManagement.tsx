
import React, { useState, useEffect, useMemo } from 'react';
import { CLASS_LIST, SECTION_LIST, STUDENT_GROUPS, SOCIAL_CATEGORIES } from '../constants';
import { supabase } from '../lib/supabase';
import { 
  Plus, Search, X, Camera, UserPlus, 
  Bus, Home, Loader2, User, Settings, Tag,
  FileText, ShieldCheck, Mail, Phone, MapPin, 
  Briefcase, Heart, Users, Key, Save, Upload,
  CheckCircle2, PlusCircle, Trash2, ArrowRight, ArrowLeft,
  Fingerprint, Smartphone, Landmark, Building2, Printer, 
  Download, QrCode, CreditCard, GraduationCap, Award,
  Activity, Zap, ShieldAlert, FileUp, FileCheck, Check,
  MoreVertical, Copy, Layers, Shield, Info, Venus, Mars,
  UserCheck, AlertTriangle, FileSignature, Stethoscope
} from 'lucide-react';

const StudentManagement: React.FC = () => {
  const [view, setView] = useState<'list' | 'enroll'>('list');
  const [formStep, setFormStep] = useState(1);
  const [students, setStudents] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [modalMode, setModalMode] = useState<'profile' | 'idcard' | null>(null);
  const [selectedStudent, setSelectedStudent] = useState<any>(null);

  const [previews, setPreviews] = useState<Record<string, string>>({
    student: '', father: '', mother: '', birthCert: '', aadhaar: '', marksCard: ''
  });

  useEffect(() => { fetchStudents(); }, []);

  const fetchStudents = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.from('students').select('*').order('name');
      if (error) throw error;
      setStudents(data || []);
    } catch (err) { console.error(err); } finally { setLoading(false); }
  };

  const handleEnroll = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (formStep < 6) {
      setFormStep(formStep + 1);
      return;
    }

    setIsSubmitting(true);
    const fd = new FormData(e.currentTarget);
    const studentId = (fd.get('admissionNo') as string) || `ADM${Date.now().toString().slice(-6)}`;
    
    const record = {
      id: studentId,
      name: fd.get('name'),
      class: fd.get('class'),
      section: fd.get('section'),
      roll_no: fd.get('roll_no') || 'TBD',
      group: fd.get('group'),
      gender: fd.get('gender'),
      category: fd.get('category'),
      dob: fd.get('dob'),
      blood_group: fd.get('blood_group'),
      nationality: fd.get('nationality'),
      religion: fd.get('religion'),
      caste: fd.get('caste'),
      mother_tongue: fd.get('motherTongue'),
      present_address: fd.get('presentAddress'),
      permanent_address: fd.get('permanentAddress'),
      city: fd.get('city'),
      state: fd.get('state'),
      pin_code: fd.get('pinCode'),
      student_mobile: fd.get('studentMobile'),
      student_email: fd.get('studentEmail'),
      father_name: fd.get('fatherName'),
      father_occupation: fd.get('fatherOccupation'),
      father_mobile: fd.get('fatherMobile'),
      father_email: fd.get('fatherEmail'),
      mother_name: fd.get('motherName'),
      mother_occupation: fd.get('motherOccupation'),
      mother_mobile: fd.get('motherMobile'),
      mother_email: fd.get('motherEmail'),
      guardian_name: fd.get('guardianName'),
      emergency_contact_name: fd.get('emergencyName'),
      emergency_number: fd.get('emergencyPhone'),
      aadhaar_number: fd.get('aadhaar'),
      allergies: fd.get('allergies'),
      special_needs: fd.get('specialNeeds'),
      admission_date: fd.get('admissionDate'),
      verified_by: fd.get('verifiedBy'),
      fee_category: fd.get('feeCategory'),
      remarks: fd.get('remarks'),
      photo_url: previews.student || `https://picsum.photos/seed/${studentId}/200`,
    };

    try {
      const { error } = await supabase.from('students').insert([record]);
      if (error) throw error;
      alert('Institutional Ledger Updated: Admission Authorized.');
      fetchStudents();
      setView('list');
      setFormStep(1);
    } catch (err: any) { alert('Sync Failure: ' + err.message); } finally { setIsSubmitting(false); }
  };

  const filteredStudents = useMemo(() => students.filter(s => 
    (s.name?.toLowerCase().includes(searchQuery.toLowerCase())) || 
    (s.id?.toLowerCase().includes(searchQuery.toLowerCase()))
  ), [students, searchQuery]);

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-7xl mx-auto overflow-x-hidden relative min-h-screen">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-6 no-print">
        <div>
          <h1 className="text-3xl md:text-5xl font-black text-slate-900 italic uppercase tracking-tighter leading-none">Student Registry</h1>
          <p className="text-[10px] md:text-sm font-medium text-slate-500 uppercase tracking-widest mt-1 tracking-[0.2em]">Institutional Core Node • {loading ? 'Syncing...' : 'Live Ledger'}</p>
        </div>
        <button onClick={() => { setView('enroll'); setFormStep(1); }} className="px-10 py-5 bg-indigo-600 text-white rounded-[2rem] font-black text-xs uppercase tracking-widest flex items-center justify-center gap-3 shadow-2xl hover:scale-105 active:scale-95 transition-all">
          <UserPlus size={20} /> ADMISSION HUB
        </button>
      </div>

      {view === 'list' && (
        <div className="space-y-8 animate-in fade-in">
           <div className="relative group max-w-2xl">
              <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-600 transition-colors" size={24} />
              <input 
                type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Query Registry by Name or UID..." 
                className="w-full pl-16 pr-8 py-5 bg-white border-2 border-slate-100 rounded-[2.5rem] text-sm outline-none transition-all font-black shadow-sm focus:border-indigo-500"
              />
           </div>
           
           <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredStudents.map(student => (
                <div key={student.id} className="bg-white p-8 rounded-[3rem] border border-slate-100 hover:shadow-2xl transition-all relative overflow-hidden group">
                   <div className="absolute top-0 right-0 p-8 opacity-5 -rotate-12 group-hover:rotate-0 transition-all"><GraduationCap size={100}/></div>
                   <div className="flex items-center gap-6 relative z-10">
                      <img src={student.photo_url || student.photoUrl} className="w-20 h-20 rounded-[2rem] object-cover border-4 border-white shadow-lg" alt="" />
                      <div>
                        <h4 className="text-xl font-black text-slate-900 leading-tight truncate max-w-[180px] uppercase italic tracking-tighter">{student.name}</h4>
                        <p className="text-[10px] font-black text-indigo-600 uppercase mt-1.5 flex items-center gap-2">
                           {student.gender === 'Female' ? <Venus size={12}/> : <Mars size={12}/>}
                           G{student.class}-{student.section} • {student.category}
                        </p>
                        <p className="text-[9px] text-slate-400 font-bold uppercase mt-1 tracking-widest">ID: {student.id}</p>
                      </div>
                   </div>
                   <div className="mt-8 pt-8 border-t border-slate-50 flex gap-4 relative z-10">
                      <button onClick={() => { setSelectedStudent(student); setModalMode('profile'); }} className="flex-1 py-3 bg-slate-50 text-[10px] font-black uppercase text-slate-400 rounded-2xl hover:bg-slate-100 transition-all tracking-widest">Profile</button>
                      <button onClick={() => { setSelectedStudent(student); setModalMode('idcard'); }} className="flex-1 py-3 bg-indigo-50 text-[10px] font-black uppercase text-indigo-600 rounded-2xl hover:bg-indigo-600 hover:text-white transition-all tracking-widest">Identity</button>
                   </div>
                </div>
              ))}
              {filteredStudents.length === 0 && !loading && (
                <div className="col-span-full py-32 text-center bg-white rounded-[4rem] border-2 border-dashed border-slate-100">
                   <Users size={64} className="mx-auto text-slate-100 mb-6"/>
                   <h3 className="text-2xl font-black text-slate-200 uppercase italic">Empty Sector</h3>
                   <p className="text-sm font-medium text-slate-400 mt-2">No active student nodes detected.</p>
                </div>
              )}
           </div>
        </div>
      )}

      {view === 'enroll' && (
        <div className="max-w-6xl mx-auto bg-white rounded-[3.5rem] md:rounded-[5rem] border border-slate-100 shadow-2xl relative overflow-hidden animate-in zoom-in-95">
           <div className="absolute top-0 left-0 w-3 h-full bg-indigo-600"></div>
           
           <div className="px-10 md:px-20 pt-16 flex flex-wrap gap-4 items-center justify-between no-print">
              <div className="flex-1 flex gap-2">
                 {[1, 2, 3, 4, 5, 6].map(s => (
                   <div key={s} className="flex-1 h-1.5 rounded-full bg-slate-100 overflow-hidden">
                      <div className={`h-full bg-indigo-600 transition-all duration-500 ${formStep >= s ? 'w-full' : 'w-0'}`}></div>
                   </div>
                 ))}
              </div>
              <span className="text-[10px] font-black text-indigo-600 uppercase tracking-[0.2em] ml-6">Phase {formStep} / 6</span>
           </div>

           <div className="p-10 md:p-20 pt-10">
              <div className="flex justify-between items-start mb-16">
                 <div>
                    <h2 className="text-4xl md:text-7xl font-black text-slate-900 italic uppercase tracking-tighter leading-none">Admission Hub</h2>
                    <p className="text-slate-400 font-bold uppercase text-[10px] md:text-sm tracking-widest mt-3 flex items-center gap-3">
                       <ShieldCheck size={20} className="text-emerald-500"/> Secure Enrollment Protocol
                    </p>
                 </div>
                 <button onClick={() => setView('list')} className="p-4 hover:bg-slate-50 rounded-full text-slate-300 transition-colors"><X size={48}/></button>
              </div>
              
              <form onSubmit={handleEnroll} className="space-y-12">
                {formStep === 1 && (
                  <div className="space-y-10 animate-in fade-in">
                    <div className="flex items-center gap-4 border-b border-slate-50 pb-6">
                       <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl"><User size={20}/></div>
                       <h3 className="text-2xl font-black text-slate-900 italic uppercase">1. Personal Specifications</h3>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                       <div className="space-y-2 lg:col-span-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Full Legal Name (Student)</label>
                          <input name="name" required className="w-full px-8 py-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none focus:bg-white focus:border-indigo-500 shadow-inner" />
                       </div>
                       <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Admission No (Office)</label>
                          <input name="admissionNo" placeholder="Auto-gen if empty" className="w-full px-8 py-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none shadow-inner" />
                       </div>
                       <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Gender Identification</label>
                          <select name="gender" className="w-full px-6 py-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none">
                             <option value="Male">Male</option>
                             <option value="Female">Female</option>
                             <option value="Other">Other</option>
                          </select>
                       </div>
                       <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Date of Birth</label>
                          <input name="dob" type="date" required className="w-full px-8 py-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none" />
                       </div>
                       <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Age at Admission</label>
                          <input name="age" type="number" placeholder="Years" className="w-full px-8 py-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none" />
                       </div>
                    </div>
                    <button type="button" onClick={() => setFormStep(2)} className="w-full py-6 bg-slate-900 text-white rounded-[2.5rem] font-black text-sm uppercase tracking-widest flex items-center justify-center gap-3 shadow-2xl">Phase 2: Contact <ArrowRight size={20}/></button>
                  </div>
                )}

                {formStep === 2 && (
                  <div className="space-y-10 animate-in fade-in">
                    <div className="flex items-center gap-4 border-b border-slate-50 pb-6">
                       <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl"><MapPin size={20}/></div>
                       <h3 className="text-2xl font-black text-slate-900 italic uppercase">2. Geolocation & Contact</h3>
                    </div>
                    <div className="space-y-6">
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Present Address</label>
                            <textarea name="presentAddress" rows={2} required className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-xs outline-none focus:bg-white resize-none"></textarea>
                          </div>
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Permanent Address</label>
                            <textarea name="permanentAddress" rows={2} required className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-xs outline-none focus:bg-white resize-none"></textarea>
                          </div>
                       </div>
                       <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                          <input name="city" placeholder="City" className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-xs outline-none" />
                          <input name="state" placeholder="State" className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-xs outline-none" />
                          <input name="pinCode" placeholder="PIN Code" className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-xs outline-none" />
                          <input name="studentMobile" placeholder="Mobile (Student)" className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-xs outline-none" />
                       </div>
                    </div>
                    <div className="flex gap-4">
                      <button type="button" onClick={() => setFormStep(1)} className="flex-1 py-6 bg-slate-50 text-slate-400 rounded-[2.5rem] font-black text-sm uppercase tracking-widest">Back</button>
                      <button type="button" onClick={() => setFormStep(3)} className="flex-[2] py-6 bg-slate-900 text-white rounded-[2.5rem] font-black text-sm uppercase tracking-widest flex items-center justify-center gap-3 shadow-2xl">Phase 3: Parental <ArrowRight size={20}/></button>
                    </div>
                  </div>
                )}

                {formStep === 3 && (
                   <div className="space-y-10 animate-in fade-in">
                    <div className="flex items-center gap-4 border-b border-slate-50 pb-6">
                       <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl"><Briefcase size={20}/></div>
                       <h3 className="text-2xl font-black text-slate-900 italic uppercase">3. Parental Hierarchy</h3>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                       <div className="space-y-6">
                          <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] border-l-4 border-indigo-500 pl-4">Father's Dossier</h4>
                          <input name="fatherName" placeholder="Full Name" required className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-xs outline-none" />
                          <input name="fatherOccupation" placeholder="Occupation" className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-xs outline-none" />
                          <input name="fatherMobile" placeholder="Mobile Number" required className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-xs outline-none" />
                       </div>
                       <div className="space-y-6">
                          <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] border-l-4 border-rose-500 pl-4">Mother's Dossier</h4>
                          <input name="motherName" placeholder="Full Name" required className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-xs outline-none" />
                          <input name="motherOccupation" placeholder="Occupation" className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-xs outline-none" />
                          <input name="motherMobile" placeholder="Mobile Number" required className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-xs outline-none" />
                       </div>
                    </div>
                    <div className="flex gap-4">
                      <button type="button" onClick={() => setFormStep(2)} className="flex-1 py-6 bg-slate-50 text-slate-400 rounded-[2.5rem] font-black text-sm uppercase tracking-widest">Back</button>
                      <button type="button" onClick={() => setFormStep(4)} className="flex-[2] py-6 bg-slate-900 text-white rounded-[2.5rem] font-black text-sm uppercase tracking-widest flex items-center justify-center gap-3 shadow-2xl">Phase 4: Verification <ArrowRight size={20}/></button>
                    </div>
                  </div>
                )}

                {formStep === 4 && (
                   <div className="space-y-10 animate-in fade-in">
                    <div className="flex items-center gap-4 border-b border-slate-50 pb-6">
                       <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl"><Fingerprint size={20}/></div>
                       <h3 className="text-2xl font-black text-slate-900 italic uppercase">4. ID & Emergency</h3>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                       <div className="space-y-4">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Government Identification (Aadhaar)</label>
                          <input name="aadhaar" required placeholder="12-Digit Unique ID" className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-base outline-none shadow-inner tracking-[0.2em]" />
                       </div>
                       <div className="space-y-4">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Emergency Contact Node</label>
                          <div className="flex gap-4">
                             <input name="emergencyName" placeholder="Person Name" className="flex-[2] p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-xs outline-none" />
                             <input name="emergencyPhone" placeholder="Phone" className="flex-[1.5] p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-xs outline-none" />
                          </div>
                       </div>
                    </div>
                    <div className="flex gap-4">
                      <button type="button" onClick={() => setFormStep(3)} className="flex-1 py-6 bg-slate-50 text-slate-400 rounded-[2.5rem] font-black text-sm uppercase tracking-widest">Back</button>
                      <button type="button" onClick={() => setFormStep(5)} className="flex-[2] py-6 bg-slate-900 text-white rounded-[2.5rem] font-black text-sm uppercase tracking-widest flex items-center justify-center gap-3 shadow-2xl">Phase 5: Medical <ArrowRight size={20}/></button>
                    </div>
                  </div>
                )}

                {formStep === 5 && (
                   <div className="space-y-10 animate-in fade-in">
                    <div className="flex items-center gap-4 border-b border-slate-50 pb-6">
                       <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl"><Stethoscope size={20}/></div>
                       <h3 className="text-2xl font-black text-slate-900 italic uppercase">5. Health & Documents</h3>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                       <div className="space-y-4">
                          <div className="flex items-center gap-2 mb-2"><Heart className="text-rose-500" size={16}/><span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Medical Parameters</span></div>
                          <div className="grid grid-cols-2 gap-4">
                             <input name="blood_group" placeholder="Blood Group" className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-xs outline-none" />
                             <input name="allergies" placeholder="Known Allergies" className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-xs outline-none" />
                          </div>
                          <textarea name="specialNeeds" placeholder="Special Needs / Educational Support requirements..." className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-xs outline-none resize-none h-24"></textarea>
                       </div>
                       <div className="space-y-4">
                          <div className="flex items-center gap-2 mb-2"><Camera className="text-indigo-500" size={16}/><span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Biometric Identity</span></div>
                          <div className="aspect-video bg-slate-50 border-4 border-dashed border-slate-200 rounded-[3rem] flex flex-col items-center justify-center gap-4 cursor-pointer hover:border-indigo-500 transition-all group">
                             <Upload className="text-slate-300 group-hover:text-indigo-500 group-hover:scale-110 transition-all" size={48}/>
                             <p className="text-[10px] font-black text-slate-400 uppercase">Attach Passport Photo</p>
                          </div>
                       </div>
                    </div>
                    <div className="flex gap-4">
                      <button type="button" onClick={() => setFormStep(4)} className="flex-1 py-6 bg-slate-50 text-slate-400 rounded-[2.5rem] font-black text-sm uppercase tracking-widest">Back</button>
                      <button type="button" onClick={() => setFormStep(6)} className="flex-[2] py-6 bg-slate-900 text-white rounded-[2.5rem] font-black text-sm uppercase tracking-widest flex items-center justify-center gap-3 shadow-2xl">Phase 6: Finalize <ArrowRight size={20}/></button>
                    </div>
                  </div>
                )}

                {formStep === 6 && (
                  <div className="space-y-10 animate-in fade-in">
                    <div className="flex items-center gap-4 border-b border-slate-50 pb-6">
                       <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl"><Building2 size={20}/></div>
                       <h3 className="text-2xl font-black text-slate-900 italic uppercase">6. Institutional Context (Office Use)</h3>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                       <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Class Assignment</label>
                          <select name="class" className="w-full px-6 py-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none">
                             {CLASS_LIST.map(c => <option key={c} value={c}>Grade {c}</option>)}
                          </select>
                       </div>
                       <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Section Assigned</label>
                          <select name="section" className="w-full px-6 py-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none">
                             {SECTION_LIST.map(s => <option key={s} value={s}>Section {s}</option>)}
                          </select>
                       </div>
                       <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Fee Configuration</label>
                          <select name="feeCategory" className="w-full px-6 py-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none">
                             <option value="General">Standard Ledger</option>
                             <option value="Staff-Ward">Staff Privilege</option>
                             <option value="RTE">Right to Education</option>
                             <option value="Merit">Scholarship Tier</option>
                          </select>
                       </div>
                       <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Verified By</label>
                          <input name="verifiedBy" required placeholder="Authorized Official Name" className="w-full px-8 py-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none shadow-inner" />
                       </div>
                       <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Date of Admission</label>
                          <input name="admissionDate" type="date" defaultValue={new Date().toISOString().split('T')[0]} className="w-full px-8 py-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none" />
                       </div>
                    </div>
                    
                    <div className="bg-amber-50 p-8 rounded-[3rem] border-2 border-dashed border-amber-200">
                       <p className="text-xs font-medium text-amber-800 leading-relaxed text-center italic">"I hereby authorize the enrollment of this student node into the EduNexus Global Ledger. All provided biometric and legal data has been scrutinized against original instruments."</p>
                    </div>

                    <div className="flex gap-4">
                      <button type="button" onClick={() => setFormStep(5)} className="flex-1 py-6 bg-slate-50 text-slate-400 rounded-[2.5rem] font-black text-sm uppercase tracking-widest">Back</button>
                      <button type="submit" disabled={isSubmitting} className="flex-[2] py-8 bg-emerald-600 text-white rounded-[3rem] font-black text-xl shadow-2xl hover:bg-emerald-700 transition-all flex items-center justify-center gap-4 active:scale-95 uppercase tracking-widest">
                        {isSubmitting ? <Loader2 className="animate-spin" /> : <ShieldCheck size={28}/>} AUTHORIZE ENROLLMENT
                      </button>
                    </div>
                  </div>
                )}
              </form>
           </div>
        </div>
      )}
      
      {/* MODALS for Identity & Profile */}
      {modalMode === 'profile' && selectedStudent && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center bg-slate-900/60 backdrop-blur-md p-4 animate-in fade-in" onClick={() => setModalMode(null)}>
           <div className="bg-white rounded-[4rem] p-10 md:p-16 max-w-4xl w-full shadow-2xl relative overflow-y-auto max-h-[90vh]" onClick={(e) => e.stopPropagation()}>
              <button onClick={() => setModalMode(null)} className="absolute top-10 right-10 p-3 text-slate-400 hover:bg-slate-100 rounded-full transition-all"><X size={36}/></button>
              <div className="flex items-center gap-8 mb-12">
                 <img src={selectedStudent.photo_url || selectedStudent.photoUrl} className="w-32 h-32 rounded-[2.5rem] object-cover border-4 border-indigo-50 shadow-xl" />
                 <div>
                    <h2 className="text-5xl font-black text-slate-900 tracking-tighter italic uppercase">{selectedStudent.name}</h2>
                    <p className="text-indigo-600 font-bold uppercase text-xs tracking-[0.2em] flex items-center gap-2 mt-4">
                      <ShieldCheck size={20} className="text-emerald-500" /> Grade {selectedStudent.class}-{selectedStudent.section} • UID: {selectedStudent.id}
                    </p>
                 </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                 <div className="space-y-6">
                    <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100 pb-2">Academic Profile</h3>
                    <div className="grid grid-cols-2 gap-y-4">
                       <div><p className="text-[9px] font-bold text-slate-400 uppercase">Roll No</p><p className="text-sm font-black">{selectedStudent.roll_no || selectedStudent.rollNo}</p></div>
                       <div><p className="text-[9px] font-bold text-slate-400 uppercase">Group</p><p className="text-sm font-black">{selectedStudent.group}</p></div>
                       <div><p className="text-[9px] font-bold text-slate-400 uppercase">Category</p><p className="text-sm font-black">{selectedStudent.category}</p></div>
                       <div><p className="text-[9px] font-bold text-slate-400 uppercase">Status</p><span className="text-[10px] font-black text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full uppercase">Active</span></div>
                    </div>
                 </div>
                 <div className="space-y-6">
                    <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100 pb-2">Identity Context</h3>
                    <div className="grid grid-cols-2 gap-y-4">
                       <div><p className="text-[9px] font-bold text-slate-400 uppercase">D.O.B</p><p className="text-sm font-black">{selectedStudent.dob}</p></div>
                       <div><p className="text-[9px] font-bold text-slate-400 uppercase">Blood Group</p><p className="text-sm font-black">{selectedStudent.blood_group || selectedStudent.bloodGroup}</p></div>
                       <div><p className="text-[9px] font-bold text-slate-400 uppercase">Religion</p><p className="text-sm font-black">{selectedStudent.religion}</p></div>
                       <div><p className="text-[9px] font-bold text-slate-400 uppercase">Gender</p><p className="text-sm font-black">{selectedStudent.gender}</p></div>
                    </div>
                 </div>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default StudentManagement;
