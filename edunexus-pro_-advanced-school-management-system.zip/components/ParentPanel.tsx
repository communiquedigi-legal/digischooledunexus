
import React, { useState } from 'react';
import { 
  User, BookOpen, CreditCard, ShieldCheck, Download, Upload, Send, 
  MessageSquare, Heart, IndianRupee, Bus, Home, Star, Trophy, Clock,
  Calendar, FileText, CheckCircle2, AlertCircle, ChevronRight, Share2, Plus, Info, Landmark,
  LayoutDashboard, Bell, CheckSquare, Activity, Receipt, CreditCard as CardIcon,
  Navigation, MapPin, Smartphone, Shield, DownloadCloud
} from 'lucide-react';
import { MOCK_HOMEWORK } from '../constants';

const ParentPanel: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'home' | 'academic' | 'finance' | 'services' | 'profile'>('home');

  const feeHistory = [
    { id: 'TXN-8821', date: '15 Sep 2023', amount: 12000, mode: 'Online', status: 'Success' },
    { id: 'TXN-4412', date: '10 Jul 2023', amount: 15000, mode: 'Cheque', status: 'Success' },
    { id: 'TXN-1092', date: '02 Apr 2023', amount: 8000, mode: 'Cash', status: 'Success' },
  ];

  return (
    <div className="p-4 md:p-8 space-y-6 md:space-y-10 max-w-7xl mx-auto overflow-x-hidden">
      <div className="flex flex-col lg:flex-row lg:justify-between lg:items-center gap-6">
        <div className="flex items-center gap-4 md:gap-6">
           <img src="https://picsum.photos/seed/student1001/200" className="w-14 h-14 md:w-24 md:h-24 rounded-2xl md:rounded-[2.5rem] border-4 border-white shadow-2xl" alt="" />
           <div>
              <h1 className="text-xl md:text-3xl font-black text-slate-900 italic uppercase tracking-tighter leading-none mb-1 md:mb-2">Aarav Sharma</h1>
              <p className="text-indigo-600 font-bold uppercase text-[8px] md:text-[10px] tracking-widest flex items-center gap-1.5 md:gap-2">
                 <Star size={10} fill="currentColor" className="md:w-3.5 md:h-3.5"/> Grade 10-A • Registry #1001
              </p>
           </div>
        </div>
        <div className="flex bg-white p-1 rounded-xl md:rounded-2xl border border-slate-200 shadow-sm overflow-x-auto no-print scrollbar-hide">
           <div className="flex min-w-max">
             {[
               { id: 'home', label: 'Home', icon: <LayoutDashboard size={14}/> },
               { id: 'academic', label: 'Academic', icon: <BookOpen size={14}/> },
               { id: 'finance', label: 'Finance', icon: <CreditCard size={14}/> },
               { id: 'services', label: 'Services', icon: <Bus size={14}/> },
               { id: 'profile', label: 'Profile', icon: <User size={14}/> }
             ].map(t => (
               <button 
                 key={t.id}
                 onClick={() => setActiveTab(t.id as any)}
                 className={`px-4 md:px-8 py-2 md:py-2.5 rounded-lg md:rounded-xl text-[10px] md:text-xs font-black transition-all flex items-center gap-2 whitespace-nowrap ${activeTab === t.id ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}
               >
                  {t.icon} {t.label}
               </button>
             ))}
           </div>
        </div>
      </div>

      {activeTab === 'home' && (
        <div className="space-y-6 md:space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
           <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
              <div className="bg-indigo-600 p-6 md:p-8 rounded-[1.5rem] md:rounded-[2.5rem] text-white shadow-xl shadow-indigo-500/20 relative overflow-hidden group">
                 <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform"><BookOpen size={60} className="md:w-20 md:h-20" /></div>
                 <p className="text-[10px] font-black text-indigo-200 uppercase tracking-widest mb-1">Missions Pending</p>
                 <h3 className="text-2xl md:text-3xl font-black">{MOCK_HOMEWORK.filter(h => h.status === 'Pending').length} Assignments</h3>
                 <button onClick={() => setActiveTab('academic')} className="mt-4 text-[9px] md:text-[10px] font-black uppercase text-indigo-100 hover:text-white transition-colors flex items-center gap-2">Go to Academic Zone <ChevronRight size={12}/></button>
              </div>
              <div className="bg-white p-6 md:p-8 rounded-[1.5rem] md:rounded-[2.5rem] border border-slate-100 shadow-sm flex flex-col justify-between">
                 <div>
                    <p className="text-[10px] font-black text-rose-500 uppercase tracking-widest mb-1">Outstanding Fees</p>
                    <h3 className="text-2xl md:text-3xl font-black text-slate-900">₹8,400</h3>
                 </div>
                 <button onClick={() => setActiveTab('finance')} className="mt-4 w-full py-2.5 md:py-3 bg-rose-50 text-rose-600 rounded-lg md:rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-rose-100 transition-all">Settle Dues Now</button>
              </div>
              <div className="bg-slate-900 p-6 md:p-8 rounded-[1.5rem] md:rounded-[2.5rem] text-white shadow-xl relative overflow-hidden group sm:col-span-2 lg:col-span-1">
                 <div className="absolute top-0 right-0 p-4 opacity-10"><Clock size={60} className="md:w-20 md:h-20" /></div>
                 <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Attendance Status</p>
                 <h3 className="text-2xl md:text-3xl font-black">94.2%</h3>
                 <p className="text-[10px] text-emerald-400 font-bold uppercase mt-2">Excellent Attendance</p>
              </div>
           </div>

           <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
              <div className="bg-white p-6 md:p-10 rounded-[1.5rem] md:rounded-[3rem] border border-slate-100 shadow-sm">
                 <div className="flex justify-between items-center mb-6 md:mb-8">
                    <h3 className="text-lg md:text-xl font-black text-slate-900 flex items-center gap-3"><Bell className="text-indigo-600" size={20}/> Recent Notices</h3>
                 </div>
                 <div className="space-y-4 md:space-y-6">
                    <div className="p-4 md:p-6 bg-slate-50 rounded-2xl md:rounded-3xl border border-slate-100">
                       <p className="text-[10px] font-black text-indigo-600 uppercase tracking-widest mb-1">Academic</p>
                       <h4 className="font-black text-slate-900 mb-2 text-sm md:text-base">Winter Uniform Guidelines</h4>
                       <p className="text-[11px] md:text-xs text-slate-500 font-medium leading-relaxed">Please ensure students wear the proper winter vest and blazer from Nov 1st.</p>
                    </div>
                    <div className="p-4 md:p-6 bg-slate-50 rounded-2xl md:rounded-3xl border border-slate-100">
                       <p className="text-[10px] font-black text-emerald-600 uppercase tracking-widest mb-1">Events</p>
                       <h4 className="font-black text-slate-900 mb-2 text-sm md:text-base">Annual Sports Meet 2023</h4>
                       <p className="text-[11px] md:text-xs text-slate-500 font-medium leading-relaxed">Registrations for 100m sprint and high jump close this Friday.</p>
                    </div>
                 </div>
              </div>

              <div className="bg-white p-6 md:p-10 rounded-[1.5rem] md:rounded-[3rem] border border-slate-100 shadow-sm flex flex-col">
                 <h3 className="text-lg md:text-xl font-black text-slate-900 mb-6 md:mb-8 flex items-center gap-3"><Activity className="text-rose-500" size={20}/> Today's Class Sync</h3>
                 <div className="space-y-4 flex-1">
                    <div className="p-4 md:p-6 bg-indigo-50 border border-indigo-100 rounded-2xl md:rounded-3xl relative overflow-hidden group">
                       <div className="absolute top-0 right-0 p-4 opacity-5 rotate-12"><Activity size={40}/></div>
                       <p className="text-[10px] font-black text-indigo-600 uppercase tracking-widest mb-1">Ongoing Period</p>
                       <h4 className="text-base md:text-lg font-black text-slate-900">Mathematics • Trigonometry</h4>
                       <p className="text-[11px] md:text-xs text-slate-500 mt-1 font-medium">Dr. Sarah Connor • Room 402B</p>
                    </div>
                    <div className="p-4 md:p-6 bg-slate-50 border border-slate-100 rounded-2xl md:rounded-3xl opacity-50">
                       <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Next: 12:30 PM</p>
                       <h4 className="text-base md:text-lg font-black text-slate-900">Physics Lab</h4>
                       <p className="text-[11px] md:text-xs text-slate-500 mt-1 font-medium">Amit Gupta • Lab 2</p>
                    </div>
                 </div>
              </div>
           </div>
        </div>
      )}

      {activeTab === 'academic' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8 animate-in slide-in-from-bottom-4 duration-500">
           <div className="lg:col-span-2 space-y-6 md:space-y-8">
              <div className="bg-white p-6 md:p-10 rounded-[1.5rem] md:rounded-[3rem] border border-slate-100 shadow-sm">
                 <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 mb-8 md:mb-10">
                    <h3 className="text-xl md:text-2xl font-black text-slate-900 flex items-center gap-3"><BookOpen className="text-indigo-600" size={24}/> Homework</h3>
                    <div className="flex gap-2">
                       <span className="px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-[9px] font-black uppercase tracking-widest">Active Sync</span>
                    </div>
                 </div>
                 <div className="space-y-4 md:space-y-6">
                    {MOCK_HOMEWORK.map((hw) => (
                      <div key={hw.id} className="p-4 md:p-6 bg-slate-50 border border-slate-100 rounded-[1.5rem] md:rounded-[2rem] hover:border-indigo-300 transition-all group">
                         <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                            <div className="flex items-center gap-4 md:gap-6">
                               <div className={`w-10 h-10 md:w-12 md:h-12 rounded-xl md:rounded-2xl flex items-center justify-center text-white shadow-lg ${hw.status === 'Submitted' ? 'bg-emerald-500' : 'bg-indigo-500'}`}>
                                  {hw.status === 'Submitted' ? <CheckSquare size={18}/> : <FileText size={18}/>}
                               </div>
                               <div>
                                  <p className="font-black text-slate-900 text-sm md:text-base">{hw.title}</p>
                                  <p className="text-[10px] font-bold text-slate-400 uppercase">{hw.subject} • by {hw.teacher}</p>
                               </div>
                            </div>
                            <div className="text-left md:text-right">
                               <p className="text-[10px] font-black text-rose-500 uppercase tracking-tighter">Due: {hw.dueDate}</p>
                               <span className={`mt-1 inline-block px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-widest ${hw.status === 'Submitted' ? 'bg-emerald-100 text-emerald-600' : 'bg-amber-100 text-amber-600'}`}>
                                  {hw.status}
                               </span>
                            </div>
                         </div>
                         <p className="mt-3 md:mt-4 text-[11px] md:text-xs text-slate-500 leading-relaxed font-medium italic">"{hw.description}"</p>
                         <div className="mt-4 md:mt-6 flex gap-2 md:gap-3">
                            <button className="flex-1 py-2.5 md:py-3 bg-indigo-600 text-white rounded-lg md:rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2">
                               <Upload size={14}/> {hw.status === 'Submitted' ? 'Update' : 'Upload'}
                            </button>
                            <button className="px-4 py-2.5 md:py-3 bg-white border border-slate-200 text-slate-400 rounded-lg md:rounded-xl hover:text-indigo-600 transition-colors">
                               <MessageSquare size={14}/>
                            </button>
                         </div>
                      </div>
                    ))}
                 </div>
              </div>
           </div>
           <div className="space-y-6 md:space-y-8">
              <div className="bg-white p-6 md:p-10 rounded-[1.5rem] md:rounded-[3rem] border border-slate-100 shadow-sm">
                 <div className="flex justify-between items-center mb-6">
                    <h3 className="text-lg md:text-xl font-black text-slate-900 uppercase">Requests</h3>
                    <button className="p-2 bg-indigo-50 text-indigo-600 rounded-xl hover:bg-indigo-600 hover:text-white transition-all"><Plus size={18}/></button>
                 </div>
                 <div className="space-y-4">
                    <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-2xl flex items-start gap-3">
                       <CheckCircle2 size={20} className="text-emerald-500 shrink-0 mt-0.5"/>
                       <div>
                          <p className="text-[9px] font-black text-emerald-700 uppercase tracking-widest">Approved</p>
                          <p className="text-xs font-black text-slate-900 mt-1">Medical Leave • 24 Oct</p>
                       </div>
                    </div>
                 </div>
              </div>
           </div>
        </div>
      )}

      {activeTab === 'finance' && (
        <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
                 <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Annual Fee</p>
                 <h3 className="text-3xl font-black text-slate-900">₹45,000</h3>
                 <div className="mt-4 flex items-center gap-2">
                    <div className="h-1.5 flex-1 bg-slate-100 rounded-full overflow-hidden">
                       <div className="h-full bg-indigo-600" style={{width: '80%'}}></div>
                    </div>
                    <span className="text-[9px] font-black text-indigo-600">80%</span>
                 </div>
              </div>
              <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
                 <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Paid to Date</p>
                 <h3 className="text-3xl font-black text-emerald-600">₹36,600</h3>
                 <p className="text-[9px] font-bold text-slate-400 mt-1 uppercase">Verified Legacy Entries</p>
              </div>
              <div className="bg-rose-50 p-8 rounded-[2.5rem] border border-rose-100 shadow-sm relative overflow-hidden group">
                 <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:scale-110 transition-transform"><AlertCircle size={60} /></div>
                 <p className="text-[10px] font-black text-rose-500 uppercase tracking-widest mb-1">Due Amount</p>
                 <h3 className="text-3xl font-black text-rose-600">₹8,400</h3>
                 <button className="mt-3 px-4 py-1.5 bg-rose-600 text-white rounded-lg text-[8px] font-black uppercase tracking-widest shadow-lg shadow-rose-900/20">PAY NOW</button>
              </div>
              <div className="bg-slate-900 p-8 rounded-[2.5rem] text-white shadow-xl relative overflow-hidden group">
                 <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:rotate-12 transition-transform"><CardIcon size={60} /></div>
                 <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-1">Next Cycle</p>
                 <h3 className="text-3xl font-black">01 Nov</h3>
                 <p className="text-[9px] text-slate-500 uppercase mt-1">Institutional Billing Node</p>
              </div>
           </div>

           <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 bg-white rounded-[3.5rem] border border-slate-100 shadow-sm overflow-hidden">
                 <div className="p-10 border-b border-slate-50 bg-slate-50/30 flex justify-between items-center">
                    <h3 className="text-xl font-black text-slate-900 uppercase italic flex items-center gap-3">
                       <Receipt className="text-indigo-600" size={20}/> Transaction Ledger
                    </h3>
                    <button className="p-2.5 bg-white border border-slate-200 text-slate-400 rounded-xl hover:text-indigo-600 transition-colors shadow-sm"><Download size={18}/></button>
                 </div>
                 <div className="overflow-x-auto">
                    <table className="w-full text-left">
                       <thead className="bg-slate-50 text-slate-400 text-[9px] font-black uppercase tracking-widest border-b border-slate-100">
                          <tr>
                             <th className="px-10 py-6">Reference ID</th>
                             <th className="px-10 py-6">Date</th>
                             <th className="px-10 py-6">Mode</th>
                             <th className="px-10 py-6">Fiscal Amount</th>
                             <th className="px-10 py-6 text-right">Receipt</th>
                          </tr>
                       </thead>
                       <tbody className="divide-y divide-slate-100">
                          {feeHistory.map(txn => (
                            <tr key={txn.id} className="hover:bg-slate-50/50 transition-colors">
                               <td className="px-10 py-6 font-black text-slate-900 text-xs">{txn.id}</td>
                               <td className="px-10 py-6 text-xs font-bold text-slate-500 uppercase">{txn.date}</td>
                               <td className="px-10 py-6"><span className="px-2.5 py-1 bg-slate-100 rounded-lg text-[9px] font-black uppercase text-slate-600">{txn.mode}</span></td>
                               <td className="px-10 py-6 font-black text-slate-900 text-sm">₹{txn.amount.toLocaleString()}</td>
                               <td className="px-10 py-6 text-right">
                                  <button className="p-2 text-indigo-400 hover:text-indigo-600 transition-colors"><FileText size={18}/></button>
                               </td>
                            </tr>
                          ))}
                       </tbody>
                    </table>
                 </div>
              </div>

              <div className="space-y-8">
                 <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm relative overflow-hidden group">
                    <h4 className="text-lg font-black text-slate-900 mb-6 border-b border-slate-50 pb-4">Fee Structure Breakdown</h4>
                    <div className="space-y-4">
                       {[
                         { label: 'Tuition Fee', amount: 25000 },
                         { label: 'Infrastructure', amount: 8000 },
                         { label: 'Activity Fund', amount: 4500 },
                         { label: 'Digital Access', amount: 3500 },
                         { label: 'Transport Sync', amount: 4000 }
                       ].map((item, i) => (
                         <div key={i} className="flex justify-between items-center text-xs">
                            <span className="text-slate-400 font-bold uppercase">{item.label}</span>
                            <span className="font-black text-slate-900">₹{item.amount.toLocaleString()}</span>
                         </div>
                       ))}
                       <div className="pt-6 border-t-2 border-slate-900 mt-6 flex justify-between items-center">
                          <span className="text-sm font-black uppercase text-slate-900">Annual Total</span>
                          <span className="text-xl font-black text-indigo-600">₹45,000</span>
                       </div>
                    </div>
                 </div>
                 <div className="bg-indigo-900 p-8 rounded-[3rem] text-white shadow-2xl relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-4 opacity-10"><Shield size={60}/></div>
                    <h4 className="text-lg font-black mb-4 flex items-center gap-2"><Smartphone size={18} className="text-indigo-400" /> Digital Wallet Active</h4>
                    <p className="text-xs text-indigo-200 leading-relaxed font-medium mb-8">Save payment methods for instant 1-tap fee settlements next month.</p>
                    <button className="w-full py-4 bg-indigo-500 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-indigo-950/50 hover:bg-indigo-400 transition-all">Configure Wallet</button>
                 </div>
              </div>
           </div>
        </div>
      )}

      {activeTab === 'services' && (
        <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
           <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Transport Node */}
              <div className="bg-white p-10 rounded-[4rem] border border-slate-100 shadow-sm relative overflow-hidden group">
                 <div className="absolute top-0 right-0 w-48 h-48 bg-indigo-50 rounded-bl-[6rem] -translate-y-4 translate-x-4 opacity-40 group-hover:scale-110 transition-transform"></div>
                 <div className="flex items-center gap-6 mb-10 relative z-10">
                    <div className="p-6 bg-indigo-600 text-white rounded-[2rem] shadow-xl shadow-indigo-500/20"><Bus size={32}/></div>
                    <div>
                       <div className="bg-emerald-50 text-emerald-600 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest inline-block mb-1">Service Active</div>
                       <h3 className="text-3xl font-black text-slate-900 tracking-tight italic uppercase">Transport Logistics</h3>
                    </div>
                 </div>

                 <div className="grid grid-cols-2 gap-8 mb-10 relative z-10">
                    <div className="space-y-4">
                       <div><p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Assigned Route</p><p className="text-lg font-black text-slate-900 leading-none">R-42: North City Express</p></div>
                       <div><p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Pickup Stop</p><p className="text-sm font-black text-indigo-600 leading-none flex items-center gap-2"><MapPin size={12}/> Main Gate Sector-A</p></div>
                    </div>
                    <div className="space-y-4">
                       <div><p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Vehicle Plate</p><p className="text-lg font-black text-slate-900 leading-none">DL 12 AT 4501</p></div>
                       <div><p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Staff Context</p><p className="text-sm font-black text-slate-700 leading-none uppercase">Karan S. (Driver)</p></div>
                    </div>
                 </div>

                 <div className="p-6 bg-slate-50 rounded-[2.5rem] border border-slate-100 relative z-10">
                    <div className="flex justify-between items-center mb-6">
                       <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Real-time Node Status</p>
                       <span className="flex items-center gap-1.5 px-3 py-1 bg-white rounded-full text-[9px] font-black text-rose-500 shadow-sm animate-pulse">
                          <div className="w-1.5 h-1.5 bg-rose-500 rounded-full"></div> LIVE SYNC
                       </span>
                    </div>
                    <div className="flex items-center justify-between">
                       <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-indigo-600 shadow-sm"><Navigation size={24}/></div>
                          <div>
                             <p className="text-sm font-black text-slate-900">Current Position</p>
                             <p className="text-[10px] font-bold text-slate-500 uppercase">Approaching Clock Tower stop</p>
                          </div>
                       </div>
                       <button className="p-4 bg-indigo-600 text-white rounded-2xl shadow-lg shadow-indigo-500/20 hover:scale-110 transition-transform"><Smartphone size={20}/></button>
                    </div>
                 </div>
              </div>

              {/* Hostel Node */}
              <div className="bg-white p-10 rounded-[4rem] border border-slate-100 shadow-sm relative overflow-hidden group">
                 <div className="absolute top-0 right-0 w-48 h-48 bg-rose-50 rounded-bl-[6rem] -translate-y-4 translate-x-4 opacity-40 group-hover:scale-110 transition-transform"></div>
                 <div className="flex items-center gap-6 mb-10 relative z-10">
                    <div className="p-6 bg-rose-600 text-white rounded-[2rem] shadow-xl shadow-rose-500/20"><Home size={32}/></div>
                    <div>
                       <div className="bg-slate-100 text-slate-400 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest inline-block mb-1">Inactive Node</div>
                       <h3 className="text-3xl font-black text-slate-900 tracking-tight italic uppercase">Hostel Residency</h3>
                    </div>
                 </div>
                 
                 <div className="p-12 text-center border-2 border-dashed border-slate-100 rounded-[3rem] relative z-10">
                    <Info size={48} className="text-slate-100 mx-auto mb-6"/>
                    <p className="text-xl font-black text-slate-300 italic uppercase tracking-tighter mb-2">Residency Data Empty</p>
                    <p className="text-xs font-medium text-slate-400 max-w-[240px] mx-auto leading-relaxed">Student #1001 is currently registered as a Day Scholar. Access is restricted.</p>
                    <button className="mt-10 px-8 py-4 bg-slate-900 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl shadow-slate-900/10 hover:bg-rose-600 transition-all">Submit Hosteler Request</button>
                 </div>
              </div>
           </div>

           <div className="bg-slate-950 p-12 rounded-[4.5rem] text-white shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-indigo-500/10 rounded-full blur-[120px] -translate-y-48 translate-x-48"></div>
              <div className="flex flex-col lg:flex-row items-center justify-between gap-16 relative z-10">
                 <div className="max-w-2xl">
                    <h3 className="text-5xl font-black mb-8 leading-[1.1] tracking-tighter">Verified Institutional Credentials</h3>
                    <p className="text-slate-400 text-xl leading-relaxed mb-12 font-medium">Access high-security identity transcipts, performance reports and verified merit certifications via our encrypted blockchain ledger.</p>
                    <div className="flex flex-wrap gap-6">
                       <button onClick={() => alert('Generating full identity transcript...')} className="px-12 py-6 bg-indigo-600 rounded-[2.5rem] font-black text-sm uppercase tracking-widest shadow-2xl shadow-indigo-900/50 hover:bg-indigo-500 transition-all active:scale-95 flex items-center gap-3">
                          <DownloadCloud size={20}/> Fetch ID TRANSCRIPT
                       </button>
                    </div>
                 </div>
                 <div className="w-full lg:w-[400px] aspect-[4/5] bg-white/5 border border-white/10 rounded-[4rem] p-12 backdrop-blur-xl flex flex-col group/card hover:border-indigo-500/50 transition-all shadow-2xl">
                    <div className="w-full h-1/2 bg-slate-800/50 rounded-[3rem] mb-12 flex items-center justify-center border border-white/5 shadow-inner">
                       <ShieldCheck size={120} className="text-slate-700 group-hover/card:text-indigo-400 transition-all duration-700 group-hover/card:scale-110" />
                    </div>
                    <div className="space-y-5">
                       <div className="h-4 w-3/4 bg-slate-700/50 rounded-full"></div>
                       <div className="h-4 w-1/2 bg-slate-700/30 rounded-full"></div>
                       <div className="h-4 w-5/6 bg-slate-700/20 rounded-full"></div>
                    </div>
                    <div className="mt-auto pt-12 border-t border-white/10 flex justify-between items-center">
                       <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Digital Auth Code</span>
                       <div className="w-12 h-12 bg-emerald-500/20 rounded-2xl flex items-center justify-center shadow-lg"><CheckCircle2 size={24} className="text-emerald-500" /></div>
                    </div>
                 </div>
              </div>
           </div>
        </div>
      )}
      
      {activeTab === 'academic' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8 animate-in slide-in-from-bottom-4 duration-500">
           <div className="lg:col-span-2 space-y-6 md:space-y-8">
              <div className="bg-white p-6 md:p-10 rounded-[1.5rem] md:rounded-[3rem] border border-slate-100 shadow-sm">
                 <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 mb-8 md:mb-10">
                    <h3 className="text-xl md:text-2xl font-black text-slate-900 flex items-center gap-3"><BookOpen className="text-indigo-600" size={24}/> Homework</h3>
                    <div className="flex gap-2">
                       <span className="px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-[9px] font-black uppercase tracking-widest">Active Sync</span>
                    </div>
                 </div>
                 <div className="space-y-4 md:space-y-6">
                    {MOCK_HOMEWORK.map((hw) => (
                      <div key={hw.id} className="p-4 md:p-6 bg-slate-50 border border-slate-100 rounded-[1.5rem] md:rounded-[2rem] hover:border-indigo-300 transition-all group">
                         <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                            <div className="flex items-center gap-4 md:gap-6">
                               <div className={`w-10 h-10 md:w-12 md:h-12 rounded-xl md:rounded-2xl flex items-center justify-center text-white shadow-lg ${hw.status === 'Submitted' ? 'bg-emerald-500' : 'bg-indigo-500'}`}>
                                  {hw.status === 'Submitted' ? <CheckSquare size={18}/> : <FileText size={18}/>}
                               </div>
                               <div>
                                  <p className="font-black text-slate-900 text-sm md:text-base">{hw.title}</p>
                                  <p className="text-[10px] font-bold text-slate-400 uppercase">{hw.subject} • by {hw.teacher}</p>
                               </div>
                            </div>
                            <div className="text-left md:text-right">
                               <p className="text-[10px] font-black text-rose-500 uppercase tracking-tighter">Due: {hw.dueDate}</p>
                               <span className={`mt-1 inline-block px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-widest ${hw.status === 'Submitted' ? 'bg-emerald-100 text-emerald-600' : 'bg-amber-100 text-amber-600'}`}>
                                  {hw.status}
                               </span>
                            </div>
                         </div>
                         <p className="mt-3 md:mt-4 text-[11px] md:text-xs text-slate-500 leading-relaxed font-medium italic">"{hw.description}"</p>
                         <div className="mt-4 md:mt-6 flex gap-2 md:gap-3">
                            <button className="flex-1 py-2.5 md:py-3 bg-indigo-600 text-white rounded-lg md:rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2">
                               <Upload size={14}/> {hw.status === 'Submitted' ? 'Update' : 'Upload'}
                            </button>
                            <button className="px-4 py-2.5 md:py-3 bg-white border border-slate-200 text-slate-400 rounded-lg md:rounded-xl hover:text-indigo-600 transition-colors">
                               <MessageSquare size={14}/>
                            </button>
                         </div>
                      </div>
                    ))}
                 </div>
              </div>
           </div>
           <div className="space-y-6 md:space-y-8">
              <div className="bg-white p-6 md:p-10 rounded-[1.5rem] md:rounded-[3rem] border border-slate-100 shadow-sm">
                 <div className="flex justify-between items-center mb-6">
                    <h3 className="text-lg md:text-xl font-black text-slate-900 uppercase">Requests</h3>
                    <button className="p-2 bg-indigo-50 text-indigo-600 rounded-xl hover:bg-indigo-600 hover:text-white transition-all"><Plus size={18}/></button>
                 </div>
                 <div className="space-y-4">
                    <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-2xl flex items-start gap-3">
                       <CheckCircle2 size={20} className="text-emerald-500 shrink-0 mt-0.5"/>
                       <div>
                          <p className="text-[9px] font-black text-emerald-700 uppercase tracking-widest">Approved</p>
                          <p className="text-xs font-black text-slate-900 mt-1">Medical Leave • 24 Oct</p>
                       </div>
                    </div>
                 </div>
              </div>
           </div>
        </div>
      )}
      
      {activeTab === 'profile' && (
        <div className="max-w-3xl mx-auto space-y-6 md:space-y-8 animate-in fade-in px-2">
           <div className="bg-white p-6 md:p-10 rounded-[1.5rem] md:rounded-[3rem] border border-slate-100 shadow-sm">
              <h3 className="text-xl md:text-2xl font-black text-slate-900 mb-6 md:mb-8 border-b border-slate-50 pb-4">Personal Archive</h3>
              <div className="space-y-4 md:space-y-6">
                 {[
                   { label: 'D.O.B', val: '20 Aug 2015' },
                   { label: 'Blood', val: 'O+' },
                   { label: 'Guardian', val: 'Sharma Family' },
                   { label: 'Contact', val: '+91 91001005' },
                 ].map((item, i) => (
                   <div key={i} className="flex justify-between items-center py-1">
                      <span className="text-[10px] md:text-xs font-bold text-slate-400 uppercase tracking-widest">{item.label}</span>
                      <span className="text-xs md:text-sm font-black text-slate-700">{item.val}</span>
                   </div>
                 ))}
              </div>
              <button className="mt-8 md:mt-10 w-full py-4 bg-slate-50 border border-slate-200 text-slate-400 rounded-xl md:rounded-2xl text-[9px] md:text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2">
                 <ShieldCheck size={14}/> Verified Identity
              </button>
           </div>
        </div>
      )}
    </div>
  );
};

export default ParentPanel;
