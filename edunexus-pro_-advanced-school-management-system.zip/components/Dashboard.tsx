
import React, { useState, useMemo } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, AreaChart, Area
} from 'recharts';
import { 
  Users, BookOpen, CreditCard, TrendingUp, Bell, Calendar, 
  ShieldCheck, Activity, Clock, ChevronRight, Award, UserCheck, 
  AlertTriangle, IndianRupee, MapPin, GraduationCap, Briefcase, Search,
  CheckCircle2, Timer, School, BarChart2, Video, ExternalLink,
  // Added missing UserPlus import
  Target, Zap, Globe, Sparkles, Landmark, Trophy, Plus, Layers, UserPlus
} from 'lucide-react';
import { AcademicSession } from '../types';
import { MOCK_STUDENTS, MOCK_STAFF, CLASS_LIST, SECTION_LIST } from '../constants';

interface DashboardProps {
  session: AcademicSession;
  onNavigate?: (tabId: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ session, onNavigate }) => {
  const [selectedClass, setSelectedClass] = useState('10');
  const [selectedSection, setSelectedSection] = useState('A');

  const classStudents = useMemo(() => 
    MOCK_STUDENTS.filter(s => s.class === selectedClass && s.section === selectedSection),
    [selectedClass, selectedSection]
  );

  const assignedTeachers = useMemo(() => {
    const subjects = ['Mathematics', 'Physics', 'Chemistry', 'English', 'History'];
    return MOCK_STAFF.filter(s => subjects.includes(s.subject)).slice(0, 5);
  }, []);

  const classStrength = classStudents.length;
  
  const classPerformance = [
    { subject: 'Math', avg: 78, high: 98 },
    { subject: 'Physics', avg: 82, high: 95 },
    { subject: 'Chem', avg: 75, high: 92 },
    { subject: 'English', avg: 88, high: 96 },
  ];

  const cashflowData = [
    { name: 'Week 1', amount: 120000 },
    { name: 'Week 2', amount: 450000 },
    { name: 'Week 3', amount: 280000 },
    { name: 'Week 4', amount: 890000 },
  ];

  const quickActions = [
    { id: 'students', label: 'Add Student', icon: <UserPlus className="text-emerald-500" size={24}/>, desc: 'Enroll New Pupil' },
    { id: 'hr', label: 'Add Teacher', icon: <GraduationCap className="text-indigo-500" size={24}/>, desc: 'Faculty Recruitment' },
    { id: 'academics', label: 'Establish Class', icon: <School className="text-amber-500" size={24}/>, desc: 'Setup Wing Level' },
    { id: 'academics', label: 'Deploy Section', icon: <Layers className="text-sky-500" size={24}/>, desc: 'Establish Sec §' }
  ];

  return (
    <div className="p-4 md:p-8 space-y-6 md:space-y-10 max-w-[1600px] mx-auto overflow-x-hidden">
      {/* Top Banner */}
      <div className="bg-slate-900 p-8 md:p-16 rounded-[2.5rem] md:rounded-[5rem] text-white flex flex-col lg:flex-row justify-between items-center gap-10 relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-indigo-500/10 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/2 -z-0"></div>
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-emerald-500/10 rounded-full blur-[100px] translate-y-1/2 -translate-x-1/2 -z-0"></div>
        
        <div className="relative z-10 flex flex-col items-center lg:items-start text-center lg:text-left">
          <div className="bg-indigo-600/30 text-indigo-400 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.3em] inline-flex items-center gap-2 mb-6 border border-white/5">
             <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-pulse"></div>
             Institutional Intelligence Sync
          </div>
          <h1 className="text-4xl md:text-7xl font-black italic tracking-tighter leading-none mb-6">Mission <span className="text-indigo-400 underline decoration-indigo-500/30 underline-offset-8">Control</span></h1>
          <p className="text-slate-400 text-base md:text-xl font-medium max-w-xl leading-relaxed">Centralized management for academic fidelity, fiscal stability, and workforce optimization.</p>
          
          <div className="flex gap-4 mt-10">
             <div className="px-6 py-3 bg-white/5 border border-white/10 rounded-2xl flex items-center gap-3 backdrop-blur-md">
                <Users className="text-indigo-400" size={20}/>
                <div><p className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Enrollment</p><p className="text-lg font-black italic">1,240 Nodes</p></div>
             </div>
             <div className="px-6 py-3 bg-white/5 border border-white/10 rounded-2xl flex items-center gap-3 backdrop-blur-md">
                <Landmark className="text-emerald-400" size={20}/>
                <div><p className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Equity</p><p className="text-lg font-black italic">₹1.2Cr</p></div>
             </div>
          </div>
        </div>

        <div className="relative z-10 grid grid-cols-2 gap-4 md:gap-6 w-full lg:w-auto">
           <div className="bg-white/5 border border-white/10 p-6 rounded-[2rem] md:rounded-[3rem] backdrop-blur-xl group hover:border-indigo-500/50 transition-all">
              <h3 className="text-[9px] font-black text-indigo-400 uppercase tracking-widest mb-4">Faculty Pulse</h3>
              <div className="h-24 w-24 md:h-32 md:w-32 mx-auto relative flex items-center justify-center">
                 <div className="absolute inset-0 rounded-full border-4 border-white/5"></div>
                 <div className="absolute inset-0 rounded-full border-4 border-indigo-50 border-t-transparent animate-spin-slow"></div>
                 <div className="text-center">
                    <p className="text-2xl md:text-4xl font-black italic">98%</p>
                    <p className="text-[8px] font-bold text-slate-500 uppercase">Active</p>
                 </div>
              </div>
           </div>
           <div className="bg-white/5 border border-white/10 p-6 rounded-[2rem] md:rounded-[3rem] backdrop-blur-xl group hover:border-emerald-500/50 transition-all">
              <h3 className="text-[9px] font-black text-emerald-400 uppercase tracking-widest mb-4">Student Hub</h3>
              <div className="space-y-4">
                 <div className="flex items-center gap-3"><div className="w-2 h-2 rounded-full bg-emerald-500"></div><span className="text-[10px] font-black uppercase tracking-tighter">Present: 1140</span></div>
                 <div className="flex items-center gap-3"><div className="w-2 h-2 rounded-full bg-rose-500"></div><span className="text-[10px] font-black uppercase tracking-tighter">Absent: 100</span></div>
                 <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden mt-4"><div className="h-full bg-emerald-500" style={{width: '91%'}}></div></div>
              </div>
           </div>
        </div>
      </div>

      {/* Quick Actions Sector */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {quickActions.map((action, idx) => (
          <button 
            key={idx}
            onClick={() => onNavigate?.(action.id)}
            className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm flex flex-col items-center text-center group hover:shadow-2xl hover:scale-105 hover:bg-indigo-600 transition-all duration-300"
          >
            <div className="p-5 bg-slate-50 rounded-2xl mb-6 group-hover:bg-white transition-all transform group-hover:rotate-12">
              {action.icon}
            </div>
            <h4 className="text-lg font-black text-slate-900 group-hover:text-white uppercase italic tracking-tighter">{action.label}</h4>
            <p className="text-[10px] font-medium text-slate-400 group-hover:text-indigo-200 uppercase tracking-widest mt-1">{action.desc}</p>
          </button>
        ))}
      </div>

      {/* Grid Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-10">
        <div className="lg:col-span-2 space-y-6 md:space-y-10">
           <div className="bg-white p-6 md:p-8 rounded-[2rem] md:rounded-[3.5rem] border border-slate-100 shadow-xl shadow-slate-200/50 flex flex-col md:flex-row justify-between items-center gap-6">
              <div className="flex items-center gap-5">
                 <div className="p-4 bg-indigo-50 text-indigo-600 rounded-[1.2rem] shadow-inner"><Activity size={24}/></div>
                 <div>
                    <h3 className="text-xl font-black text-slate-900 italic tracking-tighter">Class Analytics Node</h3>
                    <p className="text-xs font-medium text-slate-400 uppercase tracking-widest">Target grade context</p>
                 </div>
              </div>
              <div className="flex gap-4 bg-slate-50 p-2 rounded-2xl md:rounded-[2rem] border border-slate-200/50 w-full md:w-auto">
                <select value={selectedClass} onChange={(e) => setSelectedClass(e.target.value)} className="flex-1 px-6 py-2.5 bg-white border-none rounded-xl md:rounded-[1.5rem] font-black text-xs md:text-sm outline-none shadow-sm min-w-[100px]">{CLASS_LIST.map(c => <option key={c} value={c}>Grade {c}</option>)}</select>
                <select value={selectedSection} onChange={(e) => setSelectedSection(e.target.value)} className="flex-1 px-6 py-2.5 bg-white border-none rounded-xl md:rounded-[1.5rem] font-black text-xs md:text-sm outline-none shadow-sm min-w-[80px]">{SECTION_LIST.map(s => <option key={s} value={s}>Sec {s}</option>)}</select>
              </div>
           </div>

           <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-10">
              <div className="bg-white p-8 md:p-10 rounded-[3rem] border border-slate-100 shadow-sm relative overflow-hidden group">
                 <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:scale-110 transition-transform"><Trophy size={100}/></div>
                 <h3 className="text-xl font-black text-slate-900 mb-8 uppercase italic tracking-tighter">Academic Metrics</h3>
                 <div className="h-[250px]">
                    <ResponsiveContainer width="100%" height="100%">
                       <BarChart data={classPerformance}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                          <XAxis dataKey="subject" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 10, fontWeight: 700}} dy={10} />
                          <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 10}} />
                          <Tooltip contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 10px 30px rgba(0,0,0,0.1)'}} />
                          <Bar dataKey="avg" fill="#6366f1" radius={[4, 4, 0, 0]} barSize={24} />
                          <Bar dataKey="high" fill="#10b981" radius={[4, 4, 0, 0]} barSize={24} />
                       </BarChart>
                    </ResponsiveContainer>
                 </div>
              </div>

              <div className="bg-slate-900 p-8 md:p-10 rounded-[3rem] text-white shadow-2xl relative overflow-hidden group">
                 <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:rotate-12 transition-transform"><IndianRupee size={100}/></div>
                 <h3 className="text-xl font-black text-indigo-400 mb-2 uppercase italic tracking-tighter">Fiscal Flow</h3>
                 <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] mb-8">Weekly Revenue Cycle</p>
                 <div className="h-[200px]">
                    <ResponsiveContainer width="100%" height="100%">
                       <AreaChart data={cashflowData}>
                          <defs>
                             <linearGradient id="colorAmt" x1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#6366f1" stopOpacity={0.8}/>
                                <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                             </linearGradient>
                          </defs>
                          <Area type="monotone" dataKey="amount" stroke="#6366f1" strokeWidth={3} fillOpacity={1} fill="url(#colorAmt)" />
                       </AreaChart>
                    </ResponsiveContainer>
                 </div>
                 <div className="mt-8 flex justify-between items-end">
                    <div><p className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Weekly Net</p><p className="text-3xl font-black italic">₹8.90L</p></div>
                    <button className="p-3 bg-white/10 rounded-xl hover:bg-white/20 transition-all"><ExternalLink size={18} className="text-indigo-400"/></button>
                 </div>
              </div>
           </div>
        </div>

        <div className="space-y-6 md:space-y-10">
           <div className="bg-white p-8 md:p-10 rounded-[3rem] border border-slate-100 shadow-sm">
              <div className="flex justify-between items-center mb-10">
                 <h3 className="text-xl font-black text-slate-900 uppercase italic tracking-tighter">Faculty Cluster</h3>
                 <span className="px-3 py-1 bg-emerald-50 text-emerald-600 rounded-full text-[8px] font-black uppercase animate-pulse">Live Now</span>
              </div>
              <div className="space-y-8">
                 {assignedTeachers.map((teacher) => (
                   <div key={teacher.id} className="flex items-center gap-5 group cursor-pointer">
                      <div className="relative shrink-0">
                         <img src={teacher.photoUrl} className="w-14 h-14 md:w-16 md:h-16 rounded-2xl md:rounded-[1.5rem] object-cover border-4 border-slate-50 shadow-sm group-hover:border-indigo-100 transition-all" alt="" />
                         <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-emerald-500 rounded-full border-4 border-white shadow-lg"></div>
                      </div>
                      <div className="flex-1 overflow-hidden">
                         <p className="text-sm font-black text-slate-900 truncate tracking-tight">{teacher.name}</p>
                         <p className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest mt-1">{teacher.subject}</p>
                      </div>
                      <button className="p-2.5 text-slate-300 hover:text-indigo-600 transition-colors group-hover:translate-x-1 duration-300"><ChevronRight size={18} /></button>
                   </div>
                 ))}
              </div>
           </div>

           <div className="bg-indigo-600 p-10 rounded-[3rem] text-white shadow-2xl shadow-indigo-500/30 relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-8 opacity-10 -rotate-12 transition-transform group-hover:rotate-0"><Sparkles size={100}/></div>
              <h4 className="text-2xl font-black mb-4 italic tracking-tighter">System Alert Hub</h4>
              <div className="space-y-6">
                 <div className="p-5 bg-white/10 border border-white/10 rounded-[2rem] flex items-start gap-4">
                    <div className="p-2 bg-rose-500/20 text-rose-300 rounded-lg"><AlertTriangle size={18}/></div>
                    <div><p className="text-xs font-black">Fee Overdue Notice</p><p className="text-[9px] text-indigo-200 mt-1 uppercase font-bold">12 Parents Identified</p></div>
                 </div>
                 <div className="p-5 bg-white/10 border border-white/10 rounded-[2rem] flex items-start gap-4">
                    <div className="p-2 bg-emerald-500/20 text-emerald-300 rounded-lg"><Zap size={18}/></div>
                    <div><p className="text-xs font-black">Exam Manifest Sync</p><p className="text-[9px] text-indigo-200 mt-1 uppercase font-bold">Final Term Papers Ready</p></div>
                 </div>
              </div>
           </div>
        </div>
      </div>

      <style>{`
        .animate-spin-slow { animation: spin 8s linear infinite; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
};

export default Dashboard;
