
import React, { useState, useMemo } from 'react';
import { MOCK_BOOKS, MOCK_STUDENTS, MOCK_STAFF } from '../constants';
import { LibraryBook } from '../types';
import { 
  Search, Plus, Book, Barcode, RotateCcw, AlertCircle, Bookmark, 
  CheckCircle2, X, Trash2, Save, MapPin, Globe, Wallet, ExternalLink,
  ChevronDown, Filter, Info, AlertTriangle, User, Users, Briefcase,
  History, Clock, ShieldAlert, Layers, Hash, Banknote, IndianRupee,
  CalendarDays, FileWarning, Check
} from 'lucide-react';

const LibraryManagement: React.FC = () => {
  const [books, setBooks] = useState<LibraryBook[]>(MOCK_BOOKS);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showIssueModal, setShowIssueModal] = useState<string | null>(null);
  const [showPenaltyModal, setShowPenaltyModal] = useState<{bookId: string, amount: number} | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [activeType, setActiveType] = useState<'All' | 'Physical' | 'Ebook'>('All');

  const [borrowerType, setBorrowerType] = useState<'Student' | 'Teacher' | 'Staff'>('Student');
  const [borrowerSearch, setBorrowerSearch] = useState('');

  const DAILY_LATE_FEE = 5;

  const categories = useMemo(() => {
    const cats = new Set(books.map(b => b.category));
    return ['All', ...Array.from(cats)];
  }, [books]);

  const borrowers = useMemo(() => {
    if (borrowerType === 'Student') {
      return MOCK_STUDENTS.map(s => ({ 
        id: s.id, 
        name: s.name, 
        info: `Class ${s.class}-${s.section}`,
        class: s.class,
        section: s.section,
        rollNo: s.rollNo
      }));
    }
    return MOCK_STAFF.map(s => ({ 
      id: s.id, 
      name: s.name, 
      info: s.role 
    }));
  }, [borrowerType]);

  const filteredBorrowers = borrowers.filter(b => 
    b.name.toLowerCase().includes(borrowerSearch.toLowerCase()) || 
    b.id.toLowerCase().includes(borrowerSearch.toLowerCase()) ||
    (borrowerType === 'Student' && (b as any).info.toLowerCase().includes(borrowerSearch.toLowerCase()))
  );

  const handleIssueBook = (bookId: string, borrower: any) => {
    const days = borrowerType === 'Student' ? 14 : 30;
    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + days);

    setBooks(prev => prev.map(b => {
      if (b.id === bookId) {
        return {
          ...b,
          status: 'issued',
          issuedTo: {
            id: borrower.id,
            name: borrower.name,
            role: borrowerType,
            class: borrower.class,
            section: borrower.section,
            rollNo: borrower.rollNo
          },
          dueDate: dueDate.toISOString().split('T')[0]
        };
      }
      return b;
    }));
    setShowIssueModal(null);
    setBorrowerSearch('');
  };

  const handleReturnBook = (bookId: string) => {
    setBooks(prev => prev.map(b => {
      if (b.id === bookId) {
        let lateFee = 0;
        if (b.dueDate) {
          const due = new Date(b.dueDate);
          const now = new Date();
          if (now > due) {
            const diffTime = Math.abs(now.getTime() - due.getTime());
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            lateFee = diffDays * DAILY_LATE_FEE;
          }
        }

        return {
          ...b,
          status: 'available',
          issuedTo: undefined,
          dueDate: undefined,
          penalty: (b.penalty || 0) + lateFee
        };
      }
      return b;
    }));
  };

  const applyManualPenalty = (bookId: string, amount: number) => {
    setBooks(prev => prev.map(b => 
      b.id === bookId ? { ...b, penalty: (b.penalty || 0) + amount } : b
    ));
    setShowPenaltyModal(null);
  };

  const clearPenalty = (bookId: string) => {
    setBooks(prev => prev.map(b => 
      b.id === bookId ? { ...b, penalty: 0 } : b
    ));
  };

  const handleMarkLost = (bookId: string) => {
    const penaltyAmount = 500; 
    setBooks(prev => prev.map(b => {
      if (b.id === bookId) {
        return {
          ...b,
          status: 'lost',
          penalty: (b.penalty || 0) + penaltyAmount
        };
      }
      return b;
    }));
  };

  const handleAddBook = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const type = formData.get('type') as 'Physical' | 'Ebook';
    const newBook: LibraryBook = {
      id: `B${Date.now().toString().slice(-3)}`,
      title: formData.get('title') as string,
      author: formData.get('author') as string,
      isbn: formData.get('isbn') as string,
      barcode: 'BAR-' + Math.floor(Math.random() * 900 + 100),
      category: formData.get('category') as string,
      status: 'available',
      type: type,
      rack: type === 'Physical' ? formData.get('rack') as string : undefined,
      shelf: type === 'Physical' ? formData.get('shelf') as string : undefined,
      ebookUrl: type === 'Ebook' ? formData.get('ebookUrl') as string : undefined,
    };
    setBooks([...books, newBook]);
    setShowAddModal(false);
  };

  const filteredBooks = books.filter(b => {
    const matchesSearch = b.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         b.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         b.isbn.includes(searchQuery);
    const matchesCategory = selectedCategory === 'All' || b.category === selectedCategory;
    const matchesType = activeType === 'All' || b.type === activeType;
    return matchesSearch && matchesCategory && matchesType;
  });

  const stats = {
    total: books.length,
    issued: books.filter(b => b.status === 'issued').length,
    lost: books.filter(b => b.status === 'lost').length,
    penalties: books.reduce((acc, b) => acc + (b.penalty || 0), 0)
  };

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
        <div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight italic uppercase">Institutional Library Registry</h1>
          <p className="text-slate-500 font-medium">Inventory tracking, physical stacks monitoring, and multi-user circulation hub.</p>
        </div>
        <div className="flex gap-3">
          <div className="flex bg-white p-1 rounded-2xl border border-slate-200 shadow-sm">
            {['All', 'Physical', 'Ebook'].map(t => (
              <button
                key={t}
                onClick={() => setActiveType(t as any)}
                className={`px-5 py-2 text-xs font-black rounded-xl transition-all ${activeType === t ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}
              >
                {t}s
              </button>
            ))}
          </div>
          <button onClick={() => setShowAddModal(true)} className="px-6 py-3 bg-indigo-600 text-white rounded-2xl text-sm font-black flex items-center gap-2 hover:bg-indigo-700 shadow-xl shadow-indigo-500/20 transition-all uppercase tracking-widest">
            <Plus size={18} /> Catalog Asset
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Books', value: stats.total, color: 'bg-blue-600', icon: <Book size={20} /> },
          { label: 'On Loan', value: stats.issued, color: 'bg-indigo-600', icon: <Bookmark size={20} /> },
          { label: 'Missing/Lost', value: stats.lost, color: 'bg-rose-600', icon: <AlertCircle size={20} /> },
          { label: 'Unpaid Penalties', value: `₹${stats.penalties}`, color: 'bg-amber-500', icon: <Wallet size={20} /> },
        ].map((stat, idx) => (
          <div key={idx} className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm flex items-center gap-6">
            <div className={`p-5 rounded-3xl ${stat.color} text-white shadow-xl shadow-black/5`}>{stat.icon}</div>
            <div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">{stat.label}</p>
              <h3 className="text-3xl font-black text-slate-900">{stat.value}</h3>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-[3rem] border border-slate-100 overflow-hidden shadow-sm">
        <div className="p-8 border-b border-slate-100 flex flex-wrap gap-4 items-center bg-slate-50/50">
          <div className="flex-1 relative min-w-[300px]">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300" size={20} />
            <input 
              type="text" 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by Title, Author, ISBN or Barcode..." 
              className="w-full pl-14 pr-6 py-4 bg-white border border-slate-200 rounded-[2rem] text-sm font-black focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/5 outline-none shadow-sm transition-all"
            />
          </div>
          <select 
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-8 py-4 bg-white border border-slate-200 rounded-[2rem] text-xs font-black outline-none cursor-pointer shadow-sm uppercase tracking-widest"
          >
            {categories.map(cat => <option key={cat} value={cat}>{cat} Category</option>)}
          </select>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-slate-400 text-[10px] font-black uppercase tracking-[0.2em] border-b border-slate-100">
              <tr>
                <th className="px-10 py-6">Asset Publication</th>
                <th className="px-10 py-6">Registry Info</th>
                <th className="px-10 py-6">Borrower Context</th>
                <th className="px-10 py-6">Dues & Penalties</th>
                <th className="px-10 py-6 text-center">Controls</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredBooks.map((book) => (
                <tr key={book.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-10 py-7">
                    <div className="flex items-center gap-5">
                      <div className={`w-14 h-20 rounded-2xl border flex items-center justify-center shadow-inner ${book.type === 'Ebook' ? 'bg-emerald-50 border-emerald-100 text-emerald-600' : 'bg-indigo-50 border-indigo-100 text-indigo-400'}`}>
                        {book.type === 'Ebook' ? <Globe size={28} /> : <Book size={28} />}
                      </div>
                      <div>
                        <p className="text-lg font-black text-slate-900 leading-tight">{book.title}</p>
                        <p className="text-xs text-slate-400 font-bold mt-1 uppercase tracking-tighter">by {book.author}</p>
                        <div className="flex gap-2 mt-3">
                          <span className="text-[9px] font-black text-slate-400 uppercase bg-slate-100 px-2.5 py-1 rounded-lg border border-slate-200">ISBN: {book.isbn}</span>
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-10 py-7">
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-2 text-indigo-600 text-[10px] font-black uppercase tracking-widest">
                        <Barcode size={14} /> {book.barcode}
                      </div>
                      <div className="flex items-center gap-2 text-slate-500 text-[10px] font-black uppercase tracking-widest">
                        <MapPin size={14} className="text-rose-400" /> {book.rack || 'Digital'} • {book.shelf || 'N/A'}
                      </div>
                    </div>
                  </td>
                  <td className="px-10 py-7">
                    <div className="space-y-3">
                      <span className={`text-[9px] font-black uppercase px-3 py-1 rounded-lg border inline-block tracking-widest ${
                        book.status === 'available' ? 'bg-emerald-50 border-emerald-100 text-emerald-700' : 
                        book.status === 'issued' ? 'bg-indigo-50 border-indigo-100 text-indigo-700' : 
                        'bg-rose-50 border-rose-100 text-rose-700'
                      }`}>
                        {book.status}
                      </span>
                      {book.status === 'issued' && book.issuedTo && (
                        <div className="bg-slate-50/80 p-4 rounded-2xl border border-slate-100 flex items-center gap-4">
                          <div className="w-10 h-10 bg-white rounded-xl shadow-sm flex items-center justify-center">
                            {book.issuedTo.role === 'Student' ? <Users size={18} className="text-indigo-600"/> : <Briefcase size={18} className="text-rose-500"/>}
                          </div>
                          <div>
                            <p className="text-xs font-black text-slate-900">{book.issuedTo.name}</p>
                            <div className="flex items-center gap-2 mt-1">
                               <p className="text-[9px] font-black text-indigo-600 uppercase tracking-tighter">UID: {book.issuedTo.id}</p>
                               {book.issuedTo.role === 'Student' && (
                                 <p className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter">• Roll: {book.issuedTo.rollNo} • {book.issuedTo.class}-{book.issuedTo.section}</p>
                               )}
                            </div>
                            <div className="flex items-center gap-1.5 mt-1.5 text-rose-500">
                               <CalendarDays size={10}/>
                               <p className="text-[8px] font-black uppercase">Due: {new Date(book.dueDate!).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}</p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="px-10 py-7">
                    {book.penalty ? (
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-rose-600 bg-rose-50 px-4 py-2 rounded-xl border border-rose-100 w-fit">
                          <IndianRupee size={16} />
                          <span className="text-sm font-black">₹{book.penalty}</span>
                        </div>
                        <button 
                          onClick={() => clearPenalty(book.id)}
                          className="text-[9px] font-black text-indigo-600 uppercase tracking-widest hover:underline"
                        >
                          Process Payment
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 text-slate-200">
                         <CheckCircle2 size={16}/>
                         <span className="text-[10px] font-black uppercase tracking-widest">No Arrears</span>
                      </div>
                    )}
                  </td>
                  <td className="px-10 py-7 text-center">
                    <div className="flex justify-center gap-3">
                      {book.status === 'available' ? (
                        <button 
                          onClick={() => setShowIssueModal(book.id)}
                          className="p-3.5 bg-indigo-600 text-white rounded-2xl hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-500/20"
                          title="Issue Item"
                        >
                          <Bookmark size={20} />
                        </button>
                      ) : (
                        <>
                          <button 
                            onClick={() => handleReturnBook(book.id)}
                            className="p-3.5 bg-emerald-500 text-white rounded-2xl hover:bg-emerald-600 transition-all shadow-xl shadow-indigo-500/20"
                            title="Return Item"
                          >
                            <RotateCcw size={20} />
                          </button>
                          <button 
                            onClick={() => setShowPenaltyModal({ bookId: book.id, amount: 100 })}
                            className="p-3.5 bg-amber-50 text-amber-600 border border-amber-100 rounded-2xl hover:bg-amber-100 transition-all"
                            title="Apply Penalty"
                          >
                            <FileWarning size={20} />
                          </button>
                          {book.status !== 'lost' && (
                            <button 
                              onClick={() => handleMarkLost(book.id)}
                              className="p-3.5 bg-rose-50 text-rose-600 border border-rose-100 rounded-2xl hover:bg-rose-600 hover:text-white transition-all"
                              title="Mark Lost"
                            >
                              <AlertTriangle size={20} />
                            </button>
                          )}
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showIssueModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/70 backdrop-blur-md p-4 animate-in fade-in" onClick={() => setShowIssueModal(null)}>
           <div className="bg-white rounded-[3.5rem] p-12 max-w-2xl w-full shadow-2xl relative overflow-hidden" onClick={(e) => e.stopPropagation()}>
              <div className="absolute top-0 left-0 w-3 h-full bg-indigo-600"></div>
              <div className="flex justify-between items-center mb-10">
                <div>
                  <h3 className="text-3xl font-black text-slate-900 leading-tight">Circulation Transaction</h3>
                  <p className="text-sm text-slate-400 font-medium">Lending Asset Registry ID: {showIssueModal}</p>
                </div>
                <button onClick={() => setShowIssueModal(null)} className="p-3 hover:bg-slate-100 rounded-full text-slate-400 transition-colors"><X size={32}/></button>
              </div>

              <div className="space-y-10">
                 <div className="flex bg-slate-100 p-2 rounded-[1.5rem]">
                    {(['Student', 'Teacher', 'Staff'] as const).map(role => (
                      <button
                        key={role}
                        onClick={() => { setBorrowerType(role); setBorrowerSearch(''); }}
                        className={`flex-1 py-4 text-xs font-black rounded-xl transition-all flex items-center justify-center gap-2 uppercase tracking-widest ${borrowerType === role ? 'bg-white text-indigo-600 shadow-md' : 'text-slate-400 hover:text-slate-600'}`}
                      >
                        {role === 'Student' ? <Users size={16}/> : role === 'Teacher' ? <Briefcase size={16}/> : <User size={16}/>}
                        {role}
                      </button>
                    ))}
                 </div>

                 <div className="space-y-6">
                    <div className="relative group">
                       <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-600 transition-colors" size={20} />
                       <input 
                         type="text" 
                         autoFocus
                         value={borrowerSearch}
                         onChange={(e) => setBorrowerSearch(e.target.value)}
                         placeholder={`Search by Name, ID, Class or Roll No...`}
                         className="w-full pl-16 pr-6 py-5 bg-slate-50 border border-slate-200 rounded-[2.5rem] font-black text-lg outline-none focus:bg-white focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/5 transition-all shadow-inner"
                       />
                    </div>

                    <div className="max-h-[350px] overflow-y-auto space-y-3 pr-2 custom-scrollbar">
                       {filteredBorrowers.length > 0 ? filteredBorrowers.map(b => (
                         <div 
                           key={b.id} 
                           onClick={() => handleIssueBook(showIssueModal, b)}
                           className="p-6 bg-white border border-slate-100 rounded-[2rem] flex items-center justify-between hover:border-indigo-500 hover:bg-indigo-50/20 cursor-pointer group transition-all"
                         >
                            <div className="flex items-center gap-6">
                               <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center text-slate-400 group-hover:bg-indigo-600 group-hover:text-white transition-all shadow-sm">
                                  <User size={28}/>
                               </div>
                               <div>
                                  <p className="text-xl font-black text-slate-900 leading-tight mb-1">{b.name}</p>
                                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
                                     <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest">ID: {b.id}</span>
                                     {borrowerType === 'Student' && (
                                       <>
                                         <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">• {(b as any).info}</span>
                                         <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">• Roll: {(b as any).rollNo}</span>
                                       </>
                                     )}
                                  </div>
                               </div>
                            </div>
                            <div className="w-12 h-12 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-600 opacity-0 group-hover:opacity-100 transition-all border border-indigo-100">
                               <Check size={28} strokeWidth={3} />
                            </div>
                         </div>
                       )) : (
                         <div className="p-20 text-center flex flex-col items-center gap-4 text-slate-200">
                            <Users size={80} className="opacity-10" />
                            <p className="font-black text-xl italic uppercase tracking-widest opacity-50">No registry matches.</p>
                         </div>
                       )}
                    </div>
                 </div>
              </div>
           </div>
        </div>
      )}

      {showPenaltyModal && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center bg-slate-900/80 backdrop-blur-md p-4 animate-in fade-in" onClick={() => setShowPenaltyModal(null)}>
          <div className="bg-white rounded-[3rem] p-10 max-w-md w-full shadow-2xl relative" onClick={(e) => e.stopPropagation()}>
             <div className="flex justify-between items-center mb-8">
                <h3 className="text-2xl font-black text-slate-900">Assess Penalty</h3>
                <button onClick={() => setShowPenaltyModal(null)} className="p-2 text-slate-400 hover:bg-slate-50 rounded-full"><X/></button>
             </div>
             <p className="text-sm text-slate-500 mb-8 font-medium">Applied for physical damage, page removal, or lost status for Book ID: <span className="text-indigo-600 font-black">{showPenaltyModal.bookId}</span></p>
             <div className="space-y-6">
                <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Fine Amount (₹)</label>
                   <input 
                     type="number" 
                     autoFocus
                     defaultValue={showPenaltyModal.amount}
                     id="penaltyInput"
                     className="w-full p-5 bg-slate-50 border border-slate-200 rounded-2xl font-black text-2xl outline-none focus:bg-white focus:border-indigo-500 shadow-inner"
                   />
                </div>
                <button 
                  onClick={() => applyManualPenalty(showPenaltyModal.bookId, parseInt((document.getElementById('penaltyInput') as HTMLInputElement).value) || 0)}
                  className="w-full py-6 bg-slate-900 text-white rounded-[2rem] font-black uppercase tracking-widest shadow-2xl hover:bg-rose-600 transition-all"
                >
                   Finalize Arrears
                </button>
             </div>
          </div>
        </div>
      )}

      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-md p-4 animate-in fade-in" onClick={() => setShowAddModal(false)}>
          <div className="bg-white rounded-[3.5rem] p-12 max-w-2xl w-full shadow-2xl relative overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-50 rounded-bl-full opacity-50"></div>
            <div className="flex justify-between items-center mb-10">
              <h3 className="text-3xl font-black text-slate-900 leading-tight">Asset Cataloging</h3>
              <button onClick={() => setShowAddModal(false)} className="p-3 hover:bg-slate-100 rounded-full text-slate-400 transition-colors"><X size={32}/></button>
            </div>
            
            <form onSubmit={handleAddBook} className="space-y-10">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Format</label>
                    <select name="type" className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl font-black outline-none focus:bg-white transition-all shadow-inner">
                      <option value="Physical">Physical Stacks</option>
                      <option value="Ebook">Digital Resource</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Title</label>
                    <input name="title" required className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl font-black outline-none shadow-inner" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Primary Author</label>
                    <input name="author" required className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl font-black outline-none shadow-inner" />
                  </div>
                </div>

                <div className="space-y-6">
                  <div className="space-y-2">
                    {/* Fix: Corrected typo where parenthesis was used instead of closing square bracket in className */}
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">ISBN</label>
                    <input name="isbn" required className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl font-black outline-none shadow-inner" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Classification</label>
                    <input name="category" required className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl font-black outline-none shadow-inner" placeholder="e.g. History" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Rack</label>
                      <input name="rack" className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl font-black outline-none shadow-inner" placeholder="R-01" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Shelf</label>
                      <input name="shelf" className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl font-black outline-none shadow-inner" placeholder="S-05" />
                    </div>
                  </div>
                </div>
              </div>
              <button type="submit" className="w-full py-6 bg-indigo-600 text-white rounded-[2.5rem] font-black text-lg shadow-2xl shadow-indigo-500/30 hover:bg-indigo-700 transition-all uppercase tracking-widest">Register into Ledger</button>
            </form>
          </div>
        </div>
      )}

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #e2e8f0; border-radius: 10px; }
      `}</style>
    </div>
  );
};

export default LibraryManagement;
