
import React, { useState } from 'react';
import { 
  MessageSquare, Search, User, Clock, CheckCircle2, 
  AlertCircle, Send, Plus, MoreVertical, 
  Briefcase, GraduationCap, Phone, Info, Mail,
  UserCheck, ShieldCheck, Heart, X, Users, Megaphone,
  ShieldAlert, Sparkles
} from 'lucide-react';

const CommunicationHub: React.FC = () => {
  const [activeThread, setActiveThread] = useState<string | null>('1');
  const [showBroadcastModal, setShowBroadcastModal] = useState(false);

  const threads = [
    { id: '1', name: 'John Miller (Parent)', lastMsg: 'Requesting permission for leave next Tuesday...', time: '10:30 AM', status: 'Pending', role: 'Parent', type: 'Request', student: 'Luke Miller (4-A)' },
    { id: '2', name: 'Dr. Sarah Connor (Maths)', lastMsg: 'Grade 10 assignment has been published.', time: '09:15 AM', status: 'Read', role: 'Teacher', type: 'Admin', category: 'Maths Dept' },
    { id: '3', name: 'Mrs. Anita Gupta (Parent)', lastMsg: 'Thank you for the update on Aarav results.', time: 'Yesterday', status: 'Success', role: 'Parent', type: 'Response', student: 'Aarav Gupta (10-A)' },
    { id: '4', name: 'Rahul Sharma (Teacher)', lastMsg: 'Need clarification on physics module...', time: 'Yesterday', status: 'Pending', role: 'Teacher', type: 'Query' },
  ];

  const handleSendBroadcast = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const target = formData.get('target');
    const message = formData.get('message');
    
    alert(`Broadcast Dispatched!\n\nTarget: ${target}\nMessage: ${message}\n\nStakeholders notified via SMS and App Push.`);
    setShowBroadcastModal(false);
  };

  return (
    <div className="p-4 md:p-8 h-[calc(100vh-80px)] flex flex-col gap-6 md:gap-8 max-w-7xl mx-auto overflow-x-hidden">
      <div className="flex justify-between items-center no-print">
        <div>
          <h1 className="text-3xl font-black text-slate-900 italic uppercase tracking-tighter">Communication Ledger</h1>
          <p className="text-slate-500 font-medium uppercase text-[10px] tracking-widest mt-1">Teacher-Parent Interaction Vault • Secure Sync</p>
        </div>
        <div className="flex gap-4">
           <button 
            onClick={() => setShowBroadcastModal(true)}
            className="px-8 py-4 bg-indigo-600 text-white rounded-2xl text-xs font-black flex items-center gap-2 shadow-xl shadow-indigo-500/20 hover:scale-105 active:scale-95 transition-all"
           >
             <Plus size={18}/> New Broadcast
           </button>
        </div>
      </div>

      <div className="flex-1 flex bg-white rounded-[3rem] border border-slate-100 shadow-sm overflow-hidden min-h-0">
         {/* THREAD LIST */}
         <div className="w-full md:w-96 border-r border-slate-50 flex flex-col shrink-0">
            <div className="p-6 md:p-8 border-b border-slate-50">
               <div className="relative group">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-600 transition-colors" size={18} />
                  <input type="text" placeholder="Filter identities..." className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-transparent focus:bg-white focus:border-indigo-500 rounded-2xl text-sm outline-none transition-all font-black shadow-inner" />
               </div>
            </div>
            <div className="flex-1 overflow-y-auto custom-scrollbar">
               {threads.map(thread => (
                 <div 
                   key={thread.id} 
                   onClick={() => setActiveThread(thread.id)}
                   className={`p-6 md:p-8 border-b border-slate-50 cursor-pointer transition-all hover:bg-slate-50/50 relative group ${activeThread === thread.id ? 'bg-indigo-50/50' : ''}`}
                 >
                    {activeThread === thread.id && <div className="absolute left-0 top-0 w-2 h-full bg-indigo-600"></div>}
                    <div className="flex gap-5">
                       <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shadow-sm shrink-0 ${thread.role === 'Parent' ? 'bg-rose-50 text-rose-500' : 'bg-indigo-50 text-indigo-600'}`}>
                          {thread.role === 'Parent' ? <Heart size={24}/> : <Briefcase size={24}/>}
                       </div>
                       <div className="flex-1 overflow-hidden">
                          <div className="flex justify-between items-center mb-1">
                             <h4 className="font-black text-slate-900 truncate tracking-tight">{thread.name}</h4>
                             <span className="text-[10px] text-slate-400 font-bold uppercase">{thread.time}</span>
                          </div>
                          <p className="text-[11px] text-slate-500 truncate font-medium">{thread.lastMsg}</p>
                          <div className="flex items-center gap-3 mt-3">
                             <span className={`text-[8px] font-black px-2 py-0.5 rounded-lg uppercase tracking-widest ${thread.type === 'Request' ? 'bg-amber-100 text-amber-700' : 'bg-indigo-100 text-indigo-700'}`}>{thread.type}</span>
                             {thread.student && <span className="text-[8px] font-black text-slate-400 uppercase tracking-tighter">Ref: {thread.student}</span>}
                          </div>
                       </div>
                    </div>
                 </div>
               ))}
            </div>
         </div>

         {/* MESSAGE VIEW */}
         <div className="hidden md:flex flex-1 flex-col bg-slate-50/30">
            {activeThread ? (
               <>
                  <div className="px-10 py-8 bg-white border-b border-slate-100 flex justify-between items-center">
                     <div className="flex items-center gap-6">
                        <div className="w-14 h-14 bg-indigo-900 text-white rounded-[1.5rem] flex items-center justify-center font-black text-2xl shadow-xl italic">JM</div>
                        <div>
                           <h3 className="text-2xl font-black text-slate-900 italic tracking-tighter leading-none">John Miller <span className="text-sm font-medium text-slate-400 not-italic ml-2 uppercase tracking-widest">Parent Gateway</span></h3>
                           <p className="text-[10px] font-bold text-indigo-600 flex items-center gap-2 uppercase tracking-[0.2em] mt-2"><ShieldCheck size={14} className="text-emerald-500" /> Identity Verified • Assigned: Luke Miller (4-A)</p>
                        </div>
                     </div>
                     <div className="flex gap-3">
                        <button className="p-4 bg-slate-50 text-slate-400 rounded-[1.2rem] hover:text-indigo-600 transition-colors shadow-sm"><Phone size={20}/></button>
                        <button className="p-4 bg-slate-50 text-slate-400 rounded-[1.2rem] hover:text-slate-900 transition-colors shadow-sm"><MoreVertical size={20}/></button>
                     </div>
                  </div>
                  
                  <div className="flex-1 overflow-y-auto p-12 space-y-10 custom-scrollbar">
                     <div className="flex flex-col items-center mb-12">
                        <span className="px-6 py-2 bg-white border border-slate-100 text-slate-400 rounded-full text-[10px] font-black uppercase tracking-[0.2em] shadow-sm">Communication Log: 24 Oct 2023</span>
                     </div>
                     
                     <div className="flex items-start gap-6 max-w-2xl">
                        <div className="w-12 h-12 rounded-[1.2rem] bg-white border border-slate-200 flex items-center justify-center text-slate-400 shadow-md shrink-0 font-black text-xs uppercase">JM</div>
                        <div className="space-y-3">
                           <div className="p-8 bg-white border border-slate-100 rounded-[2.5rem] rounded-tl-none shadow-sm hover:shadow-lg transition-shadow">
                              <p className="text-sm font-medium text-slate-700 leading-relaxed italic">"Hello Faculty Team, this is John regarding Luke Miller in Class 4-A. We need to travel for a family emergency from next Tuesday to Friday. Requesting permission for the same. I have informed the class teacher via the student diary as well. Please acknowledge."</p>
                           </div>
                           <div className="flex items-center gap-2 ml-4">
                              <CheckCircle2 size={12} className="text-emerald-500" />
                              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">10:30 AM • System Received</span>
                           </div>
                        </div>
                     </div>

                     <div className="flex items-start flex-row-reverse gap-6 max-w-2xl ml-auto">
                        <div className="w-12 h-12 rounded-[1.2rem] bg-indigo-600 flex items-center justify-center text-white shadow-xl shadow-indigo-500/20 shrink-0 font-black text-xs uppercase">STAFF</div>
                        <div className="space-y-3 flex flex-col items-end">
                           <div className="p-8 bg-indigo-600 text-white rounded-[2.5rem] rounded-tr-none shadow-xl shadow-indigo-900/10">
                              <p className="text-sm font-medium leading-relaxed">Noted, Mr. Miller. The request has been logged and forwarded to the Grade 4 Section Coordinator for formal registry entry. You will receive an automated SMS once the leave is sanctioned on the digital portal.</p>
                           </div>
                           <div className="flex items-center gap-2 mr-4">
                              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">10:45 AM • Parent Read</span>
                              <div className="flex -space-x-1">
                                 <CheckCircle2 size={12} className="text-indigo-500" />
                                 <CheckCircle2 size={12} className="text-indigo-500" />
                              </div>
                           </div>
                        </div>
                     </div>

                     <div className="p-8 bg-amber-50 rounded-[3rem] border-2 border-amber-100 border-dashed flex items-center gap-6 max-w-lg mx-auto shadow-sm">
                        <div className="p-4 bg-white rounded-2xl text-amber-600 shadow-sm"><AlertCircle size={32}/></div>
                        <div>
                           <p className="text-[10px] font-black text-amber-800 uppercase tracking-[0.2em]">Institutional System Protocol</p>
                           <p className="text-sm font-bold text-amber-700 mt-1">Incident Registry: Leave Request Ticket #LR-441-A Established.</p>
                        </div>
                     </div>
                  </div>

                  <div className="p-10 bg-white border-t border-slate-100">
                     <div className="relative group">
                        <input type="text" placeholder="Draft a professional response..." className="w-full pl-8 pr-24 py-6 bg-slate-50 border-2 border-transparent focus:border-indigo-600 focus:bg-white rounded-[2.5rem] text-sm outline-none transition-all font-black shadow-inner" />
                        <button className="absolute right-4 top-1/2 -translate-y-1/2 p-4 bg-indigo-600 text-white rounded-[1.5rem] shadow-2xl shadow-indigo-500/30 hover:scale-105 active:scale-95 transition-all group-focus-within:bg-indigo-700">
                           <Send size={24}/>
                        </button>
                     </div>
                  </div>
               </>
            ) : (
               <div className="flex-1 flex flex-col items-center justify-center text-slate-300 animate-in zoom-in-95 duration-500">
                  <div className="w-32 h-32 bg-slate-50 rounded-[3rem] flex items-center justify-center mb-8 shadow-inner">
                    <MessageSquare size={64} className="opacity-20" />
                  </div>
                  <h3 className="text-3xl font-black text-slate-400 italic uppercase tracking-tighter">Chat Integrity Hub</h3>
                  <p className="text-sm font-medium mt-3 tracking-widest uppercase opacity-50">Select a legacy thread to view interaction logs.</p>
               </div>
            )}
         </div>
      </div>

      {/* NEW BROADCAST MODAL */}
      {showBroadcastModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-md p-4 animate-in fade-in" onClick={() => setShowBroadcastModal(false)}>
           <div className="bg-white rounded-[3.5rem] p-10 md:p-12 max-w-2xl w-full shadow-2xl relative overflow-hidden" onClick={(e) => e.stopPropagation()}>
              <div className="absolute top-0 left-0 w-3 h-full bg-indigo-600"></div>
              <div className="flex justify-between items-start mb-10">
                 <div>
                   <h3 className="text-3xl font-black text-slate-900 tracking-tighter uppercase italic">Institutional Broadcast</h3>
                   <p className="text-sm text-slate-500 font-medium italic mt-1">Multi-channel message deployment node.</p>
                 </div>
                 <button onClick={() => setShowBroadcastModal(false)} className="p-3 hover:bg-slate-100 rounded-full text-slate-400 transition-colors"><X size={32}/></button>
              </div>

              <form onSubmit={handleSendBroadcast} className="space-y-8">
                 <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-3">Target Stakeholder Group</label>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                       <select name="target" required className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-xs outline-none focus:bg-white focus:border-indigo-500">
                          <option value="All Parents">All Parents</option>
                          <option value="Grade 10-A Parents">Grade 10-A Parents</option>
                          <option value="All Staff Members">All Staff Members</option>
                          <option value="Academic Faculty Only">Academic Faculty Only</option>
                          <option value="Transport Team">Transport Team</option>
                       </select>
                       <div className="p-4 bg-indigo-50 border border-indigo-100 rounded-2xl flex items-center gap-3">
                          <Users size={18} className="text-indigo-600" />
                          <span className="text-[10px] font-black text-indigo-700 uppercase">Multi-Sync Active</span>
                       </div>
                    </div>
                 </div>

                 <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-3">Broadcast Message</label>
                    <textarea 
                      name="message" 
                      required 
                      rows={6} 
                      placeholder="Compose your professional message here. This will be sent as a Push Notification, SMS, and Portal Alert." 
                      className="w-full p-6 bg-slate-50 border-2 border-slate-100 rounded-[2.5rem] font-black text-sm outline-none focus:bg-white resize-none transition-all shadow-inner"
                    ></textarea>
                 </div>

                 <div className="p-6 bg-amber-50 rounded-3xl border border-amber-100 flex items-start gap-4">
                    <Megaphone className="text-amber-600 shrink-0" size={24} />
                    <div>
                       <p className="text-[10px] font-black text-amber-800 uppercase tracking-widest">Protocol Warning</p>
                       <p className="text-[11px] font-medium text-amber-700 mt-1 leading-relaxed">Broadcasts are audited for institutional compliance. Avoid sensitive or individual-specific data in mass messages.</p>
                    </div>
                 </div>

                 <div className="flex gap-4 pt-6">
                    <button type="submit" className="flex-1 py-6 bg-indigo-600 text-white rounded-[2.5rem] font-black text-lg shadow-2xl shadow-indigo-500/30 hover:bg-indigo-700 transition-all uppercase tracking-widest flex items-center justify-center gap-4 active:scale-95 group">
                       <Send size={24} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" /> Dispatch Broadcast
                    </button>
                 </div>
              </form>
           </div>
        </div>
      )}

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #e2e8f0; border-radius: 10px; }
      `}</style>
    </div>
  );
};

export default CommunicationHub;
