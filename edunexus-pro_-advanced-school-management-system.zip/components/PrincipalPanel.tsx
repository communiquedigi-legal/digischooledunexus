
import React from 'react';
import { Building, ShieldCheck, BarChart3, Users, IndianRupee, Globe, TrendingUp, TrendingDown, Target, Bell, Plus, Filter, LayoutGrid } from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, AreaChart, Area
} from 'recharts';

const PrincipalPanel: React.FC = () => {
  const enrollmentData = [
    { name: 'Nursery', students: 120 },
    { name: 'Primary', students: 450 },
    { name: 'Middle', students: 380 },
    { name: 'Senior', students: 300 },
  ];

  return (
    <div className="p-4 md:p-8 space-y-6 md:space-y-10 max-w-7xl mx-auto">
      <div className="bg-slate-900 p-6 md:p-16 rounded-[2rem] md:rounded-[4.5rem] text-white relative overflow-hidden shadow-2xl">
         <div className="absolute top-0 right-0 w-[400px] md:w-[800px] h-[400px] md:h-[800px] bg-rose-500/10 rounded-full blur-[80px] md:blur-[120px] -translate-y-1/2 translate-x-1/2"></div>
         <div className="flex flex-col lg:flex-row items-center justify-between gap-8 md:gap-12 relative z-10">
            <div className="text-center lg:text-left">
               <div className="flex items-center justify-center lg:justify-start gap-3 md:gap-4 mb-4 md:mb-6">
                  <div className="w-12 h-12 md:w-16 md:h-16 bg-rose-600 rounded-2xl md:rounded-3xl flex items-center justify-center shadow-2xl shadow-rose-900/50 italic font-black text-xl md:text-3xl">P</div>
                  <h1 className="text-xl md:text-4xl font-black uppercase tracking-tighter italic">Principal Intelligence</h1>
               </div>
               <h2 className="text-3xl md:text-6xl font-black leading-tight tracking-tight mb-4 md:mb-8">Operational <span className="text-rose-500">Excellence</span></h2>
               <p className="text-slate-400 text-sm md:text-xl font-medium max-w-xl mx-auto lg:mx-0">Monitor academic fidelity, fiscal health, and faculty performance across the entire landscape.</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-6 w-full lg:w-auto">
               <div className="p-6 md:p-10 bg-white/5 border border-white/10 rounded-[2rem] md:rounded-[3.5rem] backdrop-blur-md">
                  <p className="text-[10px] font-black text-rose-500 uppercase tracking-widest mb-1 md:mb-2">Total Strength</p>
                  <p className="text-3xl md:text-4xl font-black text-white italic">1,250</p>
                  <span className="text-[10px] font-bold text-emerald-400 mt-2 flex items-center gap-1"><TrendingUp size={12}/> +4% vs LY</span>
               </div>
               <div className="p-6 md:p-10 bg-white/5 border border-white/10 rounded-[2rem] md:rounded-[3.5rem] backdrop-blur-md">
                  <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-1 md:mb-2">Active Faculty</p>
                  <p className="text-3xl md:text-4xl font-black text-white italic">84</p>
                  <span className="text-[10px] font-bold text-slate-400 mt-2 uppercase">Core Personnel</span>
               </div>
            </div>
         </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
         <div className="lg:col-span-2 bg-white p-6 md:p-12 rounded-[2rem] md:rounded-[3.5rem] border border-slate-100 shadow-sm">
            <h3 className="text-lg md:text-2xl font-black text-slate-900 mb-6 md:mb-10 flex items-center gap-3"><LayoutGrid className="text-rose-500" size={20}/> Enrollment Matrix</h3>
            <div className="h-[250px] md:h-[350px]">
               <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={enrollmentData}>
                     <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                     <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 10, fontWeight: 700}} />
                     <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 10}} />
                     <Tooltip contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 10px 25px rgba(0,0,0,0.1)'}} />
                     <Bar dataKey="students" fill="#e11d48" radius={[8, 8, 0, 0]} barSize={40} />
                  </BarChart>
               </ResponsiveContainer>
            </div>
         </div>

         <div className="bg-white p-6 md:p-10 rounded-[2rem] md:rounded-[3.5rem] border border-slate-100 shadow-sm flex flex-col justify-between">
            <div>
               <h3 className="text-lg md:text-xl font-black text-slate-900 mb-1">Institutional Fiscal Sync</h3>
               <p className="text-[10px] md:text-xs font-bold text-slate-400 uppercase tracking-widest mb-6 md:mb-10">Real-time Revenue Monitoring</p>
               <div className="space-y-6 md:space-y-8">
                  <div className="p-6 md:p-8 bg-slate-900 rounded-[2rem] md:rounded-[2.5rem] text-white">
                     <p className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.2em] mb-2">Current Liquidity</p>
                     <p className="text-2xl md:text-4xl font-black italic">₹1.24Cr</p>
                  </div>
                  <div className="space-y-3">
                     <div className="flex justify-between items-center"><span className="text-[10px] font-black text-slate-500 uppercase">Collection Health</span><span className="text-sm font-black text-rose-500">84%</span></div>
                     <div className="w-full h-1.5 md:h-2 bg-slate-100 rounded-full overflow-hidden"><div className="h-full bg-rose-500" style={{width: '84%'}}></div></div>
                  </div>
               </div>
            </div>
            <button className="w-full py-4 md:py-5 bg-indigo-600 text-white rounded-[1.5rem] md:rounded-[2.5rem] font-black text-[10px] uppercase tracking-widest shadow-xl shadow-indigo-200 mt-8">Download Executive Audit</button>
         </div>
      </div>
    </div>
  );
};

export default PrincipalPanel;
