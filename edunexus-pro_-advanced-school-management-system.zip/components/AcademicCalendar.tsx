
import React, { useState, useMemo } from 'react';
import { 
  Printer, Plus, Save, X, ChevronLeft, ChevronRight, 
  Sparkles, Info, Trash2, Calendar as LucideCalendar, 
  MapPin, Clock, Camera, FileText, Image as ImageIcon,
  ShieldCheck, CheckCircle
} from 'lucide-react';
import { AcademicSession, CalendarEvent } from '../types';
import { MOCK_CALENDAR_EVENTS, CALENDAR_COLORS } from '../constants';

interface AcademicCalendarProps {
  session: AcademicSession;
}

const MONTHS = [
  'APRIL', 'MAY', 'JUNE', 'JULY', 'AUGUST', 'SEPTEMBER', 
  'OCTOBER', 'NOVEMBER', 'DECEMBER', 'JANUARY', 'FEBRUARY', 'MARCH'
];

const AcademicCalendar: React.FC<AcademicCalendarProps> = ({ session }) => {
  const [events, setEvents] = useState<CalendarEvent[]>(MOCK_CALENDAR_EVENTS);
  const [selectedDay, setSelectedDay] = useState<{ month: string, day: number } | null>(null);
  const [editingEvent, setEditingEvent] = useState<CalendarEvent | null>(null);

  const startYear = parseInt(session.label.split('-')[0]) || 2025;

  const getYearForMonth = (monthName: string) => {
    const monthIndex = MONTHS.indexOf(monthName);
    return monthIndex >= 9 ? startYear + 1 : startYear;
  };

  const getMonthData = (monthName: string) => {
    const monthIndex = MONTHS.indexOf(monthName);
    const actualMonthIndex = (monthIndex + 3) % 12;
    const year = getYearForMonth(monthName);
    
    const daysInMonth = new Date(year, actualMonthIndex + 1, 0).getDate();
    return Array.from({ length: 31 }, (_, i) => {
      const day = i + 1;
      if (day > daysInMonth) return null;
      
      const dateStr = `${year}-${(actualMonthIndex + 1).toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
      const dayOfWeek = new Date(year, actualMonthIndex, day).toLocaleDateString('en-US', { weekday: 'short' }).toUpperCase();
      const event = events.find(e => e.date === dateStr);
      
      return { day, dayOfWeek, event, dateStr };
    });
  };

  const handleCellClick = (month: string, day: number, event?: CalendarEvent) => {
    if (event) {
      setEditingEvent(event);
    } else {
      const year = getYearForMonth(month);
      const actualMonthIndex = (MONTHS.indexOf(month) + 3) % 12;
      const dateStr = `${year}-${(actualMonthIndex + 1).toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
      setEditingEvent({
        id: Date.now().toString(),
        date: dateStr,
        title: '',
        type: 'Regular'
      });
    }
    setSelectedDay({ month, day });
  };

  const saveEvent = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!editingEvent) return;
    
    const isNew = !events.find(ev => ev.id === editingEvent.id);
    if (isNew) {
      setEvents([...events, editingEvent]);
    } else {
      setEvents(events.map(ev => ev.id === editingEvent.id ? editingEvent : ev));
    }
    setEditingEvent(null);
  };

  const deleteEvent = (id: string) => {
    setEvents(events.filter(e => e.id !== id));
    setEditingEvent(null);
  };

  const calendarGrid = useMemo(() => {
    return MONTHS.map(m => ({ name: m, days: getMonthData(m) }));
  }, [events, session]);

  return (
    <div className="p-8 space-y-8 max-w-[1800px] mx-auto overflow-x-auto">
      <div className="flex flex-col lg:flex-row justify-between items-end gap-6 no-print">
        <div>
           <div className="flex items-center gap-3 mb-2">
             <div className="p-2 bg-indigo-600 text-white rounded-lg shadow-lg"><LucideCalendar size={20}/></div>
             <h1 className="text-3xl font-black text-slate-900 tracking-tight uppercase italic">Annual Academic Planner</h1>
           </div>
           <p className="text-slate-500 font-medium">Visualizing institutional milestones for Session {session.label}</p>
        </div>
        
        <div className="flex flex-wrap gap-4 items-center bg-white p-3 rounded-[2rem] border border-slate-100 shadow-sm">
           <div className="flex gap-2">
              {Object.keys(CALENDAR_COLORS).map(type => (
                <div key={type} className="flex items-center gap-2 px-3 py-1 bg-slate-50 rounded-full border border-slate-100">
                   <div className={`w-3 h-3 rounded-full ${CALENDAR_COLORS[type as keyof typeof CALENDAR_COLORS]}`}></div>
                   <span className="text-[10px] font-black text-slate-500 uppercase">{type}</span>
                </div>
              ))}
           </div>
           <div className="h-8 w-px bg-slate-100"></div>
           <button onClick={() => window.print()} className="px-6 py-2.5 bg-slate-900 text-white rounded-xl text-xs font-black uppercase tracking-widest flex items-center gap-2 hover:bg-indigo-600 transition-all shadow-xl shadow-slate-200">
             <Printer size={16} /> Export HQ PDF
           </button>
        </div>
      </div>

      <div className="bg-white rounded-[3rem] border border-slate-200 shadow-2xl overflow-hidden p-6 relative">
        <div className="grid grid-cols-13 gap-1 mb-1 border-b-4 border-slate-900">
          <div className="bg-slate-900 text-white p-4 flex items-center justify-center font-black text-sm border-r border-slate-800">D / M</div>
          {MONTHS.map(m => (
            <div key={m} className="flex flex-col bg-indigo-600 text-white overflow-hidden relative group">
               <img 
                 src={`https://picsum.photos/seed/edu-${m.toLowerCase()}/200/100`} 
                 className="w-full h-16 object-cover opacity-60 group-hover:scale-110 transition-transform duration-700 grayscale" 
                 alt="" 
               />
               <div className="absolute inset-0 bg-indigo-600/40 backdrop-blur-[1px]"></div>
               <div className="absolute inset-0 flex items-center justify-center">
                  <span className="font-black text-xs tracking-[0.2em]">{m}</span>
               </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-13 gap-1 bg-slate-200">
          {Array.from({ length: 31 }, (_, i) => {
            const dateRow = i + 1;
            return (
              <React.Fragment key={dateRow}>
                <div className="bg-slate-900 text-white p-2 flex items-center justify-center font-black text-xs border-r border-slate-800">
                  {dateRow}
                </div>
                
                {calendarGrid.map(month => {
                  const dayData = month.days[i];
                  if (!dayData) return <div key={month.name} className="bg-slate-100 border border-white/20"></div>;
                  
                  const isSunday = dayData.dayOfWeek === 'SUN';
                  const event = dayData.event;
                  
                  return (
                    <div 
                      key={month.name} 
                      onClick={() => handleCellClick(month.name, dayData.day, event)}
                      className={`min-h-[60px] p-1.5 border border-slate-100 relative group cursor-pointer transition-all hover:ring-2 hover:ring-indigo-400 z-10 
                        ${isSunday ? 'bg-rose-50' : 'bg-white'}`}
                    >
                      <span className={`text-[8px] font-black absolute top-1 left-1 ${isSunday ? 'text-rose-500' : 'text-slate-300'}`}>
                        {dayData.dayOfWeek}
                      </span>
                      
                      {event && (
                        <div className={`w-full h-full rounded-lg p-2 flex flex-col justify-between ${CALENDAR_COLORS[event.type]} shadow-sm transform hover:scale-[1.03] transition-transform`}>
                           <p className="text-[9px] font-black leading-tight uppercase line-clamp-2">{event.title}</p>
                           <Sparkles size={8} className="opacity-40 self-end" />
                        </div>
                      )}
                    </div>
                  );
                })}
              </React.Fragment>
            );
          })}
        </div>
      </div>

      {editingEvent && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-md p-4 animate-in fade-in" onClick={() => setEditingEvent(null)}>
           <div className="bg-white rounded-[3.5rem] p-12 max-w-xl w-full shadow-2xl relative overflow-hidden" onClick={(e) => e.stopPropagation()}>
              <div className="absolute top-0 left-0 w-3 h-full bg-indigo-600"></div>
              <div className="flex justify-between items-center mb-10">
                 <div>
                   <h3 className="text-3xl font-black text-slate-900 leading-tight">Planner Manager</h3>
                   <p className="text-sm text-slate-500 font-medium">Update event details for {editingEvent.date}</p>
                 </div>
                 <button onClick={() => setEditingEvent(null)} className="p-3 hover:bg-slate-100 rounded-full text-slate-400 transition-colors"><X size={32}/></button>
              </div>

              <form onSubmit={saveEvent} className="space-y-8">
                 <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Event Title</label>
                    <input 
                      autoFocus
                      required
                      value={editingEvent.title}
                      onChange={(e) => setEditingEvent({...editingEvent, title: e.target.value})}
                      placeholder="e.g. Science Fair"
                      className="w-full p-5 bg-slate-50 border border-slate-200 rounded-2xl font-black text-lg outline-none focus:bg-white focus:border-indigo-500 transition-all"
                    />
                 </div>

                 <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-2">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Category Type</label>
                       <select 
                         value={editingEvent.type}
                         onChange={(e) => setEditingEvent({...editingEvent, type: e.target.value as any})}
                         className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl font-black text-sm outline-none cursor-pointer"
                       >
                          {Object.keys(CALENDAR_COLORS).map(t => <option key={t} value={t}>{t}</option>)}
                       </select>
                    </div>
                    <div className="space-y-2">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Date (Fixed)</label>
                       <div className="w-full p-4 bg-slate-100 border border-slate-200 rounded-2xl font-black text-sm text-slate-400 uppercase">
                          {editingEvent.date}
                       </div>
                    </div>
                 </div>

                 <div className="p-6 bg-slate-50 rounded-3xl border border-slate-100 flex items-start gap-4">
                    <div className="p-3 bg-white rounded-xl shadow-sm text-indigo-600"><Info size={20}/></div>
                    <p className="text-xs text-slate-500 leading-relaxed font-medium">Marking a day as 'Holiday' will automatically disable attendance tracking and faculty timesheets for that specific date institutional-wide.</p>
                 </div>

                 <div className="flex gap-4 pt-6">
                    <button type="submit" className="flex-[2] py-6 bg-indigo-600 text-white rounded-[2.5rem] font-black text-lg shadow-2xl shadow-indigo-500/30 hover:bg-indigo-700 transition-all uppercase tracking-widest">
                       Apply & Synchronize
                    </button>
                    <button 
                      type="button" 
                      onClick={() => deleteEvent(editingEvent.id)}
                      className="flex-1 py-6 bg-rose-50 text-rose-600 rounded-[2.5rem] font-black text-sm hover:bg-rose-100 transition-all uppercase tracking-widest flex items-center justify-center gap-2"
                    >
                       <Trash2 size={18}/> Wipe
                    </button>
                 </div>
              </form>
           </div>
        </div>
      )}

      <style>{`
        .grid-cols-13 { grid-template-columns: 80px repeat(12, 1fr); }
        @media print {
          .grid-cols-13 { grid-template-columns: 50px repeat(12, 1fr) !important; }
          body { background: white !important; }
          .p-8 { padding: 0 !important; }
        }
      `}</style>
    </div>
  );
};

export default AcademicCalendar;
