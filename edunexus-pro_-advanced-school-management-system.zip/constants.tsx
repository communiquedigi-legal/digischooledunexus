
import React from 'react';
import { 
  LayoutDashboard, Users, BookOpen, Calendar, CreditCard, 
  Bus, GraduationCap, Library, Users2, FileText, Bell, Trophy, Settings, CheckSquare,
  BarChart3, MessageSquare, CalendarDays, HeartHandshake, ShieldCheck, Key,
  UsersRound, Megaphone, FileBadge
} from 'lucide-react';
// Fix: Added missing interface exports will be available in types.ts
import { StaffRole, Student, LibraryBook, CalendarEvent, UserRole, LoginCredential, SalaryStructure, HomeworkSubmission, TeacherAssignment, EmploymentCategory } from './types';

export const NAV_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={20} />, roles: [UserRole.ADMIN, UserRole.PRINCIPAL] },
  { id: 'teacher_panel', label: 'Teacher Zone', icon: <GraduationCap size={20} />, roles: [UserRole.TEACHER] },
  { id: 'parent_panel', label: 'Parent Zone', icon: <Users size={20} />, roles: [UserRole.PARENT] },
  { id: 'planner', label: 'Academic Planner', icon: <CalendarDays size={20} />, roles: [UserRole.ADMIN, UserRole.PRINCIPAL, UserRole.TEACHER] },
  { id: 'students', label: 'Students', icon: <Users size={20} />, roles: [UserRole.ADMIN, UserRole.PRINCIPAL, UserRole.STAFF] },
  { id: 'attendance', label: 'Attendance', icon: <CheckSquare size={20} />, roles: [UserRole.ADMIN, UserRole.TEACHER] },
  { id: 'academics', label: 'Academics', icon: <BookOpen size={20} />, roles: [UserRole.ADMIN, UserRole.TEACHER] },
  { id: 'exams', label: 'Exams & Results', icon: <GraduationCap size={20} />, roles: [UserRole.ADMIN, UserRole.PRINCIPAL, UserRole.TEACHER] },
  { id: 'fees', label: 'Fees Management', icon: <CreditCard size={20} />, roles: [UserRole.ADMIN, UserRole.STAFF] },
  { id: 'documents', label: 'Certificates & IDs', icon: <FileBadge size={20} />, roles: [UserRole.ADMIN, UserRole.STAFF] },
  { id: 'philanthropy', label: 'Donation & Impact', icon: <HeartHandshake size={20} />, roles: [UserRole.ADMIN, UserRole.PARENT] },
  { id: 'hr', label: 'HR & Payroll', icon: <Users2 size={20} />, roles: [UserRole.ADMIN, UserRole.STAFF] },
  { id: 'finance', label: 'Finance Hub', icon: <BarChart3 size={20} />, roles: [UserRole.ADMIN, UserRole.STAFF] },
  { id: 'library', label: 'Library', icon: <Library size={20} />, roles: [UserRole.ADMIN, UserRole.STAFF] },
  { id: 'transport', label: 'Transport', icon: <Bus size={20} />, roles: [UserRole.ADMIN, UserRole.STAFF] },
  { id: 'messages', label: 'Communication Hub', icon: <MessageSquare size={20} />, roles: [UserRole.ADMIN, UserRole.TEACHER, UserRole.PARENT] },
  { id: 'notices', label: 'Notice Board', icon: <Megaphone size={20} />, roles: [UserRole.ADMIN, UserRole.PRINCIPAL, UserRole.TEACHER, UserRole.STAFF, UserRole.PARENT] },
  { id: 'alumni', label: 'Alumni Network', icon: <UsersRound size={20} />, roles: [UserRole.ADMIN, UserRole.PRINCIPAL] },
  { id: 'credentials', label: 'Security Vault', icon: <Key size={20} />, roles: [UserRole.ADMIN, UserRole.PRINCIPAL, UserRole.STAFF, UserRole.TEACHER, UserRole.PARENT] },
  { id: 'settings', label: 'System Settings', icon: <Settings size={20} />, roles: [UserRole.ADMIN] },
];

export const CLASS_LIST = ['Nursery', 'LKG', 'UKG', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'];
export const SECTION_LIST = ['A', 'B', 'C', 'D'];
export const STUDENT_GROUPS = ['Standard', 'Merit-Elite', 'RTE-Quota', 'Staff-Ward', 'Special-Coaching'];
export const SOCIAL_CATEGORIES = ['General', 'OBC', 'SC', 'ST', 'EWS', 'BPL'];

export const CALENDAR_COLORS = {
  Holiday: 'bg-rose-500 text-white',
  Examination: 'bg-indigo-600 text-white',
  Event: 'bg-amber-500 text-white',
  Result: 'bg-emerald-500 text-white',
  PTM: 'bg-blue-500 text-white',
  Regular: 'bg-white text-slate-600'
};

const indianFirstNames = [
  'Aarav', 'Vihaan', 'Vivaan', 'Ananya', 'Diya', 'Saanvi', 'Ishaan', 'Sai', 'Arjun', 'Advait', 
  'Kavya', 'Myra', 'Aaryan', 'Ishita', 'Rohan', 'Sneha', 'Aditya', 'Tanvi', 'Pranav', 'Riya',
  'Dev', 'Kiara', 'Ishan', 'Zoya', 'Kabir', 'Tara', 'Arnav', 'Sia', 'Reyansh', 'Shanaya',
  'Arush', 'Avni', 'Krish', 'Ira', 'Manan', 'Zian', 'Navya', 'Ojas', 'Amara', 'Yash'
];

const indianLastNames = [
  'Sharma', 'Verma', 'Gupta', 'Singh', 'Reddy', 'Kumar', 'Joshi', 'Patel', 'Mehta', 'Nair',
  'Aggarwal', 'Choudhary', 'Iyer', 'Kapoor', 'Malhotra', 'Sengupta', 'Mishra', 'Pandey'
];

const generateStudentsForRange = () => {
  const students: Student[] = [];
  let globalId = 1001;

  CLASS_LIST.forEach(className => {
    SECTION_LIST.forEach(section => {
      // Ensure at least 3 unique Indian students in every single class/section node
      for (let i = 0; i < 3; i++) {
        const idNum = globalId++;
        const nameIdx = (idNum + i) % indianFirstNames.length;
        const lastIdx = (idNum * (i + 1)) % indianLastNames.length;
        const groupIdx = (idNum + i) % STUDENT_GROUPS.length;
        const catIdx = (idNum + i) % SOCIAL_CATEGORIES.length;
        const gender: 'Male' | 'Female' = (nameIdx % 2 === 0) ? 'Male' : 'Female';
        
        students.push({
          id: `S${idNum}`,
          name: `${indianFirstNames[nameIdx]} ${indianLastNames[lastIdx]}`,
          class: className,
          section: section,
          rollNo: (i + 1).toString().padStart(2, '0'),
          group: STUDENT_GROUPS[groupIdx],
          gender: gender,
          category: SOCIAL_CATEGORIES[catIdx] as any,
          parentName: `${indianLastNames[lastIdx]} Family`,
          parentContact: `+91 9${idNum.toString().slice(-4)}0${i}5`,
          parentEmail: `parent${idNum}@edu-nexus.in`,
          parentAddress: `${idNum}, Shanti Path, Knowledge City, India`,
          bloodGroup: ['O+', 'A+', 'B+', 'AB+'][i % 4],
          dob: '2015-08-20',
          religion: 'Common',
          idMark: 'None',
          admissionDate: '2025-04-01',
          photoUrl: `https://picsum.photos/seed/student${idNum}/200`,
          isPromoted: false,
          availsTransport: (idNum % 3 === 0),
          availsHostel: (idNum % 5 === 0),
          documents: {}
        });
      }
    });
  });
  return students;
};

export const MOCK_STUDENTS: Student[] = generateStudentsForRange();

export const MOCK_STAFF = [
  { id: 'T001', name: 'Dr. Sunita Agarwal', role: StaffRole.PRINCIPAL, email: 'principal@edunexus.in', photoUrl: 'https://picsum.photos/seed/sunita/200', subject: 'Leadership' },
  { id: 'T003', name: 'Priya Verma', role: StaffRole.CLASS_TEACHER, email: 'priya.maths@edunexus.in', photoUrl: 'https://picsum.photos/seed/priya/200', subject: 'Mathematics' },
  { id: 'T004', name: 'Amit Gupta', role: StaffRole.SUBJECT_TEACHER, email: 'amit.science@edunexus.in', photoUrl: 'https://picsum.photos/seed/amit/200', subject: 'Physics' },
];

export const MOCK_BOOKS: LibraryBook[] = [
  { id: 'B001', title: 'The Great Gatsby', author: 'F. Scott Fitzgerald', isbn: '978-0743273565', barcode: 'BAR-101', category: 'Classic Literature', status: 'available', type: 'Physical', rack: 'R-01', shelf: 'S-01' },
];

// Fix: Corrected MOCK_SALARY to match SalaryStructure interface including missing properties
export const MOCK_SALARY: SalaryStructure = {
  category: EmploymentCategory.REGULAR,
  earnings: {
    basic: 50000,
    da: 5000,
    hra: 20000,
    conveyance: 5000,
    medical: 2000,
    special: 2000,
    incentive: 1000,
    bonus_statutory: 0,
    ex_gratia: 0
  },
  deductions: {
    pf_emp: 1800,
    pf_empr: 1800,
    esi_emp: 0,
    esi_empr: 0,
    pt: 200,
    tds: 4500,
    loan_recovery: 2000,
    lwf: 10
  },
  provisions: {
    gratuity: 0,
    insurance: 0
  },
  gross: 85000,
  net: 76500,
  ctc: 86800
};

export const MOCK_CALENDAR_EVENTS: CalendarEvent[] = [
  { id: 'E001', date: '2025-08-15', title: 'Independence Day', type: 'Holiday' },
];

export const MOCK_HOMEWORK = [
  { id: 'HW01', title: 'Calculus Exercises', subject: 'Mathematics', dueDate: '2023-10-25', description: 'Complete exercises 4.1 to 4.5.', teacher: 'Priya Verma', status: 'Pending', class: '10', section: 'A' },
  { id: 'HW02', title: 'Quantum Mechanics', subject: 'Physics', dueDate: '2023-10-27', description: 'Read Chapter 5.', teacher: 'Amit Gupta', status: 'Pending', class: '10', section: 'A' },
];

export const MOCK_CREDENTIALS: LoginCredential[] = [
  { uid: 'ADMIN01', name: 'Super Administrator', role: 'ADMIN', password: 'password123', category: 'HQ' },
  { 
    uid: 'T003', name: 'Priya Verma', role: 'TEACHER', password: 'password123', category: 'Math Dept',
    assignments: [
      { class: '10', section: 'A', subject: 'Mathematics', isClassTeacher: true },
      { class: '9', section: 'B', subject: 'Mathematics', isClassTeacher: false }
    ]
  },
  { 
    uid: 'T004', name: 'Amit Gupta', role: 'TEACHER', password: 'password123', category: 'Science Dept',
    assignments: [
      { class: '10', section: 'A', subject: 'Physics', isClassTeacher: false },
      { class: '11', section: 'C', subject: 'Physics', isClassTeacher: false }
    ]
  },
  { uid: 'S1001', name: 'Aarav Sharma', role: 'PARENT', password: 'password123', category: 'Grade 10-A' },
  { uid: 'STAFF01', name: 'Admission Office', role: 'STAFF', password: 'password123', category: 'Office' },
];
