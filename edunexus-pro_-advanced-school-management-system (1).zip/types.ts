
export enum UserRole {
  ADMIN = 'ADMIN',
  PRINCIPAL = 'PRINCIPAL',
  TEACHER = 'TEACHER',
  STAFF = 'STAFF',
  PARENT = 'PARENT'
}

export enum StaffRole {
  PRINCIPAL = 'Principal',
  VICE_PRINCIPAL = 'Vice Principal',
  COORDINATOR = 'Coordinator',
  CLASS_TEACHER = 'Class Teacher',
  SUBJECT_TEACHER = 'Subject Teacher',
  ADMIN_STAFF = 'Admin Staff',
  SUPPORT_STAFF = 'Support Staff'
}

export enum EmploymentCategory {
  REGULAR = 'Regular',
  TEMPORARY = 'Temporary',
  CONTRACT = 'Contract'
}

export enum LeaveType {
  CASUAL = 'Casual Leave',
  SICK = 'Sick Leave',
  EARNED = 'Earned Leave',
  MATERNITY = 'Maternity Leave',
  BEREAVEMENT = 'Bereavement Leave'
}

export enum LeaveStatus {
  PENDING = 'Pending',
  APPROVED = 'Approved',
  REJECTED = 'Rejected'
}

export interface LeaveRequest {
  id: string;
  staffId: string;
  staffName: string;
  type: LeaveType;
  startDate: string;
  endDate: string;
  reason: string;
  status: LeaveStatus;
  appliedAt: string;
  approvedBy?: string;
}

export interface SalaryStructure {
  category: EmploymentCategory;
  earnings: {
    basic: number;
    da: number;
    hra: number;
    conveyance: number;
    medical: number;
    special: number;
    incentive: number;
    bonus_statutory: number;
    ex_gratia: number;
  };
  deductions: {
    pf_emp: number;
    pf_empr: number;
    esi_emp: number;
    esi_empr: number;
    pt: number;
    tds: number;
    loan_recovery: number;
    lwf: number; // Labour Welfare Fund
  };
  provisions: {
    gratuity: number;
    insurance: number;
  };
  gross: number;
  net: number;
  ctc: number;
}

export interface TeacherAssignment {
  class: string;
  section: string;
  subject: string;
  isClassTeacher: boolean;
}

export interface LoginCredential {
  uid: string;
  name: string;
  role: string;
  password?: string;
  category?: string;
  assignments?: TeacherAssignment[];
}

export interface HomeworkSubmission {
  id: string;
  studentId: string;
  homeworkId: string;
  submittedAt: string;
  fileUrl: string;
  status: 'Pending' | 'Submitted' | 'Graded';
}

export interface Staff {
  id: string;
  name: string;
  role: 'TEACHER' | 'STAFF';
  role_category: string;
  designation: string;
  department: string;
  employment_type: EmploymentCategory;
  doj: string;
  salary: SalaryStructure;
  photo_url: string;
  bank_name?: string;
  bank_account_number?: string;
  bank_ifsc?: string;
  pan_number?: string;
  aadhar_number?: string;
}

export interface LibraryBook {
  id: string;
  title: string;
  author: string;
  isbn: string;
  barcode: string;
  category: string;
  status: 'available' | 'issued' | 'lost';
  type: 'Physical' | 'Ebook';
  rack?: string;
  shelf?: string;
  ebookUrl?: string;
  issuedTo?: {
    id: string;
    name: string;
    role: 'Student' | 'Teacher' | 'Staff';
    class?: string;
    section?: string;
    rollNo?: string;
  };
  dueDate?: string;
  penalty?: number;
}

// ... rest of existing interfaces
export interface Student {
  id: string;
  name: string;
  class: string;
  section: string;
  rollNo: string;
  group: string;
  gender: 'Male' | 'Female' | 'Other';
  category: 'General' | 'OBC' | 'SC' | 'ST' | 'EWS' | 'BPL';
  parentName: string;
  parentContact: string;
  parentEmail: string;
  parentAddress: string;
  bloodGroup: string;
  dob: string;
  religion: string;
  idMark: string;
  admissionDate: string;
  photoUrl: string;
  isPromoted: boolean;
  availsTransport: boolean;
  availsHostel: boolean;
  documents: Record<string, string>;
}

export interface CalendarEvent {
  id: string;
  date: string;
  title: string;
  type: 'Holiday' | 'Examination' | 'Event' | 'Result' | 'PTM' | 'Regular';
}

export interface ClassGroup {
  id: string;
  name: string;
  classes: string[];
}

export interface AcademicSession {
  id: string;
  label: string;
  startDate: string;
  endDate: string;
  isActive: boolean;
  status: 'Admission' | 'Academic' | 'Examination' | 'Closing';
}

export interface SchoolAsset {
  id: string;
  name: string;
  category: 'IT' | 'Furniture' | 'Infrastructure' | 'Lab' | 'AudioVisual' | 'Stationery';
  totalQuantity: number;
  availableQuantity: number;
  associatedFee?: number;
  status: 'Available' | 'Low Stock' | 'Maintenance' | 'Disposed';
}

export interface SchoolBranding {
  logoUrl: string;
  directorSignUrl: string;
  principalSignUrl: string;
  coordinatorSignUrl: string;
}
