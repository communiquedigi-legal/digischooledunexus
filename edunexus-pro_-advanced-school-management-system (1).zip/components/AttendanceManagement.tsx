import React, { useState, useMemo } from 'react';
import { 
  CheckCircle2, XCircle, Clock, Calendar as CalendarIcon, 
  Search, Filter, Save, Printer, Users, ChevronLeft, ChevronRight,
  UserCheck, AlertTriangle, ShieldCheck
} from 'lucide-react';
import { MOCK_STUDENTS, CLASS_LIST, SECTION_LIST } from '../constants';

const AttendanceManagement: React.FC = () => {
  const [selectedClass, setSelectedClass] = useState('10');
  const [selectedSection, setSelectedSection] = useState('A');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  
  // Attendance State: { studentId: 'Present' | 'Absent' | 'Late' }
  const [attendance, setAttendance] = useState<Record<string, 'Present' | 'Absent' | 'Late'>>({});
  const [isSaved, setIsSaved] = useState(false);

  const filteredStudents = useMemo(() => {
    return MOCK_STUDENTS.filter(s => s.class === selectedClass && s.section === selectedSection);
  }, [selectedClass, selectedSection]);

  const stats = useMemo(() => {
    const values = filteredStudents.map(s => attendance[s.id]).filter(Boolean);
    return {
      present: values.filter(v => v === 'Present').length,
      absent: values.filter(v => v === 'Absent').length,
      late: values.filter(v => v === 'Late').length,
      total: filteredStudents.length
    };
  }, [attendance, filteredStudents]);

  const handleAttendanceChange = (studentId: string, status: 'Present' | 'Absent' | 'Late') => {
    setAttendance(prev => ({ ...prev, [studentId]: status }));
    setIsSaved(false);
  };

  const handleMarkAll = (status: 'Present' | 'Absent' | 'Late') => {
    const newAttendance: Record<string, 'Present' | 'Absent' | 'Late'> = { ...attendance };
    filteredStudents.forEach(s => {
      newAttendance[s.id] = status;
    });
    setAttendance(newAttendance);
    setIsSaved(false);
  };

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-6">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Attendance Registry</h1>
          <p className="text-slate-500">Track student presence across classes and sections daily.</p>
        </div>
        <div className="flex items-center gap-4 bg-white p-2 rounded-2xl border border-slate-100 shadow-sm no-print">
           <div className="flex items-center gap-2 px-3 border-r border-slate-100">
              <CalendarIcon size={18} className="text-indigo-600" />
              <input 
                type="date" 
                value={selectedDate} 
                onChange={(e) => setSelectedDate(e.target.value)}
                className="bg-transparent text-sm font-black outline-none"
              />
           </div>
           <div className="flex gap-2 px-2">
              <select 
                value={selectedClass} 
                onChange={(e) => setSelectedClass(e.target.value)}
                className="px-3 py-1.5 bg-slate-50 border-none rounded-xl text-xs font-black outline-none cursor-pointer"
              >
                 {CLASS_LIST.map(c => <option key={c} value={c}>{c === 'Nursery' || c === 'LKG' || c === 'UKG' ? c : `Class ${c}`}</option>)}
              </select>
              <select 
                value={selectedSection} 
                onChange={(e) => setSelectedSection(e.target.value)}
                className="px-3 py-1.5 bg-slate-50 border-none rounded-xl text-xs font-black outline-none cursor-pointer"
              >
                 {SECTION_LIST.map(s => <option key={s} value={s}>Section {s}</option>)}
              </select>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 no-print">
         {[
           { label: 'Strength', value: stats.total, color: 'bg-slate-100 text-slate-600', icon: <Users size={18}/> },
           { label: 'Present Today', value: stats.present, color: 'bg-emerald-50 text-emerald-600', icon: <UserCheck size={18}/> },
           { label: 'Absent Today', value: stats.absent, color: 'bg-rose-50 text-rose-600', icon: <XCircle size={18}/> },
           { label: 'Late Arrival', value: stats.late, color: 'bg-amber-50 text-amber-600', icon: <Clock size={18}/> },
         ].map((stat, idx) => (
           <div key={idx} className="bg-white p-6 rounded-[2rem] border border-slate-50 shadow-sm flex items-center justify-between">
              <div>
                 <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{stat.label}</p>
                 <h3 className="text-2xl font-black text-slate-900">{stat.value}</h3>
              </div>
              <div className={`p-4 rounded-2xl ${stat.color}`}>{stat.icon}</div>
           </div>
         ))}
      </div>

      <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden">
        <div className="p-8 border-b border-slate-100 bg-slate-50/30 flex flex-wrap justify-between items-center gap-4 no-print">
           <div className="flex gap-3">
              <button onClick={() => handleMarkAll('Present')} className="px-5 py-2.5 bg-emerald-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-emerald-700 transition-all">Mark All Present</button>
              <button onClick={() => handleMarkAll('Absent')} className="px-5 py-2.5 bg-rose-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-rose-700 transition-all">Mark All Absent</button>
           </div>
           <div className="flex gap-3">
              <button onClick={() => window.print()} className="p-3 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-indigo-600 transition-all shadow-sm"><Printer size={18}/></button>
              <button onClick={() => { setIsSaved(true); alert('Attendance Saved Successfully!'); }} className="px-8 py-2.5 bg-slate-900 text-white rounded-xl text-sm font-black shadow-xl shadow-slate-900/10 hover:bg-indigo-600 transition-all flex items-center gap-2">
                 <Save size={18}/> {isSaved ? 'Saved' : 'Save Changes'}
              </button>
           </div>
        </div>

        <div className="overflow-x-auto">
           <table className="w-full text-left">
              <thead className="bg-slate-50 text-slate-400 text-[10px] uppercase font-black tracking-widest border-b border-slate-100">
                 <tr>
                    <th className="px-10 py-6">Student Identity</th>
                    <th className="px-10 py-6">Roll No.</th>
                    <th className="px-10 py-6 text-center">Status Toggle</th>
                    <th className="px-10 py-6 text-right">Last Verified</th>
                 </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                 {filteredStudents.length > 0 ? filteredStudents.map((student) => (
                   <tr key={student.id} className="hover:bg-slate-50/50 transition-colors group">
                      <td className="px-10 py-6">
                         <div className="flex items-center gap-4">
                            <img src={student.photoUrl} className="w-12 h-12 rounded-xl object-cover border border-slate-100" alt="" />
                            <div>
                               <p className="font-black text-slate-900 leading-none mb-1.5">{student.name}</p>
                               <p className="text-[10px] text-slate-400 font-bold uppercase">ID: {student.id}</p>
                            </div>
                         </div>
                      </td>
                      <td className="px-10 py-6 font-black text-slate-600">{student.rollNo}</td>
                      <td className="px-10 py-6">
                         <div className="flex justify-center gap-2">
                            {(['Present', 'Absent', 'Late'] as const).map(status => (
                              <button 
                                key={status}
                                onClick={() => handleAttendanceChange(student.id, status)}
                                className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest border-2 transition-all ${
                                  attendance[student.id] === status 
                                    ? status === 'Present' ? 'bg-emerald-600 text-white border-emerald-600 shadow-lg' : status === 'Absent' ? 'bg-rose-600 text-white border-rose-600 shadow-lg' : 'bg-amber-500 text-white border-amber-500 shadow-lg'
                                    : 'bg-slate-50 text-slate-400 border-transparent hover:border-indigo-100 hover:text-indigo-600'
                                }`}
                              >
                                {status}
                              </button>
                            ))}
                         </div>
                      </td>
                      <td className="px-10 py-6 text-right">
                         {attendance[student.id] ? (
                           <div className="flex items-center justify-end gap-2">
                              <ShieldCheck size={16} className="text-emerald-500" />
                              <span className="text-[10px] font-black text-emerald-600 uppercase">Verified</span>
                           </div>
                         ) : (
                           <span className="text-[10px] font-black text-slate-300 uppercase italic">Awaiting Registry</span>
                         )}
                      </td>
                   </tr>
                 )) : (
                   <tr>
                     <td colSpan={4} className="p-20 text-center">
                       <div className="flex flex-col items-center gap-3 text-slate-300">
                         <AlertTriangle size={48} />
                         <p className="text-lg font-black">No students found for {selectedClass}-{selectedSection}</p>
                         <p className="text-xs font-medium uppercase tracking-widest">Ensure the student directory is populated.</p>
                       </div>
                     </td>
                   </tr>
                 )}
              </tbody>
           </table>
        </div>
      </div>
    </div>
  );
};

export default AttendanceManagement;