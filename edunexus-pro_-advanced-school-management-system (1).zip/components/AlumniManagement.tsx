import React, { useState, useMemo } from 'react';
import { 
  Trophy, Users, Calendar, Mail, Search, MessageSquare, 
  History, Plus, Star, MapPin, Briefcase, GraduationCap,
  ChevronRight, Sparkles, Filter, CheckCircle2, Heart, 
  HandHelping, TreePine, Dumbbell, Theater, Wallet, 
  X, UserCheck, AlertCircle, IndianRupee, Send, ShieldCheck,
  ShieldAlert, Landmark, Quote, Rocket, Target, Leaf
} from 'lucide-react';
import { MOCK_STUDENTS } from '../constants';

interface AlumniActivity {
  id: string;
  type: 'Charity' | 'Donation' | 'Environmental' | 'Sports' | 'Drama';
  title: string;
  description: string;
  amount?: number;
  isPrivileged?: boolean; // For underprivileged/merit students
  date: string;
  impact?: string;
}

const AlumniManagement: React.FC = () => {
  const [activeView, setActiveView] = useState<'directory' | 'activities' | 'mentorship'>('activities');
  const [isPortalActive, setIsPortalActive] = useState(false);
  const [showGraduateModal, setShowGraduateModal] = useState(false);
  const [showActivityModal, setShowActivityModal] = useState(false);
  const [searchStudent, setSearchStudent] = useState('');
  
  const [alumniRecords, setAlumniRecords] = useState([
    { id: 'AL-001', name: 'Dr. John Doe', batch: '2005', prof: 'Neurosurgeon', org: 'AIIMS Delhi', city: 'New Delhi', status: 'Mentor' },
    { id: 'AL-002', name: 'Alice Walker', batch: '2012', prof: 'Lead Engineer', org: 'Google Cloud', city: 'Mountain View', status: 'Active' },
    { id: 'AL-003', name: 'Rahul Khanna', batch: '1998', prof: 'Entrepreneur', org: 'GreenTech Solutions', city: 'Mumbai', status: 'Philanthropist' },
  ]);

  const [activities, setActivities] = useState<AlumniActivity[]>([
    { id: '1', type: 'Donation', title: 'Winter Uniform Fund', description: 'Donation for 50 privileged students in rural wings.', amount: 45000, isPrivileged: true, date: '2023-10-15', impact: '50 Students Impacted' },
    { id: '2', type: 'Environmental', title: 'Campus Solar Drive', description: 'Installing 10 solar panels in the athletic block.', date: '2023-09-20', impact: '20% Energy Reduction' },
    { id: '3', type: 'Drama', title: 'Annual Play Sponsorship', description: 'Financing costumes and stage for "The Merchant of Venice".', date: '2023-11-01', impact: 'Heritage Preserved' },
    { id: '4', type: 'Sports', title: 'Alumni-Student Cricket League', description: 'Friendly match and kit donation for the school team.', date: '2023-12-05', amount: 12000, impact: '100+ Players Joined' }
  ]);

  const filteredStudents = useMemo(() => {
    if (!searchStudent) return [];
    return MOCK_STUDENTS.filter(s => 
      s.name.toLowerCase().includes(searchStudent.toLowerCase()) || 
      s.id.toLowerCase().includes(searchStudent.toLowerCase())
    ).slice(0, 5);
  }, [searchStudent]);

  const handleGraduate = (student: any) => {
    const batch = new Date().getFullYear().toString();
    const newAlumnus = {
      id: `AL-${student.id.slice(-3)}`,
      name: student.name,
      batch: batch,
      prof: 'Fresh Graduate',
      org: 'EduNexus University',
      city: 'Local',
      status: 'Active'
    };
    setAlumniRecords([newAlumnus, ...alumniRecords]);
    setShowGraduateModal(false);
    setSearchStudent('');
    alert(`${student.name} has been formally added to the Alumni Network!`);
  };

  const handleAddActivity = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const newActivity: AlumniActivity = {
      id: Date.now().toString(),
      type: formData.get('type') as any,
      title: formData.get('title') as string,
      description: formData.get('description') as string,
      amount: formData.get('amount') ? Number(formData.get('amount')) : undefined,
      isPrivileged: formData.get('isPrivileged') === 'on',
      date: new Date().toISOString().split('T')[0],
      impact: formData.get('impact') as string
    };
    setActivities([newActivity, ...activities]);
    setShowActivityModal(false);
  };

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-6">
        <div>
          <h1 className="text-4xl font-black text-slate-900 italic uppercase tracking-tight">Alumni Legacy & Impact</h1>
          <p className="text-slate-500 font-medium">Empowering institutional heritage through charity, activities, and global recruitment.</p>
        </div>
        <div className="flex gap-4 no-print">
          <button 
            onClick={() => setShowGraduateModal(true)}
            className="px-6 py-3 bg-white border-2 border-slate-100 text-slate-600 rounded-2xl font-black text-sm flex items-center gap-2 hover:bg-slate-900 hover:text-white hover:border-slate-900 transition-all shadow-sm"
          >
            <UserCheck size={20} /> Recruitment Bridge
          </button>
          <button 
            onClick={() => setShowActivityModal(true)}
            className="px-6 py-3 bg-indigo-600 text-white rounded-2xl font-black text-sm flex items-center gap-2 shadow-xl shadow-indigo-500/20 hover:scale-105 transition-all"
          >
            <Plus size={20} /> Log Activity
          </button>
        </div>
      </div>

      <div className="flex bg-white p-1.5 rounded-2xl border border-slate-200 shadow-sm w-fit no-print">
        {[
          { id: 'directory', label: 'Legacy Directory', icon: <Users size={16}/> },
          { id: 'activities', label: 'Global Impact Hub', icon: <HandHelping size={16}/> },
          { id: 'mentorship', label: 'Expert Mentors', icon: <Star size={16}/> }
        ].map(tab => (
          <button 
            key={tab.id}
            onClick={() => setActiveView(tab.id as any)}
            className={`px-8 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 ${activeView === tab.id ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            {tab.icon} {tab.label}
          </button>
        ))}
      </div>

      {activeView === 'activities' && (
        <div className="space-y-10 animate-in slide-in-from-bottom-4 duration-500">
           {/* Summary Cards */}
           <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm relative overflow-hidden group hover:shadow-xl transition-all">
                 <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:scale-110 transition-transform"><Heart size={80}/></div>
                 <p className="text-[10px] font-black text-rose-500 uppercase tracking-widest mb-1">Charity Logged</p>
                 <h3 className="text-3xl font-black text-slate-900">{activities.filter(a => a.type === 'Charity').length} Projects</h3>
                 <p className="text-[10px] font-bold text-slate-400 mt-2 uppercase tracking-tight">Verified Social Service</p>
              </div>
              <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm relative overflow-hidden group hover:shadow-xl transition-all">
                 <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:scale-110 transition-transform"><IndianRupee size={80}/></div>
                 <p className="text-[10px] font-black text-emerald-600 uppercase tracking-widest mb-1">Total Donations</p>
                 <h3 className="text-3xl font-black text-slate-900">₹{activities.reduce((acc, a) => acc + (a.amount || 0), 0).toLocaleString()}</h3>
                 <p className="text-[10px] font-bold text-slate-400 mt-2 uppercase tracking-tight">Financial Support Flow</p>
              </div>
              <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm relative overflow-hidden group hover:shadow-xl transition-all">
                 <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:scale-110 transition-transform"><Target size={80}/></div>
                 <p className="text-[10px] font-black text-amber-600 uppercase tracking-widest mb-1">Privileged Fund</p>
                 <h3 className="text-3xl font-black text-slate-900">₹{activities.filter(a => a.isPrivileged).reduce((acc, a) => acc + (a.amount || 0), 0).toLocaleString()}</h3>
                 <p className="text-[10px] font-bold text-slate-400 mt-2 uppercase tracking-tight">For Disadvantaged Stars</p>
              </div>
              <div className="bg-indigo-600 p-8 rounded-[2.5rem] text-white shadow-xl shadow-indigo-500/20 flex flex-col justify-between group overflow-hidden">
                 <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:rotate-12 transition-transform"><Sparkles size={60}/></div>
                 <p className="text-[10px] font-black text-indigo-200 uppercase tracking-widest">Active Community</p>
                 <h3 className="text-3xl font-black">Global Reach</h3>
                 <div className="mt-4 flex -space-x-3">
                    {[1,2,3,4,5].map(i => <img key={i} src={`https://picsum.photos/seed/al-${i}/100`} className="w-8 h-8 rounded-full border-2 border-indigo-600" />)}
                    <div className="w-8 h-8 rounded-full bg-indigo-500 flex items-center justify-center text-[10px] font-black border-2 border-indigo-600">+120</div>
                 </div>
              </div>
           </div>

           <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-8">
                 <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
                    <div className="flex justify-between items-center mb-8">
                       <h3 className="text-2xl font-black text-slate-900 flex items-center gap-3"><HandHelping className="text-rose-500" /> Institution Impact Ledger</h3>
                       <div className="flex gap-2">
                          <button className="p-2.5 bg-slate-50 text-slate-400 rounded-xl hover:text-indigo-600 transition-all shadow-sm"><Filter size={18}/></button>
                       </div>
                    </div>
                    <div className="grid grid-cols-1 gap-6">
                       {activities.map(act => (
                         <div key={act.id} className="p-8 bg-slate-50 rounded-[2.5rem] border border-slate-100 flex items-start justify-between group hover:bg-white hover:border-indigo-200 transition-all hover:shadow-2xl">
                            <div className="flex gap-8">
                               <div className={`w-20 h-20 rounded-[2rem] flex items-center justify-center text-white shadow-2xl shrink-0 group-hover:scale-105 transition-transform ${
                                 act.type === 'Charity' ? 'bg-rose-500 shadow-rose-200' : 
                                 act.type === 'Donation' ? 'bg-emerald-500 shadow-emerald-200' : 
                                 act.type === 'Environmental' ? 'bg-teal-500 shadow-teal-200' : 
                                 act.type === 'Sports' ? 'bg-amber-500 shadow-amber-200' : 'bg-purple-500 shadow-purple-200'
                               }`}>
                                  {act.type === 'Charity' ? <Heart size={32}/> : 
                                   act.type === 'Donation' ? <Wallet size={32}/> : 
                                   act.type === 'Environmental' ? <Leaf size={32}/> : 
                                   act.type === 'Sports' ? <Dumbbell size={32}/> : <Theater size={32}/>}
                               </div>
                               <div>
                                  <div className="flex flex-wrap items-center gap-3">
                                     <h4 className="text-2xl font-black text-slate-900 tracking-tight">{act.title}</h4>
                                     <span className={`text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest ${
                                       act.type === 'Donation' ? 'bg-emerald-50 text-emerald-600' : 'bg-indigo-50 text-indigo-600'
                                     }`}>{act.type}</span>
                                  </div>
                                  <p className="text-sm font-medium text-slate-500 mt-2 leading-relaxed max-w-lg">{act.description}</p>
                                  
                                  <div className="flex flex-wrap items-center gap-6 mt-6 pt-6 border-t border-slate-200/50 text-[10px] font-black uppercase tracking-[0.1em]">
                                     <span className="flex items-center gap-2 text-slate-400 bg-white px-3 py-1.5 rounded-xl shadow-sm"><Calendar size={14}/> {act.date}</span>
                                     {act.amount && <span className="flex items-center gap-2 text-emerald-600 bg-emerald-50 px-3 py-1.5 rounded-xl shadow-sm"><IndianRupee size={12}/> {act.amount.toLocaleString()}</span>}
                                     {act.impact && <span className="flex items-center gap-2 text-indigo-600 bg-indigo-50 px-3 py-1.5 rounded-xl shadow-sm"><Rocket size={14}/> {act.impact}</span>}
                                     {act.isPrivileged && <span className="flex items-center gap-2 text-rose-500 bg-rose-50 px-3 py-1.5 rounded-xl shadow-sm border border-rose-100"><ShieldCheck size={14}/> Privileged Fund</span>}
                                  </div>
                               </div>
                            </div>
                            <button className="p-3 opacity-0 group-hover:opacity-100 bg-indigo-50 text-indigo-600 rounded-2xl transition-all hover:bg-indigo-600 hover:text-white"><ChevronRight size={24}/></button>
                         </div>
                       ))}
                    </div>
                 </div>
              </div>

              <div className="space-y-8">
                 <div className="bg-slate-900 p-12 rounded-[4rem] text-white shadow-2xl relative overflow-hidden group">
                    <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform"><Landmark size={120} /></div>
                    <div className="bg-indigo-500/20 text-indigo-400 px-4 py-1 rounded-full text-[10px] font-black uppercase inline-block mb-6">Financial Bridge</div>
                    <h3 className="text-3xl font-black mb-6 leading-tight">Contribution Console</h3>
                    <p className="text-sm text-slate-400 leading-relaxed mb-10 font-medium">Support the upcoming sports complex or fund a scholarship for our top performers who need aid.</p>
                    
                    <div className="space-y-4">
                       <button onClick={() => setShowActivityModal(true)} className="w-full py-5 bg-indigo-600 rounded-[2rem] font-black text-xs uppercase tracking-widest flex items-center justify-center gap-3 hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-500/20 active:scale-95">
                          <HandHelping size={18}/> New Charity Work
                       </button>
                       <button onClick={() => setShowActivityModal(true)} className="w-full py-5 bg-white/10 rounded-[2rem] font-black text-xs uppercase tracking-widest flex items-center justify-center gap-3 hover:bg-white/20 transition-all border border-white/5">
                          <Wallet size={18}/> Accept Donation
                       </button>
                    </div>
                 </div>

                 <div className="bg-rose-600 p-10 rounded-[3.5rem] text-white shadow-2xl shadow-rose-500/30 relative overflow-hidden group">
                    <div className="absolute top-0 right-0 p-4 opacity-20 -rotate-12 group-hover:rotate-0 transition-transform"><Quote size={60}/></div>
                    <h4 className="text-2xl font-black mb-4">Privileged Student Fund</h4>
                    <p className="text-sm text-rose-100 font-medium mb-8 leading-relaxed">Direct support for tuition and kits for high-achieving students from low-income backgrounds.</p>
                    <div className="bg-black/20 p-6 rounded-3xl border border-white/10 mb-8">
                       <div className="flex justify-between items-center mb-2">
                          <span className="text-[10px] font-black uppercase tracking-widest">Fund Target</span>
                          <span className="text-lg font-black tracking-tight">₹2,00,000</span>
                       </div>
                       <div className="w-full h-2 bg-white/20 rounded-full overflow-hidden">
                          <div className="h-full bg-white" style={{width: '64%'}}></div>
                       </div>
                    </div>
                    <button className="w-full py-4 bg-white text-rose-600 rounded-2xl font-black text-xs uppercase tracking-[0.2em] hover:bg-rose-50 transition-all active:scale-95 shadow-xl">Contribute Now</button>
                 </div>
              </div>
           </div>
        </div>
      )}

      {activeView === 'directory' && (
        <div className="space-y-8 animate-in fade-in duration-300">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { label: 'Verified Graduates', value: alumniRecords.length + 3000, color: 'text-indigo-600', icon: <Users size={20}/> },
              { label: 'Fiscal Equity', value: '₹12.4L', color: 'text-emerald-600', icon: <Landmark size={20}/> },
              { label: 'Expert Mentors', value: '142', color: 'text-amber-600', icon: <Star size={20}/> },
              { label: 'Live Projects', value: '12', color: 'text-rose-600', icon: <History size={20}/> },
            ].map((stat, idx) => (
              <div key={idx} className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm flex items-center gap-6 group hover:shadow-lg transition-all">
                <div className={`p-5 bg-slate-50 rounded-3xl ${stat.color} group-hover:scale-110 transition-transform`}>{stat.icon}</div>
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{stat.label}</p>
                  <h3 className="text-3xl font-black text-slate-900">{stat.value}</h3>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-[3.5rem] border border-slate-100 shadow-sm overflow-hidden">
            <div className="p-10 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
               <h3 className="text-xl font-black text-slate-900 uppercase italic tracking-tighter">Legacy Honor Roll</h3>
               <div className="flex gap-4">
                  <div className="relative group">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-600 transition-colors" size={18} />
                    <input type="text" placeholder="Filter by batch or firm..." className="pl-12 pr-4 py-4 bg-white border border-slate-200 rounded-[1.5rem] text-xs font-black outline-none focus:ring-4 focus:ring-indigo-500/5 transition-all shadow-inner w-64" />
                  </div>
               </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-slate-50 text-slate-400 text-[10px] font-black uppercase tracking-[0.2em]">
                  <tr>
                    <th className="px-10 py-7">Member Identity</th>
                    <th className="px-10 py-7">Expertise & Firm</th>
                    <th className="px-10 py-7">Registry Status</th>
                    <th className="px-10 py-7 text-right">Channel</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {alumniRecords.map(rec => (
                    <tr key={rec.id} className="hover:bg-slate-50/50 transition-colors group">
                      <td className="px-10 py-7">
                        <div className="flex items-center gap-5">
                          <div className="w-14 h-14 bg-indigo-50 rounded-[1.5rem] flex items-center justify-center text-indigo-600 font-black text-2xl shadow-sm">{rec.name[0]}</div>
                          <div>
                            <p className="text-lg font-black text-slate-900 leading-none">{rec.name}</p>
                            <p className="text-[10px] font-bold text-slate-400 uppercase mt-1">Class of {rec.batch} • UID: {rec.id}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-10 py-7">
                         <p className="text-base font-black text-slate-800 leading-tight">{rec.prof}</p>
                         <p className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest mt-1 flex items-center gap-1"><Briefcase size={12}/> {rec.org}</p>
                      </td>
                      <td className="px-10 py-7">
                         <span className={`px-4 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest ${rec.status === 'Mentor' ? 'bg-amber-100 text-amber-600 border border-amber-200' : 'bg-indigo-50 text-indigo-600 border border-indigo-100'}`}>{rec.status}</span>
                      </td>
                      <td className="px-10 py-7 text-right">
                         <button className="p-4 bg-white text-slate-400 hover:text-indigo-600 border border-slate-100 hover:border-indigo-200 rounded-2xl transition-all shadow-sm hover:shadow-indigo-500/10"><Mail size={20}/></button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* PORTAL ACTIVATION SECTION */}
      <div className="bg-slate-900 p-16 rounded-[4.5rem] text-white relative overflow-hidden shadow-[0_50px_100px_-20px_rgba(0,0,0,0.5)] group">
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-indigo-500/10 rounded-full blur-[120px] -translate-y-48 translate-x-48 group-hover:bg-indigo-500/20 transition-all duration-1000"></div>
        <div className="flex flex-col lg:flex-row items-center justify-between gap-16 relative z-10">
          <div className="max-w-2xl">
            <div className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] inline-block mb-6 transition-all ${isPortalActive ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'}`}>
               <span className="flex items-center gap-2">
                 <div className={`w-1.5 h-1.5 rounded-full animate-pulse ${isPortalActive ? 'bg-emerald-400' : 'bg-rose-400'}`}></div>
                 Status: {isPortalActive ? 'Global Sync Live' : 'Awaiting Encryption Activation'}
               </span>
            </div>
            <h3 className="text-5xl font-black mb-8 leading-[1.1] tracking-tighter">Central Legacy Hub Control</h3>
            <p className="text-slate-400 text-xl leading-relaxed mb-12 font-medium">Establish a secure, encrypted bridge between the institution and our global alumni. Activating this module enables peer-to-peer messaging, mentorship booking, and automated fundraising logs.</p>
            <div className="flex flex-wrap gap-6">
              <button 
                onClick={() => setIsPortalActive(!isPortalActive)}
                className={`px-12 py-6 rounded-[2.5rem] font-black text-sm shadow-2xl transition-all hover:scale-105 active:scale-95 uppercase tracking-widest ${isPortalActive ? 'bg-emerald-600 text-white shadow-emerald-500/30' : 'bg-indigo-600 text-white shadow-indigo-500/30'}`}
              >
                {isPortalActive ? 'Deactivate Hub' : 'Activate Hub Protocol'}
              </button>
              <button 
                onClick={() => alert('Dispatching Legacy Newsletter to 3,120 active members...')}
                className="px-12 py-6 bg-white/5 hover:bg-white/10 text-white rounded-[2.5rem] font-black text-sm transition-all border border-white/10 uppercase tracking-widest"
              >
                Broadcast Newsletter
              </button>
            </div>
          </div>
          <div className="w-full lg:w-[450px] aspect-[4/5] bg-white/5 border border-white/10 rounded-[4rem] p-12 backdrop-blur-xl flex flex-col group/card hover:border-indigo-500/50 transition-all shadow-[0_30px_60px_-15px_rgba(0,0,0,0.3)]">
             <div className={`w-full h-1/2 rounded-[3rem] mb-12 flex items-center justify-center border transition-all duration-700 shadow-inner ${isPortalActive ? 'bg-emerald-500/10 border-emerald-500/20' : 'bg-slate-800/50 border-white/5'}`}>
                {isPortalActive ? (
                   <ShieldCheck size={120} className="text-emerald-400 animate-in zoom-in duration-500" />
                ) : (
                   <ShieldAlert size={120} className="text-slate-700 group-hover/card:text-indigo-400 transition-all duration-700 group-hover/card:scale-110" />
                )}
             </div>
             <div className="space-y-5">
                <div className={`h-4 w-3/4 rounded-full transition-all duration-700 ${isPortalActive ? 'bg-emerald-500/20' : 'bg-slate-700/50'}`}></div>
                <div className={`h-4 w-1/2 rounded-full transition-all duration-700 ${isPortalActive ? 'bg-emerald-500/10' : 'bg-slate-700/30'}`}></div>
                <div className={`h-4 w-5/6 rounded-full transition-all duration-700 ${isPortalActive ? 'bg-emerald-500/5' : 'bg-slate-700/20'}`}></div>
             </div>
             <div className="mt-auto pt-12 border-t border-white/10 flex justify-between items-center">
                <div className="flex flex-col">
                   <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Active Node ID</span>
                   <span className="text-2xl font-black text-white tracking-tighter">NODE-0042-X</span>
                </div>
                <div className={`w-16 h-16 rounded-3xl flex items-center justify-center transition-all duration-700 shadow-2xl ${isPortalActive ? 'bg-emerald-500 shadow-emerald-500/20' : 'bg-indigo-600/20 shadow-indigo-500/10'}`}>
                   {isPortalActive ? <CheckCircle2 size={32} className="text-white" /> : <Landmark size={32} className="text-indigo-500" />}
                </div>
             </div>
          </div>
        </div>
      </div>

      {/* RECRUITMENT MODAL */}
      {showGraduateModal && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-900/80 backdrop-blur-md p-4 animate-in fade-in" onClick={() => setShowGraduateModal(false)}>
           <div className="bg-white rounded-[4rem] p-12 max-w-2xl w-full shadow-2xl relative overflow-hidden" onClick={(e) => e.stopPropagation()}>
              <div className="absolute top-0 left-0 w-3 h-full bg-indigo-600"></div>
              <div className="flex justify-between items-start mb-10">
                 <div>
                   <h3 className="text-4xl font-black text-slate-900 tracking-tighter">Legacy Recruitment</h3>
                   <p className="text-sm text-slate-500 font-medium italic mt-1">Promote active students to the Alumni honors list.</p>
                 </div>
                 <button onClick={() => setShowGraduateModal(false)} className="p-3 hover:bg-slate-100 rounded-full text-slate-400 transition-colors"><X size={36}/></button>
              </div>

              <div className="space-y-10">
                 <div className="space-y-3">
                    <label className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] px-3">Search Active Directory</label>
                    <div className="relative group">
                       <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-600 transition-colors" size={24} />
                       <input 
                         autoFocus
                         value={searchStudent}
                         onChange={(e) => setSearchStudent(e.target.value)}
                         placeholder="Type student name or ID..."
                         className="w-full pl-20 pr-6 py-6 bg-slate-50 border-2 border-slate-100 rounded-[2.5rem] font-black text-xl outline-none focus:bg-white focus:border-indigo-500 focus:ring-8 focus:ring-indigo-500/5 transition-all shadow-inner"
                       />
                    </div>
                 </div>

                 <div className="space-y-4 max-h-[350px] overflow-y-auto pr-2 custom-scrollbar">
                    {filteredStudents.map(student => (
                      <div 
                        key={student.id} 
                        onClick={() => handleGraduate(student)}
                        className="p-6 bg-white border border-slate-100 rounded-[2rem] flex items-center justify-between group hover:border-indigo-500 hover:bg-indigo-50/50 cursor-pointer transition-all shadow-sm hover:shadow-xl"
                      >
                         <div className="flex items-center gap-6">
                            <img src={student.photoUrl} className="w-16 h-16 rounded-3xl object-cover border-2 border-slate-50 shadow-sm" />
                            <div>
                               <p className="text-xl font-black text-slate-900 leading-none">{student.name}</p>
                               <p className="text-[10px] font-black text-indigo-600 uppercase tracking-widest mt-1.5 flex items-center gap-1.5">
                                 <GraduationCap size={12}/> Grade {student.class}-{student.section} • Roll {student.rollNo}
                               </p>
                            </div>
                         </div>
                         <div className="p-4 bg-indigo-600 text-white rounded-2xl opacity-0 group-hover:opacity-100 transition-all shadow-lg shadow-indigo-500/20 translate-x-4 group-hover:translate-x-0">
                            <UserCheck size={24} />
                         </div>
                      </div>
                    ))}
                    {searchStudent && filteredStudents.length === 0 && (
                      <div className="py-20 text-center flex flex-col items-center gap-4 text-slate-200">
                         <Users size={100} className="opacity-10" />
                         <p className="font-black text-2xl italic uppercase tracking-widest opacity-40">No matches found.</p>
                      </div>
                    )}
                 </div>
              </div>
           </div>
        </div>
      )}

      {/* ACTIVITY MODAL */}
      {showActivityModal && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-900/80 backdrop-blur-md p-4 animate-in fade-in" onClick={() => setShowActivityModal(false)}>
          <div className="bg-white rounded-[4rem] p-12 max-w-2xl w-full shadow-2xl relative overflow-hidden max-h-[95vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
             <div className="absolute top-0 left-0 w-3 h-full bg-rose-500"></div>
             <div className="flex justify-between items-start mb-12">
                <div>
                   <h3 className="text-4xl font-black text-slate-900 tracking-tighter">Global Impact Entry</h3>
                   <p className="text-sm text-slate-500 font-medium italic mt-1">Document charity, donations, and campus activities.</p>
                </div>
                <button onClick={() => setShowActivityModal(null)} className="p-3 hover:bg-slate-100 rounded-full text-slate-400 transition-colors"><X size={36}/></button>
             </div>

             <form onSubmit={handleAddActivity} className="space-y-8">
                <div className="grid grid-cols-2 gap-8">
                   <div className="space-y-3">
                      <label className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] px-3">Primary Domain</label>
                      <select name="type" required className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none focus:bg-white focus:border-rose-500 transition-all">
                         <option value="Charity">Charity Work</option>
                         <option value="Donation">General Donation</option>
                         <option value="Environmental">Environmental Action (Green)</option>
                         <option value="Sports">Sports Engagement</option>
                         <option value="Drama">Drama & Arts Presence</option>
                      </select>
                   </div>
                   <div className="space-y-3">
                      <label className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] px-3">Impact Metrics</label>
                      <input name="impact" placeholder="e.g. 50 Trees Planted" className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none focus:bg-white focus:border-indigo-500 transition-all" />
                   </div>
                </div>

                <div className="space-y-3">
                   <label className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] px-3">Project Title</label>
                   <input name="title" required placeholder="e.g. Clean River Initiative" className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-lg outline-none focus:bg-white transition-all shadow-inner" />
                </div>

                <div className="space-y-3">
                   <label className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] px-3">Description & Vision</label>
                   <textarea name="description" required rows={3} placeholder="Describe the goal and achievement..." className="w-full p-6 bg-slate-50 border-2 border-slate-100 rounded-[2.5rem] font-black text-sm outline-none focus:bg-white resize-none transition-all shadow-inner"></textarea>
                </div>

                <div className="p-8 bg-indigo-50/50 rounded-[3rem] border-2 border-indigo-100/50">
                   <div className="grid grid-cols-2 gap-8">
                      <div className="space-y-3">
                         <label className="text-[11px] font-black text-indigo-400 uppercase tracking-[0.2em] px-3">Fiscal Commitment (₹)</label>
                         <div className="relative">
                            <IndianRupee className="absolute left-5 top-1/2 -translate-y-1/2 text-indigo-300" size={18} />
                            <input name="amount" type="number" placeholder="Optional contribution" className="w-full pl-12 pr-6 py-5 bg-white border-2 border-indigo-100 rounded-[2rem] font-black text-lg outline-none focus:border-indigo-500 transition-all" />
                         </div>
                      </div>
                      <div className="flex items-center gap-4 pt-10">
                         <div className="relative">
                           <input type="checkbox" name="isPrivileged" id="priv_check" className="w-8 h-8 rounded-xl text-rose-500 border-2 border-rose-200 focus:ring-rose-500 cursor-pointer" />
                         </div>
                         <label htmlFor="priv_check" className="text-xs font-black text-slate-600 uppercase tracking-widest cursor-pointer group">
                           Target: <span className="text-rose-500">Privileged Student Fund</span>
                         </label>
                      </div>
                   </div>
                </div>

                <button type="submit" className="w-full py-6 bg-slate-900 text-white rounded-[3rem] font-black text-lg shadow-2xl hover:bg-rose-600 transition-all uppercase tracking-widest flex items-center justify-center gap-4 active:scale-95">
                   <Send size={24}/> Finalize Ledger Entry
                </button>
             </form>
          </div>
        </div>
      )}

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #e2e8f0; border-radius: 10px; }
      `}</style>
    </div>
  );
};

export default AlumniManagement;