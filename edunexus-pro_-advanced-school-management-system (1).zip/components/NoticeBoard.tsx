
import React, { useState, useEffect } from 'react';
import { generateSchoolNotice } from '../services/geminiService';
import { supabase } from '../lib/supabase';
import { 
  Bell, Sparkles, Send, Calendar, Clock, MapPin, Plus, 
  Loader2, Trash2, Edit3, X, Save, ShieldCheck, 
  Search, Megaphone, Target
} from 'lucide-react';

interface Notice {
  id: string;
  title: string;
  content: string;
  date: string;
  category: 'General' | 'Academic' | 'Events';
  postedAt?: string;
  location?: string;
}

const NoticeBoard: React.FC = () => {
  const [topic, setTopic] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [showEventModal, setShowEventModal] = useState(false);
  const [editingNotice, setEditingNotice] = useState<Notice | null>(null);
  const [notices, setNotices] = useState<Notice[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchNotices();
  }, []);

  const fetchNotices = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('notices')
        .select('*')
        .order('date', { ascending: false });
      
      if (!error) setNotices(data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleGenerate = async () => {
    if (!topic) return;
    setIsGenerating(true);
    const result = await generateSchoolNotice(topic);
    if (result) {
      const newNotice: Partial<Notice> = { 
        title: result.title,
        content: result.content,
        category: 'Academic',
        date: result.date || new Date().toLocaleDateString(),
        postedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        location: 'Virtual Portal'
      };
      
      const { data, error } = await supabase.from('notices').insert([newNotice]).select();
      if (!error && data) setNotices([data[0], ...notices]);
      setTopic('');
    }
    setIsGenerating(false);
  };

  const handleDelete = async (id: string) => {
    if (confirm('Permanently wipe this notice?')) {
      const { error } = await supabase.from('notices').delete().eq('id', id);
      if (!error) setNotices(prev => prev.filter(n => n.id !== id));
    }
  };

  const handleSaveNotice = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const noticeData: any = {
      title: formData.get('title') as string,
      content: formData.get('content') as string,
      category: formData.get('category') as any,
      date: formData.get('date') as string || new Date().toLocaleDateString(),
      location: formData.get('location') as string || 'School Campus'
    };

    if (editingNotice) {
      const { error } = await supabase.from('notices').update(noticeData).eq('id', editingNotice.id);
      if (!error) fetchNotices();
    } else {
      const { error } = await supabase.from('notices').insert([noticeData]);
      if (!error) fetchNotices();
    }

    setShowEventModal(false);
    setEditingNotice(null);
  };

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-7xl mx-auto overflow-x-hidden">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-6 no-print">
        <div>
          <h1 className="text-3xl md:text-4xl font-black text-slate-900 italic uppercase tracking-tighter leading-none">Communication Center</h1>
          <p className="text-slate-500 font-medium text-[11px] md:text-sm uppercase tracking-widest mt-1">Institutional Announcements • Sync: {loading ? '...' : 'Live'}</p>
        </div>
        <button 
          onClick={() => { setEditingNotice(null); setShowEventModal(true); }}
          className="px-8 py-4 bg-indigo-600 text-white rounded-2xl text-xs font-black flex items-center justify-center gap-3 shadow-2xl shadow-indigo-500/30 hover:scale-105 active:scale-95 transition-all uppercase tracking-widest"
        >
          <Plus size={20} /> Create Event
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 space-y-8">
           <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-6 opacity-20 group-hover:scale-110 transition-transform"><Sparkles className="text-indigo-400" size={40} /></div>
              <h3 className="text-xl font-black text-slate-900 mb-2">AI Composer</h3>
              <textarea 
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                className="w-full h-40 p-6 bg-slate-50 border-2 border-slate-100 rounded-[2rem] text-sm font-bold focus:outline-none focus:bg-white focus:border-indigo-500 transition-all resize-none shadow-inner"
                placeholder="Topic for AI generation..."
              />
              <button 
                onClick={handleGenerate}
                disabled={isGenerating || !topic}
                className="w-full mt-4 py-5 bg-indigo-600 disabled:bg-indigo-300 text-white rounded-[1.5rem] font-black text-xs uppercase tracking-widest flex items-center justify-center gap-3 shadow-xl active:scale-95 transition-all"
              >
                {isGenerating ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
                Generate
              </button>
           </div>
        </div>

        <div className="lg:col-span-2">
           <div className="bg-white rounded-[3.5rem] border border-slate-100 shadow-sm overflow-hidden">
              <div className="p-8 md:p-10 border-b border-slate-50 flex flex-col md:flex-row justify-between items-center gap-6 bg-slate-50/30">
                 <h3 className="text-xl md:text-2xl font-black text-slate-900 italic uppercase tracking-tighter">Live Announcements</h3>
              </div>
              
              <div className="divide-y divide-slate-100 max-h-[75vh] overflow-y-auto custom-scrollbar">
                 {notices.map((notice) => (
                   <div key={notice.id} className="p-8 md:p-10 hover:bg-slate-50/50 transition-all group relative overflow-hidden">
                      <div className="absolute top-1/2 -translate-y-1/2 right-10 flex gap-2 opacity-0 group-hover:opacity-100 transition-all translate-x-4 group-hover:translate-x-0">
                         <button onClick={() => { setEditingNotice(notice); setShowEventModal(true); }} className="p-3 bg-white border border-slate-200 text-slate-400 hover:text-indigo-600 rounded-xl shadow-sm"><Edit3 size={18}/></button>
                         <button onClick={() => handleDelete(notice.id)} className="p-3 bg-white border border-slate-200 text-slate-400 hover:text-rose-600 rounded-xl shadow-sm"><Trash2 size={18}/></button>
                      </div>
                      <h4 className="text-2xl font-black text-slate-900 tracking-tight leading-none mb-2">{notice.title}</h4>
                      <p className="text-slate-600 leading-relaxed mb-8 text-sm md:text-base font-medium max-w-2xl">{notice.content}</p>
                      <div className="flex flex-wrap items-center gap-x-8 gap-y-3 text-slate-400 text-[10px] font-black uppercase tracking-widest">
                         <div className="flex items-center gap-2"><Calendar size={14} className="text-indigo-500" /> {notice.date}</div>
                         <div className="flex items-center gap-2"><MapPin size={14} className="text-rose-500" /> {notice.location}</div>
                      </div>
                   </div>
                 ))}
              </div>
           </div>
        </div>
      </div>

      {showEventModal && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center bg-slate-900/60 backdrop-blur-md p-4 animate-in fade-in" onClick={() => setShowEventModal(false)}>
           <div className="bg-white rounded-[3.5rem] p-10 md:p-12 max-w-2xl w-full shadow-2xl relative overflow-hidden" onClick={(e) => e.stopPropagation()}>
              <div className="absolute top-0 left-0 w-3 h-full bg-indigo-600"></div>
              <h3 className="text-3xl font-black text-slate-900 tracking-tighter uppercase mb-8">Deploy Notice</h3>
              <form onSubmit={handleSaveNotice} className="space-y-8">
                 <input name="title" required defaultValue={editingNotice?.title} placeholder="Heading" className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-lg outline-none focus:bg-white" />
                 <textarea name="content" required rows={4} defaultValue={editingNotice?.content} placeholder="Draft message..." className="w-full p-6 bg-slate-50 border-2 border-slate-100 rounded-[2.5rem] font-black text-sm outline-none resize-none"></textarea>
                 <button type="submit" className="w-full py-6 bg-indigo-600 text-white rounded-[2.5rem] font-black text-lg shadow-2xl uppercase tracking-widest active:scale-95">Commit to Ledger</button>
              </form>
           </div>
        </div>
      )}
    </div>
  );
};

export default NoticeBoard;
