
import React, { useState } from 'react';
import { 
  Key, Search, Filter, Eye, EyeOff, ShieldCheck, Plus, X, Save, 
  Trash2, Edit3, Fingerprint, Shield, GraduationCap, 
  User, AlertCircle, PlusCircle, MinusCircle, BookOpen
} from 'lucide-react';
import { MOCK_CREDENTIALS, CLASS_LIST, SECTION_LIST } from '../constants';
import { LoginCredential, UserRole, TeacherAssignment } from '../types';

interface SecurityVaultProps {
  userRole?: UserRole;
}

const SecurityVault: React.FC<SecurityVaultProps> = ({ userRole = UserRole.ADMIN }) => {
  const [search, setSearch] = useState('');
  const [showPass, setShowPass] = useState<Record<string, boolean>>({});
  const [credentials, setCredentials] = useState<LoginCredential[]>(MOCK_CREDENTIALS);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingCred, setEditingCred] = useState<LoginCredential | null>(null);
  const [tempAssignments, setTempAssignments] = useState<TeacherAssignment[]>([]);

  const canManage = userRole === UserRole.ADMIN || userRole === UserRole.STAFF;

  const togglePass = (uid: string) => {
    setShowPass(prev => ({ ...prev, [uid]: !prev[uid] }));
  };

  const filtered = credentials.filter(c => 
    c.name.toLowerCase().includes(search.toLowerCase()) || 
    c.uid.toLowerCase().includes(search.toLowerCase()) ||
    c.role.toLowerCase().includes(search.toLowerCase())
  );

  const handleAddSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const newCred: LoginCredential = {
      uid: formData.get('uid') as string,
      name: formData.get('name') as string,
      role: formData.get('role') as string,
      password: formData.get('password') as string,
      category: formData.get('category') as string,
      assignments: (formData.get('role') === 'TEACHER') ? tempAssignments : undefined
    };

    if (editingCred) {
      setCredentials(prev => prev.map(c => c.uid === editingCred.uid ? newCred : c));
    } else {
      setCredentials([newCred, ...credentials]);
    }
    
    setShowAddModal(false);
    setEditingCred(null);
    setTempAssignments([]);
  };

  const addAssignment = () => {
    setTempAssignments([...tempAssignments, { class: '10', section: 'A', subject: 'General', isClassTeacher: false }]);
  };

  const updateAssignment = (idx: number, field: keyof TeacherAssignment, value: any) => {
    const updated = [...tempAssignments];
    updated[idx] = { ...updated[idx], [field]: value };
    setTempAssignments(updated);
  };

  const removeAssignment = (idx: number) => {
    setTempAssignments(tempAssignments.filter((_, i) => i !== idx));
  };

  return (
    <div className="p-4 md:p-10 space-y-6 md:space-y-10 max-w-7xl mx-auto overflow-x-hidden">
      <div className="bg-slate-950 p-6 md:p-16 rounded-[2rem] md:rounded-[4.5rem] text-white relative overflow-hidden shadow-2xl">
         <div className="absolute top-0 right-0 w-[400px] md:w-[600px] h-[400px] md:h-[600px] bg-indigo-500/10 rounded-full blur-[100px] md:blur-[120px] -translate-y-1/2 translate-x-1/2"></div>
         <div className="flex flex-col lg:flex-row items-center justify-between gap-8 md:gap-10 relative z-10">
            <div className="space-y-4 md:space-y-6 text-center lg:text-left">
               <div className="flex items-center justify-center lg:justify-start gap-4 md:gap-6 mb-2">
                  <div className="w-12 h-12 md:w-24 md:h-24 bg-rose-600 rounded-2xl md:rounded-[2.5rem] flex items-center justify-center shadow-2xl shadow-rose-900/50"><Key size={24} className="md:w-16 md:h-16" /></div>
                  <div>
                     <h1 className="text-xl md:text-5xl font-black italic uppercase tracking-tighter">Security Vault</h1>
                     <p className="text-rose-300 font-bold uppercase text-[8px] md:text-sm tracking-widest mt-0.5 md:mt-1">Credential Controller Node</p>
                  </div>
               </div>
               <p className="text-slate-400 text-xs md:text-xl font-medium leading-relaxed max-w-3xl mx-auto lg:mx-0">Manage all academic and administrative identities in the secure ledger.</p>
            </div>
            {canManage && (
              <button 
                onClick={() => { setEditingCred(null); setTempAssignments([]); setShowAddModal(true); }}
                className="w-full lg:w-auto px-6 md:px-10 py-4 md:py-6 bg-indigo-600 text-white rounded-xl md:rounded-[2rem] font-black text-[10px] md:text-sm uppercase tracking-widest flex items-center justify-center gap-3 shadow-2xl hover:scale-105 transition-all group"
              >
                <Fingerprint size={20} className="group-hover:rotate-12 transition-transform" /> New Identity
              </button>
            )}
         </div>
      </div>

      <div className="bg-white rounded-[1.5rem] md:rounded-[3.5rem] border border-slate-100 shadow-sm overflow-hidden">
         <div className="p-4 md:p-10 bg-slate-50/50 border-b border-slate-100">
            <div className="relative w-full max-w-md group">
               <Search className="absolute left-4 md:left-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-600 transition-colors" size={18} />
               <input 
                type="text" 
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search Identity..." 
                className="w-full pl-11 md:pl-14 pr-4 md:pr-6 py-3 md:py-5 bg-white border border-slate-200 rounded-xl md:rounded-[2rem] text-[11px] md:text-sm font-black outline-none focus:ring-4 md:focus:ring-8 focus:ring-indigo-500/5 transition-all shadow-inner"
               />
            </div>
         </div>

         <div className="overflow-x-auto">
            <table className="w-full text-left whitespace-nowrap min-w-[700px]">
               <thead className="bg-slate-50 text-slate-400 text-[8px] md:text-[10px] font-black uppercase tracking-[0.2em] border-b border-slate-100">
                  <tr>
                     <th className="px-6 md:px-10 py-5 md:py-8">User Identity</th>
                     <th className="px-6 md:px-10 py-5 md:py-8">Cloud UID</th>
                     <th className="px-6 md:px-10 py-5 md:py-8">Assignments</th>
                     <th className="px-6 md:px-10 py-5 md:py-8">Password</th>
                     {canManage && <th className="px-6 md:px-10 py-5 md:py-8 text-right">Actions</th>}
                  </tr>
               </thead>
               <tbody className="divide-y divide-slate-100">
                  {filtered.map((cred) => (
                    <tr key={cred.uid} className="hover:bg-slate-50/50 transition-colors group">
                       <td className="px-6 md:px-10 py-5 md:py-8">
                          <div className="flex items-center gap-3 md:gap-4">
                             <div className="w-10 h-10 md:w-12 md:h-12 bg-indigo-50 rounded-lg md:rounded-2xl flex items-center justify-center text-indigo-600 font-black text-sm md:text-xl shadow-sm">{cred.name[0]}</div>
                             <div>
                                <p className="text-sm md:text-lg font-black text-slate-900 leading-none">{cred.name}</p>
                                <p className="text-[8px] md:text-[10px] font-bold text-slate-400 uppercase mt-1 md:mt-1.5 flex items-center gap-1.5 md:gap-2">
                                  {cred.role === 'ADMIN' ? <Shield size={10}/> : cred.role === 'TEACHER' ? <GraduationCap size={10}/> : <User size={10}/>}
                                  {cred.role}
                                </p>
                             </div>
                          </div>
                       </td>
                       <td className="px-6 md:px-10 py-5 md:py-8"><span className="px-3 py-1 md:px-4 md:py-2 bg-slate-100 text-slate-600 rounded-lg md:rounded-xl font-black text-[9px] md:text-[10px] uppercase tracking-widest border border-slate-200">{cred.uid}</span></td>
                       <td className="px-6 md:px-10 py-5 md:py-8">
                         {cred.assignments && cred.assignments.length > 0 ? (
                           <div className="flex flex-wrap gap-1.5 md:gap-2 max-w-[200px]">
                             {cred.assignments.map((a, i) => (
                               <span key={i} className="text-[8px] md:text-[9px] font-black text-indigo-600 bg-indigo-50 px-2 py-0.5 md:py-1 rounded border border-indigo-100">
                                 {a.isClassTeacher && '★ '} {a.class}-{a.section}
                               </span>
                             ))}
                           </div>
                         ) : (
                           <span className="text-[9px] md:text-[10px] font-bold text-slate-300 uppercase italic">Admin Node</span>
                         )}
                       </td>
                       <td className="px-6 md:px-10 py-5 md:py-8">
                          <div className="flex items-center gap-2 md:gap-4">
                             <p className="font-mono font-black text-slate-900 tracking-tighter text-xs md:text-base">
                               {showPass[cred.uid] ? cred.password : '••••••••'}
                             </p>
                             <button onClick={() => togglePass(cred.uid)} className="p-1.5 md:p-2 text-slate-300 hover:text-indigo-600 transition-colors">
                               {showPass[cred.uid] ? <EyeOff size={16}/> : <Eye size={16}/>}
                             </button>
                          </div>
                       </td>
                       {canManage && (
                         <td className="px-6 md:px-10 py-5 md:py-8 text-right">
                            <div className="flex justify-end gap-1.5 md:gap-2 sm:opacity-0 group-hover:opacity-100 transition-opacity">
                               <button 
                                 onClick={() => { setEditingCred(cred); setTempAssignments(cred.assignments || []); setShowAddModal(true); }}
                                 className="p-2 md:p-3 bg-white border border-slate-200 text-slate-400 hover:text-indigo-600 hover:border-indigo-200 rounded-lg md:rounded-xl transition-all shadow-sm"
                               >
                                  <Edit3 size={16}/>
                               </button>
                               <button 
                                 onClick={() => setCredentials(prev => prev.filter(c => c.uid !== cred.uid))}
                                 className="p-2 md:p-3 bg-white border border-slate-200 text-slate-400 hover:text-rose-600 hover:border-rose-200 rounded-lg md:rounded-xl transition-all shadow-sm"
                               >
                                  <Trash2 size={16}/>
                               </button>
                            </div>
                         </td>
                       )}
                    </tr>
                  ))}
               </tbody>
            </table>
         </div>
      </div>

      {showAddModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in" onClick={() => setShowAddModal(false)}>
           <div className="bg-white rounded-[2rem] md:rounded-[3.5rem] p-6 md:p-12 max-w-4xl w-full shadow-2xl relative overflow-y-auto max-h-[95vh]" onClick={(e) => e.stopPropagation()}>
              <div className="flex justify-between items-start mb-6 md:mb-10 sticky top-0 bg-white z-10 pb-2">
                 <div>
                   <h3 className="text-xl md:text-3xl font-black text-slate-900 tracking-tighter">
                    {editingCred ? 'Modify Node' : 'Register Identity'}
                   </h3>
                   <p className="text-[10px] md:text-sm text-slate-500 font-medium italic">Define permissions in the ledger.</p>
                 </div>
                 <button onClick={() => setShowAddModal(false)} className="p-2 hover:bg-slate-100 rounded-full text-slate-400 transition-colors"><X size={24}/></button>
              </div>

              <form onSubmit={handleAddSubmit} className="space-y-6 md:space-y-10">
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-8">
                    <div className="space-y-2">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-2">Full Legal Name</label>
                       <input name="name" required defaultValue={editingCred?.name} className="w-full p-4 md:p-5 bg-slate-50 border-2 border-slate-100 rounded-xl md:rounded-[2rem] font-black text-xs md:text-sm outline-none focus:bg-white focus:border-indigo-500 transition-all shadow-inner" />
                    </div>
                    <div className="space-y-2">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-2">Institutional Role</label>
                       <select name="role" required defaultValue={editingCred?.role} className="w-full p-4 md:p-5 bg-slate-50 border-2 border-slate-100 rounded-xl md:rounded-[2rem] font-black text-xs md:text-sm outline-none focus:bg-white focus:border-indigo-500 transition-all">
                          <option value="PARENT">Student / Parent</option>
                          <option value="TEACHER">Academic Faculty</option>
                          <option value="STAFF">Administrative Staff</option>
                          <option value="ADMIN">System Administrator</option>
                       </select>
                    </div>
                 </div>

                 <div className="space-y-4 bg-indigo-50/50 p-6 md:p-8 rounded-[1.5rem] md:rounded-[3rem] border border-indigo-100">
                    <div className="flex justify-between items-center mb-4">
                       <h4 className="text-sm md:text-lg font-black text-indigo-900 flex items-center gap-2"><BookOpen size={18}/> Academic Lines</h4>
                       <button type="button" onClick={addAssignment} className="flex items-center gap-1.5 px-3 py-1.5 md:px-4 md:py-2 bg-indigo-600 text-white rounded-lg md:rounded-xl text-[9px] md:text-[10px] font-black uppercase tracking-widest shadow-lg">
                          <PlusCircle size={14}/> Add Subject
                       </button>
                    </div>
                    <div className="space-y-3">
                       {tempAssignments.map((a, idx) => (
                         <div key={idx} className="grid grid-cols-1 sm:grid-cols-5 gap-3 items-end bg-white p-4 rounded-xl shadow-sm">
                            <div className="sm:col-span-1 space-y-1">
                               <label className="text-[8px] font-black text-slate-400 uppercase">Class</label>
                               <select value={a.class} onChange={(e) => updateAssignment(idx, 'class', e.target.value)} className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-black text-[10px] outline-none">
                                  {CLASS_LIST.map(c => <option key={c} value={c}>{c}</option>)}
                               </select>
                            </div>
                            <div className="sm:col-span-1 space-y-1">
                               <label className="text-[8px] font-black text-slate-400 uppercase">Sec</label>
                               <select value={a.section} onChange={(e) => updateAssignment(idx, 'section', e.target.value)} className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-black text-[10px] outline-none">
                                  {SECTION_LIST.map(s => <option key={s} value={s}>{s}</option>)}
                               </select>
                            </div>
                            <div className="sm:col-span-1 space-y-1">
                               <label className="text-[8px] font-black text-slate-400 uppercase">Subject</label>
                               <input value={a.subject} onChange={(e) => updateAssignment(idx, 'subject', e.target.value)} className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-black text-[10px] outline-none" />
                            </div>
                            <div className="sm:col-span-1 flex items-center gap-2 py-2">
                               <input type="checkbox" checked={a.isClassTeacher} onChange={(e) => updateAssignment(idx, 'isClassTeacher', e.target.checked)} className="w-4 h-4 rounded text-indigo-600" />
                               <label className="text-[8px] font-black text-slate-400 uppercase">Class Teacher?</label>
                            </div>
                            <div className="sm:col-span-1 text-right">
                               <button type="button" onClick={() => removeAssignment(idx)} className="p-2 text-rose-400 hover:bg-rose-50 rounded-lg"><MinusCircle size={18}/></button>
                            </div>
                         </div>
                       ))}
                    </div>
                 </div>

                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-8">
                    <div className="space-y-2">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-2">Cloud UID</label>
                       <input name="uid" required defaultValue={editingCred?.uid} disabled={!!editingCred} className="w-full p-4 md:p-5 bg-slate-50 border-2 border-slate-100 rounded-xl md:rounded-[2rem] font-black text-xs md:text-sm outline-none focus:bg-white focus:border-indigo-500 transition-all disabled:opacity-50" />
                    </div>
                    <div className="space-y-2">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-2">Access Key</label>
                       <input name="password" required defaultValue={editingCred?.password} className="w-full p-4 md:p-5 bg-slate-50 border-2 border-slate-100 rounded-xl md:rounded-[2rem] font-black text-xs md:text-sm outline-none focus:bg-white focus:border-emerald-500 transition-all shadow-inner" />
                    </div>
                 </div>

                 <button type="submit" className="w-full py-5 md:py-6 bg-slate-950 text-white rounded-2xl md:rounded-[3rem] font-black md:text-lg shadow-2xl hover:bg-emerald-600 transition-all uppercase tracking-widest flex items-center justify-center gap-3">
                    <Save size={20}/> {editingCred ? 'Synchronize' : 'Commit to Vault'}
                 </button>
              </form>
           </div>
        </div>
      )}
    </div>
  );
};

export default SecurityVault;
