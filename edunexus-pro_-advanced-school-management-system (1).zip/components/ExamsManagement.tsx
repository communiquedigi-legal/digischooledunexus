
import React, { useState, useMemo, useEffect } from 'react';
import { 
  GraduationCap, FileText, Globe, Pencil, CheckCircle2, Plus, 
  Loader2, Sparkles, Send, Eye, Save, Trash2, X, Calendar as CalendarIcon, 
  Clock, Hash, Users, Layers, Trophy, BarChart2, Share2, Printer,
  Settings2, Percent, ListOrdered, Award, TrendingUp, TrendingDown,
  ChevronRight, ClipboardCheck, Edit3, BookOpen, Layout, ListPlus,
  ShieldCheck, AlertTriangle, FileUp, Zap, PieChart as PieChartIcon,
  ArrowUpRight, MinusCircle, PlusCircle, Columns, Download, BookMarked,
  FileCheck, Info, ArrowRight, UserCheck, ShieldAlert, Target, Building
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from 'recharts';
import { MOCK_STUDENTS, CLASS_LIST, SECTION_LIST } from '../constants';
import { supabase } from '../lib/supabase';

interface MatchPair {
  left: string;
  right: string;
}

interface Question {
  id: string;
  type: 'MCQ' | 'Short' | 'Long' | 'Match';
  text: string;
  marks: number;
  options?: string[];
  matchPairs?: MatchPair[];
}

interface QuestionPaper {
  id: string;
  examId: number;
  subject: string;
  class: string;
  section: string;
  duration?: string;
  instructions?: string;
  questions: Question[];
}

interface ExamRecord {
  id: number;
  sub: string;
  class: string;
  section: string;
  date: string;
  time: string;
  maxMarks: number;
  passingMarks: number;
  type: 'Online' | 'Offline';
  status: 'Scheduled' | 'Completed' | 'Published';
}

const ExamsManagement: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'schedule' | 'builder' | 'entry' | 'results'>('schedule');
  const [selectedClass, setSelectedClass] = useState('10');
  const [selectedSection, setSelectedSection] = useState('A');
  const [selectedExamId, setSelectedExamId] = useState<number | null>(null);

  const [exams, setExams] = useState<ExamRecord[]>([
    { id: 101, sub: 'Mathematics', class: '10', section: 'A', date: '2025-05-30', time: '09:00 AM', maxMarks: 100, passingMarks: 40, type: 'Offline', status: 'Scheduled' },
    { id: 102, sub: 'Physics', class: '10', section: 'A', date: '2025-06-02', time: '11:30 AM', maxMarks: 80, passingMarks: 32, type: 'Online', status: 'Scheduled' },
  ]);

  const [papers, setPapers] = useState<QuestionPaper[]>([
    {
      id: 'P101', examId: 101, subject: 'Mathematics', class: '10', section: 'A', duration: '3 Hours', instructions: 'Attempt all questions. Scientific calculators allowed.',
      questions: [
        { id: 'q1', type: 'MCQ', text: 'Solve for x: 2x + 5 = 15', marks: 5, options: ['x=2', 'x=5', 'x=10', 'x=15'] },
        { id: 'q2', type: 'Short', text: 'Define a Prime Number with examples.', marks: 10 },
      ]
    }
  ]);

  const [ledgerMarks, setLedgerMarks] = useState<Record<string, number>>({});
  const [isSavingLedger, setIsSavingLedger] = useState(false);

  // Modal States
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [showPaperBuilderModal, setShowPaperBuilderModal] = useState(false);
  const [showPaperPreview, setShowPaperPreview] = useState(false);
  
  const [newQuestionType, setNewQuestionType] = useState<'MCQ' | 'Short' | 'Long' | 'Match'>('MCQ');
  const [matchPairs, setMatchPairs] = useState<MatchPair[]>([{ left: '', right: '' }, { left: '', right: '' }]);

  const currentExam = useMemo(() => exams.find(e => e.id === selectedExamId), [exams, selectedExamId]);
  const currentPaper = useMemo(() => papers.find(p => p.examId === selectedExamId), [papers, selectedExamId]);

  const currentPaperTotalMarks = useMemo(() => {
    return currentPaper?.questions.reduce((acc, q) => acc + q.marks, 0) || 0;
  }, [currentPaper]);

  const calculateGrade = (score: number, maxMarks: number) => {
    if (!maxMarks) return { label: 'N/A', color: 'text-slate-400 bg-slate-50' };
    const percentage = (score / maxMarks) * 100;
    if (percentage >= 90) return { label: 'A+', color: 'text-emerald-600 bg-emerald-50' };
    if (percentage >= 80) return { label: 'A', color: 'text-emerald-500 bg-emerald-50' };
    if (percentage >= 70) return { label: 'B', color: 'text-indigo-600 bg-indigo-50' };
    if (percentage >= 60) return { label: 'C', color: 'text-amber-600 bg-amber-50' };
    return { label: 'F', color: 'text-rose-600 bg-rose-50' };
  };

  // Fix: Added handleScheduleSubmit to process new exam entries
  const handleScheduleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const newExam: ExamRecord = {
      id: Date.now(),
      sub: fd.get('subject') as string,
      class: selectedClass,
      section: selectedSection,
      date: fd.get('date') as string,
      time: fd.get('time') as string,
      maxMarks: 100,
      passingMarks: 40,
      type: 'Offline',
      status: 'Scheduled'
    };
    setExams(prev => [...prev, newExam]);
    setShowScheduleModal(false);
  };

  const handleAddQuestion = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedExamId || !currentExam) return;
    const fd = new FormData(e.currentTarget);
    const marksValue = parseInt(fd.get('marks') as string);
    
    if (currentPaperTotalMarks + marksValue > currentExam.maxMarks) {
      alert(`Error: Limit exceeded.`);
      return;
    }

    const newQ: Question = {
      id: `q${Date.now()}`,
      type: newQuestionType,
      text: fd.get('text') as string,
      marks: marksValue,
      options: newQuestionType === 'MCQ' ? [
        fd.get('optA') as string, fd.get('optB') as string,
        fd.get('optC') as string, fd.get('optD') as string
      ] : undefined,
      matchPairs: newQuestionType === 'Match' ? matchPairs.filter(p => p.left.trim() && p.right.trim()) : undefined
    };

    const paperIdx = papers.findIndex(p => p.examId === selectedExamId);
    if (paperIdx > -1) {
      const updated = [...papers];
      updated[paperIdx] = { ...updated[paperIdx], questions: [...updated[paperIdx].questions, newQ] };
      setPapers(updated);
    } else {
      setPapers([...papers, {
        id: `P${selectedExamId}`, examId: selectedExamId, subject: currentExam.sub,
        class: currentExam.class, section: currentExam.section, duration: '3 Hours',
        instructions: 'Follow Hall guidelines.', questions: [newQ]
      }]);
    }
    setShowPaperBuilderModal(false);
  };

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-7xl mx-auto overflow-x-hidden min-h-screen">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-6 no-print">
        <div>
          <h1 className="text-3xl md:text-5xl font-black text-slate-900 italic uppercase tracking-tighter leading-none">Exam Registry</h1>
          <p className="text-[10px] md:text-sm font-medium text-slate-500 uppercase tracking-widest mt-1">Institutional Governance Node</p>
        </div>
        <div className="flex bg-white p-1 rounded-2xl border border-slate-200 shadow-sm overflow-x-auto scrollbar-hide">
          {[
            { id: 'schedule', label: 'Schedule', icon: <CalendarIcon size={14} /> },
            { id: 'builder', label: 'Paper Architect', icon: <Layout size={14} /> },
            { id: 'entry', label: 'Mark Ledger', icon: <Pencil size={14} /> },
            { id: 'results', label: 'Analytics', icon: <Trophy size={14} /> },
          ].map(tab => (
            <button 
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-6 py-2.5 rounded-xl text-[10px] md:text-xs font-black transition-all flex items-center gap-2 whitespace-nowrap ${activeTab === tab.id ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-50'}`}
            >
              {tab.icon} {tab.label}
            </button>
          ))}
        </div>
      </div>

      {activeTab === 'schedule' && (
        <div className="space-y-8 animate-in fade-in">
           <div className="flex flex-col md:flex-row justify-between items-center bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm gap-6">
              <div className="flex gap-4 w-full md:w-auto">
                 <select value={selectedClass} onChange={(e) => setSelectedClass(e.target.value)} className="px-6 py-3 bg-slate-50 border-2 border-transparent focus:bg-white focus:border-indigo-500 rounded-2xl font-black text-xs outline-none transition-all">
                    {CLASS_LIST.map(c => <option key={c} value={c}>Class {c}</option>)}
                 </select>
                 <select value={selectedSection} onChange={(e) => setSelectedSection(e.target.value)} className="px-6 py-3 bg-slate-50 border-2 border-transparent focus:bg-white focus:border-indigo-500 rounded-2xl font-black text-xs outline-none transition-all">
                    {SECTION_LIST.map(s => <option key={s} value={s}>Section {s}</option>)}
                 </select>
              </div>
              <button onClick={() => setShowScheduleModal(true)} className="w-full md:w-auto px-10 py-5 bg-indigo-600 text-white rounded-[2rem] font-black text-xs uppercase tracking-widest flex items-center justify-center gap-3 shadow-2xl shadow-indigo-500/30 hover:scale-105 active:scale-95 transition-all">
                <Plus size={20} /> Schedule Event
              </button>
           </div>

           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {exams.filter(ex => ex.class === selectedClass && ex.section === selectedSection).map(exam => (
                <div key={exam.id} className="bg-white p-10 rounded-[3rem] border border-slate-100 hover:shadow-2xl transition-all relative group overflow-hidden">
                   <div className="space-y-4 relative z-10">
                      <div className="flex justify-between items-center">
                         <span className={`px-4 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest ${exam.type === 'Online' ? 'bg-sky-50 text-sky-600' : 'bg-indigo-50 text-indigo-600'}`}>{exam.type} Mode</span>
                         <span className="text-[10px] font-bold text-slate-300 uppercase">Node #{exam.id}</span>
                      </div>
                      <h3 className="text-3xl font-black text-slate-900 tracking-tight">{exam.sub}</h3>
                      <div className="grid grid-cols-2 gap-4 py-6 border-y border-slate-50">
                         <div className="space-y-1"><p className="text-[9px] font-black text-slate-400 uppercase tracking-tighter">Timeline</p><div className="flex items-center gap-2 text-xs font-black text-slate-700"><CalendarIcon size={14}/> {exam.date}</div></div>
                         <div className="space-y-1"><p className="text-[9px] font-black text-slate-400 uppercase tracking-tighter">Capacity</p><div className="flex items-center gap-2 text-xs font-black text-slate-700"><Clock size={14}/> {exam.time}</div></div>
                      </div>
                      <div className="flex justify-between items-center pt-2">
                         <div className="flex items-center gap-2">
                            <div className={`w-2 h-2 rounded-full ${exam.status === 'Scheduled' ? 'bg-indigo-500 animate-pulse' : 'bg-emerald-500'}`}></div>
                            <span className="text-[10px] font-black uppercase text-slate-500">{exam.status}</span>
                         </div>
                         <button onClick={() => { setSelectedExamId(exam.id); setActiveTab('builder'); }} className="p-4 bg-slate-900 text-white rounded-2xl hover:bg-indigo-600 transition-all shadow-xl group-hover:scale-110"><Layout size={20}/></button>
                      </div>
                   </div>
                </div>
              ))}
              {exams.filter(ex => ex.class === selectedClass && ex.section === selectedSection).length === 0 && (
                <div className="col-span-full py-32 text-center bg-white rounded-[4rem] border-2 border-dashed border-slate-100">
                   <CalendarIcon size={48} className="mx-auto text-slate-100 mb-6"/>
                   <h3 className="text-xl font-black text-slate-300 italic uppercase">No Scheduled Nodes</h3>
                   <p className="text-sm font-medium text-slate-400 mt-2">Initialize assessment schedule for Grade {selectedClass}-{selectedSection}.</p>
                </div>
              )}
           </div>
        </div>
      )}

      {activeTab === 'builder' && (
        <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
           <div className="bg-slate-950 p-10 md:p-16 rounded-[4rem] text-white flex flex-col lg:flex-row justify-between items-center gap-12 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-10 opacity-5 rotate-12"><Zap size={200}/></div>
              <div className="relative z-10 space-y-6 text-center lg:text-left">
                 <div className="bg-indigo-500/20 text-indigo-400 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] inline-block border border-white/5">Paper Architect Node</div>
                 <h2 className="text-4xl md:text-6xl font-black italic uppercase tracking-tighter leading-none">
                    {currentExam ? `${currentExam.sub} Manifest` : 'Select Target Node'}
                 </h2>
                 {currentExam && (
                    <div className="flex flex-wrap justify-center lg:justify-start gap-8 mt-10">
                       <div className="space-y-1"><p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Weightage</p><p className="text-3xl font-black">{currentPaperTotalMarks} / {currentExam.maxMarks}</p></div>
                       <div className="space-y-1"><p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Query Count</p><p className="text-3xl font-black">{currentPaper?.questions.length || 0}</p></div>
                    </div>
                 )}
              </div>
              <div className="flex flex-col gap-4 relative z-10 w-full lg:w-auto">
                 <select 
                   value={selectedExamId || ''} 
                   onChange={(e) => setSelectedExamId(parseInt(e.target.value))} 
                   className="w-full lg:w-72 px-8 py-5 bg-white/5 border border-white/10 rounded-[2rem] font-black text-base outline-none focus:bg-white/10 transition-all text-white"
                 >
                    <option value="" className="text-slate-900">Target Node...</option>
                    {exams.map(e => <option key={e.id} value={e.id}>{e.sub} (Grade {e.class}-{e.section})</option>)}
                 </select>
                 {selectedExamId && (
                    <div className="flex gap-3">
                       <button onClick={() => setShowPaperBuilderModal(true)} className="flex-1 px-8 py-5 bg-indigo-600 text-white rounded-[2rem] font-black text-xs uppercase tracking-widest shadow-2xl hover:bg-indigo-500 transition-all flex items-center justify-center gap-3">
                          <Plus size={18}/> New Query
                       </button>
                       <button onClick={() => setShowPaperPreview(true)} className="p-5 bg-white text-slate-900 rounded-[1.5rem] shadow-xl hover:bg-indigo-50 transition-all"><Eye size={20}/></button>
                    </div>
                 )}
              </div>
           </div>
           
           {!selectedExamId && (
             <div className="p-32 bg-white rounded-[4rem] border-2 border-dashed border-slate-200 text-center animate-in zoom-in-95">
                <Layout size={80} className="mx-auto text-slate-100 mb-8"/>
                <h3 className="text-3xl font-black text-slate-200 italic uppercase tracking-tighter">Selection Required</h3>
                <p className="text-slate-400 mt-4 font-medium italic">Initialize assessment architecture by choosing a context above.</p>
             </div>
           )}

           {currentPaper && currentPaper.questions.length > 0 && (
             <div className="bg-white p-10 md:p-14 rounded-[4rem] border border-slate-100 shadow-sm space-y-10">
                <div className="flex justify-between items-center border-b border-slate-50 pb-8">
                   <h3 className="text-2xl font-black text-slate-900 flex items-center gap-4"><BookMarked className="text-indigo-600" size={28}/> Question Manifest</h3>
                </div>
                <div className="space-y-8">
                   {currentPaper.questions.map((q, idx) => (
                      <div key={q.id} className="p-10 bg-slate-50 rounded-[3rem] border border-slate-100 group hover:bg-white hover:border-indigo-200 transition-all hover:shadow-2xl">
                         <div className="flex justify-between items-start mb-6">
                            <div className="flex items-center gap-6">
                               <span className="w-14 h-14 bg-indigo-900 text-white rounded-[1.5rem] flex items-center justify-center font-black text-2xl shadow-xl italic">{idx + 1}</span>
                               <span className="px-3 py-1 bg-indigo-50 text-indigo-600 rounded-lg text-[9px] font-black uppercase tracking-widest">{q.type} Mode</span>
                            </div>
                            <div className="text-right">
                               <p className="text-[10px] font-black text-slate-400 uppercase">Weightage</p>
                               <p className="text-xl font-black text-slate-900">{q.marks} M</p>
                            </div>
                         </div>
                         <p className="text-2xl font-black text-slate-800 leading-tight mb-8 whitespace-pre-wrap">{q.text}</p>
                      </div>
                   ))}
                </div>
             </div>
           )}
        </div>
      )}

      {activeTab === 'results' && (
        <div className="p-32 text-center bg-white rounded-[4rem] border border-slate-100 shadow-sm animate-in zoom-in-95">
           <BarChart2 size={80} className="mx-auto text-indigo-100 mb-8"/>
           <h3 className="text-3xl font-black text-slate-900 italic uppercase tracking-tighter">Analytics Node</h3>
           <p className="text-slate-400 mt-4 font-medium max-w-lg mx-auto">Consolidating performance metrics across all legacy nodes.</p>
        </div>
      )}

      {/* RENDER MODALS IN ROOT LEVEL PORTAL SIMULATION */}
      {showScheduleModal && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in" onClick={() => setShowScheduleModal(false)}>
           <div className="bg-white rounded-[3.5rem] p-10 md:p-14 max-w-2xl w-full shadow-2xl relative overflow-hidden" onClick={(e) => e.stopPropagation()}>
              <div className="absolute top-0 left-0 w-3 h-full bg-indigo-600"></div>
              <div className="flex justify-between items-start mb-10">
                 <h3 className="text-4xl font-black text-slate-900 tracking-tighter italic leading-none">Schedule Assessment</h3>
                 <button onClick={() => setShowScheduleModal(false)} className="p-3 hover:bg-slate-100 rounded-full text-slate-400 transition-colors"><X size={36}/></button>
              </div>
              <form onSubmit={handleScheduleSubmit} className="space-y-8">
                 <input name="subject" required placeholder="Subject Identification" className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-base outline-none focus:bg-white focus:border-indigo-500" />
                 <div className="grid grid-cols-2 gap-8">
                    <input name="date" type="date" required className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none" />
                    <input name="time" type="time" required className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none" />
                 </div>
                 <button type="submit" className="w-full py-8 bg-indigo-600 text-white rounded-[3rem] font-black text-xl shadow-2xl active:scale-95 transition-all">Authorize Node</button>
              </form>
           </div>
        </div>
      )}
    </div>
  );
};

export default ExamsManagement;
