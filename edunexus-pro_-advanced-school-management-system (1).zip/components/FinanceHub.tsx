import React, { useState, useMemo } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, AreaChart, Area
} from 'recharts';
import { 
  BarChart3, Landmark, Wallet, TrendingUp, TrendingDown, Package, 
  Calendar, FileText, ChevronRight, ArrowUpRight, ArrowDownRight,
  Filter, Download, Calculator, ShieldCheck, IndianRupee, Layers,
  Printer
} from 'lucide-react';

const FinanceHub: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'overview' | 'statements' | 'inventory'>('overview');

  const monthlyCashflow = [
    { name: 'Jul', revenue: 420000, expenses: 280000 },
    { name: 'Aug', revenue: 380000, expenses: 290000 },
    { name: 'Sep', revenue: 510000, expenses: 310000 },
    { name: 'Oct', revenue: 640000, expenses: 320000 },
    { name: 'Nov', revenue: 590000, expenses: 305000 },
    { name: 'Dec', revenue: 480000, expenses: 300000 },
  ];

  const inventoryAllocation = [
    { name: 'IT Lab', value: 1240000, color: '#6366f1' },
    { name: 'Furniture', value: 850000, color: '#10b981' },
    { name: 'Science Lab', value: 420000, color: '#f59e0b' },
    { name: 'AV Dept', value: 310000, color: '#ef4444' },
  ];

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      <header className="flex flex-col md:flex-row md:justify-between md:items-center gap-6">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Institutional Finance Hub</h1>
          <p className="text-slate-500">Balance sheets, profit-loss tracking, and inventory equity reports.</p>
        </div>
        <div className="flex bg-white p-1 rounded-2xl border border-slate-200 shadow-sm overflow-x-auto no-print">
          {[
            { id: 'overview', label: 'Cashflow Overview', icon: <TrendingUp size={16} /> },
            { id: 'statements', label: 'Financial Statements', icon: <FileText size={16} /> },
            { id: 'inventory', label: 'Inventory Equity', icon: <Package size={16} /> },
          ].map(tab => (
            <button 
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-6 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 whitespace-nowrap ${activeTab === tab.id ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}
            >
              {tab.icon} {tab.label}
            </button>
          ))}
        </div>
      </header>

      {activeTab === 'overview' && (
        <div className="space-y-8 animate-in fade-in duration-300">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
             <div className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Institutional Liquidity</p>
                <h3 className="text-2xl font-black text-slate-900">₹42.84L</h3>
                <span className="text-[10px] font-bold text-emerald-500 mt-2 flex items-center gap-1"><ArrowUpRight size={12}/> +8.4% this qtr</span>
             </div>
             <div className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Annual Revenue (YTD)</p>
                <h3 className="text-2xl font-black text-indigo-600">₹1.28Cr</h3>
                <span className="text-[10px] font-bold text-slate-400 mt-2">Target: ₹1.5Cr</span>
             </div>
             <div className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Opex (Staff + Ops)</p>
                <h3 className="text-2xl font-black text-rose-500">₹64.2L</h3>
                <span className="text-[10px] font-bold text-rose-400 mt-2 flex items-center gap-1"><ArrowUpRight size={12}/> +2% hike apply</span>
             </div>
             <div className="bg-slate-900 p-6 rounded-[2rem] text-white shadow-xl shadow-slate-900/10 flex flex-col justify-between">
                <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Net Surplus</p>
                <h3 className="text-2xl font-black">₹63.8L</h3>
                <button className="text-[9px] font-black uppercase text-indigo-300 hover:text-white transition-colors">Download Financial Audit &rarr;</button>
             </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
             <div className="lg:col-span-2 bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
                <div className="flex justify-between items-center mb-10">
                   <h3 className="text-xl font-black text-slate-900">Revenue vs. Expenditure</h3>
                   <div className="flex gap-4">
                      <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-indigo-500"></div><span className="text-[10px] font-black text-slate-400 uppercase">Revenue</span></div>
                      <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-rose-400"></div><span className="text-[10px] font-black text-slate-400 uppercase">Expenses</span></div>
                   </div>
                </div>
                <div className="h-[300px]">
                   <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={monthlyCashflow}>
                         <defs>
                            <linearGradient id="colorRev" x1="0" x2="0" y2="1">
                               <stop offset="5%" stopColor="#6366f1" stopOpacity={0.1}/>
                               <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                            </linearGradient>
                         </defs>
                         <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                         <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 10}} />
                         <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 10}} />
                         <Tooltip />
                         <Area type="monotone" dataKey="revenue" stroke="#6366f1" fillOpacity={1} fill="url(#colorRev)" strokeWidth={3} />
                         <Area type="monotone" dataKey="expenses" stroke="#fb7185" fill="transparent" strokeWidth={3} strokeDasharray="5 5" />
                      </AreaChart>
                   </ResponsiveContainer>
                </div>
             </div>

             <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm flex flex-col">
                <h3 className="text-xl font-black text-slate-900 mb-2">Collection Health</h3>
                <p className="text-sm font-medium text-slate-400 mb-8">Real-time status of student fee receivables.</p>
                <div className="flex-1 flex flex-col justify-center gap-8">
                   <div className="space-y-3">
                      <div className="flex justify-between items-center"><span className="text-xs font-black text-slate-600 uppercase">Collected Fees</span><span className="font-mono font-bold">₹84.2L</span></div>
                      <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                         <div className="h-full bg-emerald-500 rounded-full" style={{ width: '84%' }}></div>
                      </div>
                   </div>
                   <div className="space-y-3">
                      <div className="flex justify-between items-center"><span className="text-xs font-black text-slate-600 uppercase">Outstanding Dues</span><span className="font-mono font-bold">₹15.8L</span></div>
                      <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                         <div className="h-full bg-rose-400 rounded-full" style={{ width: '16%' }}></div>
                      </div>
                   </div>
                </div>
                <div className="mt-10 pt-8 border-t border-slate-50 flex justify-between items-center">
                   <div><p className="text-[10px] font-black text-slate-400 uppercase">Total Expected</p><p className="text-xl font-black text-slate-900">₹1.00Cr</p></div>
                   <button className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl hover:bg-indigo-600 hover:text-white transition-all"><Download size={20}/></button>
                </div>
             </div>
          </div>
        </div>
      )}

      {activeTab === 'statements' && (
        <div className="space-y-10 animate-in fade-in duration-300">
           <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
              {/* BALANCE SHEET */}
              <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
                 <div className="flex justify-between items-start mb-10">
                    <div>
                       <h3 className="text-2xl font-black text-slate-900">Balance Sheet</h3>
                       <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">Fiscal Year 2023-24 • Verified</p>
                    </div>
                    <button className="px-5 py-2.5 bg-slate-900 text-white rounded-xl text-[10px] font-black uppercase shadow-lg shadow-slate-900/10 flex items-center gap-2"><Printer size={14}/> Print PDF</button>
                 </div>
                 <div className="space-y-8">
                    <div className="space-y-4">
                       <p className="text-[10px] font-black text-emerald-600 uppercase tracking-widest border-b border-emerald-50 pb-2">Institutional Assets</p>
                       <div className="flex justify-between text-sm"><span className="font-medium text-slate-500">Cash & Bank Balances</span><span className="font-black">₹42,84,000</span></div>
                       <div className="flex justify-between text-sm"><span className="font-medium text-slate-500">Inventory Value (Gross)</span><span className="font-black">₹28,50,000</span></div>
                       <div className="flex justify-between text-sm"><span className="font-medium text-slate-500">Accounts Receivable (Fees)</span><span className="font-black">₹15,80,000</span></div>
                    </div>
                    <div className="space-y-4">
                       <p className="text-[10px] font-black text-rose-600 uppercase tracking-widest border-b border-rose-50 pb-2">Institutional Liabilities</p>
                       <div className="flex justify-between text-sm"><span className="font-medium text-slate-500">Unearned Revenue (Prepaid Fees)</span><span className="font-black">₹12,40,000</span></div>
                       <div className="flex justify-between text-sm"><span className="font-medium text-slate-500">Accounts Payable (Suppliers)</span><span className="font-black">₹2,10,000</span></div>
                    </div>
                    <div className="pt-6 border-t-2 border-slate-100 flex justify-between items-center">
                       <span className="text-lg font-black text-slate-900">Institutional Equity</span>
                       <span className="text-2xl font-black text-indigo-600">₹72,64,000</span>
                    </div>
                 </div>
              </div>

              {/* PROFIT & LOSS */}
              <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
                 <div className="flex justify-between items-start mb-10">
                    <div>
                       <h3 className="text-2xl font-black text-slate-900">Profit & Loss</h3>
                       <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">Operating Surplus Statement</p>
                    </div>
                 </div>
                 <div className="space-y-8">
                    <div className="space-y-4">
                       <p className="text-[10px] font-black text-indigo-600 uppercase tracking-widest border-b border-indigo-50 pb-2">Revenue Streams</p>
                       <div className="flex justify-between text-sm"><span className="font-medium text-slate-500">Tuition Fees Collected</span><span className="font-black">₹84,20,000</span></div>
                       <div className="flex justify-between text-sm"><span className="font-medium text-slate-500">Transport & Logistics</span><span className="font-black">₹8,40,000</span></div>
                       <div className="flex justify-between text-sm"><span className="font-medium text-slate-500">Grant & Donations</span><span className="font-black">₹2,50,000</span></div>
                    </div>
                    <div className="space-y-4">
                       <p className="text-[10px] font-black text-amber-600 uppercase tracking-widest border-b border-amber-50 pb-2">Operating Expenses</p>
                       <div className="flex justify-between text-sm"><span className="font-medium text-slate-500">Staff Payroll (Salaries)</span><span className="font-black">₹48,20,000</span></div>
                       <div className="flex justify-between text-sm"><span className="font-medium text-slate-500">Facility Maintenance</span><span className="font-black">₹6,40,000</span></div>
                       <div className="flex justify-between text-sm"><span className="font-medium text-slate-500">Inventory Procurement</span><span className="font-black">₹3,50,000</span></div>
                    </div>
                    <div className="p-6 bg-slate-900 rounded-[2rem] text-white flex justify-between items-center shadow-xl">
                       <div><p className="text-[10px] font-black text-indigo-300 uppercase tracking-widest">Net Surplus</p><h4 className="text-3xl font-black mt-1">₹37,00,000</h4></div>
                       <TrendingUp className="text-emerald-400" size={40} />
                    </div>
                 </div>
              </div>
           </div>
        </div>
      )}

      {activeTab === 'inventory' && (
        <div className="space-y-10 animate-in fade-in duration-300">
           <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
              <div className="lg:col-span-2 bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
                 <h3 className="text-2xl font-black text-slate-900 mb-8 flex items-center gap-3"><Package className="text-indigo-600"/> Asset Value Distribution</h3>
                 <div className="h-[400px]">
                    <ResponsiveContainer width="100%" height="100%">
                       <PieChart>
                          <Pie data={inventoryAllocation} cx="50%" cy="50%" innerRadius={80} outerRadius={120} paddingAngle={10} dataKey="value">
                             {inventoryAllocation.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.color} />)}
                          </Pie>
                          <Tooltip formatter={(value: number) => `₹${value.toLocaleString()}`} />
                       </PieChart>
                    </ResponsiveContainer>
                 </div>
                 <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-8">
                    {inventoryAllocation.map(item => (
                       <div key={item.name} className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                          <div className="flex items-center gap-2 mb-2"><div className="w-2 h-2 rounded-full" style={{backgroundColor: item.color}}></div><span className="text-[10px] font-black text-slate-400 uppercase">{item.name}</span></div>
                          <p className="text-sm font-black text-slate-900">₹{(item.value / 100000).toFixed(1)}L</p>
                       </div>
                    ))}
                 </div>
              </div>

              <div className="space-y-6">
                 <div className="bg-indigo-600 p-10 rounded-[3rem] text-white shadow-2xl shadow-indigo-500/30">
                    <h4 className="text-xl font-black mb-4">Stock Compliance</h4>
                    <p className="text-sm text-indigo-100 leading-relaxed font-medium mb-8">92% of institutional inventory is categorized as active. 8% of assets are pending maintenance or disposal audit.</p>
                    <button className="w-full py-4 bg-white text-indigo-600 rounded-[1.5rem] font-black text-xs uppercase tracking-widest">Audit Full Registry</button>
                 </div>
                 <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm flex-1 flex flex-col justify-between">
                    <div>
                       <h4 className="font-black text-slate-900 mb-6 flex items-center gap-2"><IndianRupee size={18} className="text-indigo-600"/> Equity Ratio</h4>
                       <div className="space-y-6">
                          <div className="flex justify-between items-center"><span className="text-xs font-bold text-slate-500">Asset/Student Ratio</span><span className="font-black text-indigo-600">₹2,240</span></div>
                          <div className="flex justify-between items-center"><span className="text-xs font-bold text-slate-500">Annual Dep. Rate</span><span className="font-black text-rose-500">12.5%</span></div>
                       </div>
                    </div>
                 </div>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default FinanceHub;