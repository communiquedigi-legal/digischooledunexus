import React, { useState } from 'react';
import { 
  Bus, MapPin, Navigation, UserCheck, Shield, Plus, 
  X, Save, Trash2, ShieldCheck, UserPlus, FileText, Upload, 
  Settings, Info, Camera, Map as MapIcon,
  ArrowRight, Gauge, Edit3, Smartphone, Wallet
} from 'lucide-react';

interface TransportStaff {
  id: string;
  name: string;
  role: 'Driver' | 'Conductor';
  phone: string;
  licenseNo?: string;
  experience: string;
  status: 'Active' | 'On Leave';
  photo: string;
  documents: {
    license?: string;
    idCard?: string;
  };
}

interface BusVehicle {
  id: string;
  regNo: string;
  model: string;
  capacity: number;
  status: 'Operational' | 'Maintenance';
}

interface Route {
  id: string;
  name: string;
  distance: number; // in KM
  busId: string;
  driverId: string;
  conductorId: string;
  stops: string[];
}

const TransportManagement: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'routes' | 'fleet' | 'staff' | 'fees'>('routes');
  
  const [fleet, setFleet] = useState<BusVehicle[]>([
    { id: 'BUS-01', regNo: 'DL 12 AT 4501', model: 'Tata Starbus 2022', capacity: 50, status: 'Operational' },
    { id: 'BUS-02', regNo: 'DL 12 AT 4502', model: 'Ashok Leyland 2021', capacity: 42, status: 'Operational' },
  ]);

  const [staff, setStaff] = useState<TransportStaff[]>([
    { id: 'ST-001', name: 'Karan Singh', role: 'Driver', phone: '9876543210', licenseNo: 'DL-552021004', experience: '12 Yrs', status: 'Active', photo: 'https://picsum.photos/seed/d1/200', documents: { license: 'verified' } },
    { id: 'ST-002', name: 'Rahul Verma', role: 'Driver', phone: '9876543211', licenseNo: 'DL-552021005', experience: '8 Yrs', status: 'Active', photo: 'https://picsum.photos/seed/d2/200', documents: { license: 'verified' } },
    { id: 'ST-003', name: 'Amit Kumar', role: 'Conductor', phone: '9876543212', experience: '5 Yrs', status: 'Active', photo: 'https://picsum.photos/seed/c1/200', documents: {} },
  ]);

  const [routes, setRoutes] = useState<Route[]>([
    { id: 'RT-01', name: 'North City - Sector A', distance: 12, busId: 'BUS-01', driverId: 'ST-001', conductorId: 'ST-003', stops: ['Main Gate', 'Clock Tower', 'Sector A Market'] },
    { id: 'RT-02', name: 'West Campus - Block 10', distance: 18.5, busId: 'BUS-02', driverId: 'ST-002', conductorId: 'ST-003', stops: ['West Mall', 'Police Station', 'Block 10 Park'] },
  ]);

  const [feeConfig, setFeeConfig] = useState({
    baseRate: 500,
    ratePerKm: 150
  });

  const [showAddModal, setShowAddModal] = useState<any>(null);

  const calculateFee = (distance: number) => {
    return feeConfig.baseRate + (distance * feeConfig.ratePerKm);
  };

  const handleAddStaff = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const newStaff: TransportStaff = {
      id: `ST-${Date.now().toString().slice(-3)}`,
      name: formData.get('name') as string,
      role: formData.get('role') as any,
      phone: formData.get('phone') as string,
      licenseNo: formData.get('license') as string,
      experience: formData.get('exp') as string,
      status: 'Active',
      photo: `https://picsum.photos/seed/${Math.random()}/200`,
      documents: {
        license: 'uploaded',
        idCard: 'uploaded'
      }
    };
    setStaff([...staff, newStaff]);
    setShowAddModal(null);
  };

  const handleAddBus = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const newBus: BusVehicle = {
      id: `BUS-${(fleet.length + 1).toString().padStart(2, '0')}`,
      regNo: formData.get('regNo') as string,
      model: formData.get('model') as string,
      capacity: parseInt(formData.get('capacity') as string),
      status: 'Operational'
    };
    setFleet([...fleet, newBus]);
    setShowAddModal(null);
  };

  const handleAddRoute = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const newRoute: Route = {
      id: `RT-${(routes.length + 1).toString().padStart(2, '0')}`,
      name: formData.get('name') as string,
      distance: parseFloat(formData.get('distance') as string),
      busId: formData.get('busId') as string,
      driverId: formData.get('driverId') as string,
      conductorId: formData.get('conductorId') as string,
      stops: (formData.get('stops') as string).split(',').map(s => s.trim())
    };
    setRoutes([...routes, newRoute]);
    setShowAddModal(null);
  };

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4 no-print">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Transport & Logistics</h1>
          <p className="text-slate-500">Route optimization, fleet monitoring, and staff management.</p>
        </div>
        <div className="flex bg-white p-1 rounded-2xl border border-slate-200 shadow-sm overflow-x-auto">
          {[
            { id: 'routes', label: 'Route Map', icon: <MapIcon size={16} /> },
            { id: 'fleet', label: 'Fleet Inventory', icon: <Bus size={16} /> },
            { id: 'staff', label: 'Crew (Driver/Cond.)', icon: <UserCheck size={16} /> },
            { id: 'fees', label: 'Fee Engine', icon: <Settings size={16} /> },
          ].map(tab => (
            <button 
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-6 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 whitespace-nowrap ${activeTab === tab.id ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}
            >
              {tab.icon} {tab.label}
            </button>
          ))}
        </div>
      </div>

      {activeTab === 'routes' && (
        <div className="space-y-8 animate-in fade-in duration-300">
          <div className="flex justify-between items-center bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm">
             <div>
                <h3 className="text-xl font-black text-slate-900">Assigned Transport Routes</h3>
                <p className="text-sm font-medium text-slate-400">Manage paths and real-time fee calculations based on distance.</p>
             </div>
             <button onClick={() => setShowAddModal('route')} className="px-6 py-3 bg-indigo-600 text-white rounded-2xl text-sm font-black flex items-center gap-2 hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-500/20">
               <Plus size={20} /> Deploy New Route
             </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {routes.map(route => {
              const assignedBus = fleet.find(b => b.id === route.busId);
              const assignedDriver = staff.find(s => s.id === route.driverId);
              const assignedConductor = staff.find(s => s.id === route.conductorId);
              const routeFee = calculateFee(route.distance);

              return (
                <div key={route.id} className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm hover:shadow-2xl hover:scale-[1.01] transition-all group relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-50 rounded-bl-[4rem] -translate-y-4 translate-x-4 flex items-center justify-center">
                    <Navigation className="text-indigo-200" size={48} />
                  </div>
                  
                  <div className="flex justify-between items-start mb-8">
                    <div>
                      <span className="text-[10px] font-black bg-indigo-50 text-indigo-600 px-3 py-1.5 rounded-xl uppercase tracking-widest">{route.id}</span>
                      <h3 className="text-2xl font-black text-slate-900 mt-3">{route.name}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <Gauge size={14} className="text-slate-400" />
                        <span className="text-xs font-bold text-slate-400">Logistics Distance: {route.distance} KM</span>
                      </div>
                    </div>
                    <div className="text-right">
                       <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Monthly Travel Fee</p>
                       <p className="text-2xl font-black text-emerald-600">₹{routeFee.toLocaleString()}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8 pt-6 border-t border-slate-50">
                     <div className="space-y-1">
                        <p className="text-[9px] font-black text-slate-400 uppercase tracking-tighter">Vehicle Reg.</p>
                        <p className="text-xs font-black text-slate-800">{assignedBus?.regNo}</p>
                     </div>
                     <div className="space-y-1">
                        <p className="text-[9px] font-black text-slate-400 uppercase tracking-tighter">Assigned Driver</p>
                        <p className="text-xs font-black text-slate-800">{assignedDriver?.name}</p>
                     </div>
                     <div className="space-y-1">
                        <p className="text-[9px] font-black text-slate-400 uppercase tracking-tighter">Conductor</p>
                        <p className="text-xs font-black text-slate-800">{assignedConductor?.name || 'Unassigned'}</p>
                     </div>
                  </div>

                  <div className="space-y-4">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Route Progression (Stops)</p>
                    <div className="flex flex-wrap gap-2">
                       {route.stops.map((stop, idx) => (
                         <div key={idx} className="flex items-center gap-2">
                           <span className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-[10px] font-black text-slate-600">{stop}</span>
                           {idx < route.stops.length - 1 && <ArrowRight size={12} className="text-slate-300" />}
                         </div>
                       ))}
                    </div>
                  </div>

                  <div className="mt-8 pt-8 border-t border-slate-50 flex justify-between items-center">
                    <button className="flex items-center gap-2 text-xs font-black text-indigo-600 hover:bg-indigo-50 px-4 py-2 rounded-xl transition-all">
                      <Smartphone size={14}/> Track Live Location
                    </button>
                    <div className="flex gap-2">
                      <button className="p-3 bg-slate-50 text-slate-400 hover:text-indigo-600 rounded-xl transition-all"><Edit3 size={18}/></button>
                      <button className="p-3 bg-slate-50 text-slate-400 hover:text-rose-600 rounded-xl transition-all"><Trash2 size={18}/></button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {activeTab === 'fleet' && (
        <div className="space-y-8 animate-in fade-in duration-300">
           <div className="flex justify-between items-center bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm">
             <div>
                <h3 className="text-xl font-black text-slate-900">Vehicle Inventory</h3>
                <p className="text-sm font-medium text-slate-400">Maintain records of school-owned buses and their maintenance status.</p>
             </div>
             <button onClick={() => setShowAddModal('bus')} className="px-6 py-3 bg-slate-900 text-white rounded-2xl text-sm font-black flex items-center gap-2 hover:bg-indigo-600 transition-all shadow-xl">
               <Plus size={20} /> Register Bus
             </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {fleet.map(bus => (
              <div key={bus.id} className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-xl transition-all group">
                 <div className="flex justify-between items-start mb-8">
                    <div className="p-5 bg-indigo-50 text-indigo-600 rounded-[1.5rem] group-hover:bg-indigo-600 group-hover:text-white transition-all"><Bus size={32} /></div>
                    <span className={`text-[10px] font-black px-3 py-1.5 rounded-xl uppercase tracking-widest ${bus.status === 'Operational' ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
                      {bus.status}
                    </span>
                 </div>
                 <h4 className="text-2xl font-black text-slate-900 leading-tight">{bus.regNo}</h4>
                 <p className="text-xs font-bold text-slate-400 uppercase mt-1">{bus.model}</p>
                 
                 <div className="mt-8 grid grid-cols-2 gap-4">
                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                       <p className="text-[10px] font-black text-slate-400 uppercase mb-1">Max Capacity</p>
                       <p className="text-lg font-black text-slate-900">{bus.capacity} Seats</p>
                    </div>
                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                       <p className="text-[10px] font-black text-slate-400 uppercase mb-1">Last Service</p>
                       <p className="text-xs font-black text-slate-600">2 Months ago</p>
                    </div>
                 </div>

                 <div className="mt-6 pt-6 border-t border-slate-50 flex gap-2">
                    <button className="flex-1 py-3 bg-slate-900 text-white text-xs font-black rounded-xl shadow-lg shadow-slate-900/10">Maintenance Log</button>
                    <button className="px-4 py-3 bg-slate-50 text-slate-400 rounded-xl hover:text-rose-600 transition-colors"><Trash2 size={18}/></button>
                 </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'staff' && (
        <div className="space-y-8 animate-in fade-in duration-300">
          <div className="flex justify-between items-center bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm">
             <div>
                <h3 className="text-xl font-black text-slate-900">Transport Crew Directory</h3>
                <p className="text-sm font-medium text-slate-400">Manage Drivers and Conductors with verified credentials.</p>
             </div>
             <button onClick={() => setShowAddModal('staff')} className="px-6 py-3 bg-indigo-600 text-white rounded-2xl text-sm font-black flex items-center gap-2 hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-500/20">
               <UserPlus size={20} /> Add New Crew Member
             </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {staff.map(member => (
              <div key={member.id} className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-2xl transition-all group">
                <div className="flex gap-5 mb-8">
                   <img src={member.photo} className="w-24 h-24 rounded-3xl object-cover border-4 border-slate-50 shadow-inner group-hover:border-indigo-100 transition-colors" alt="" />
                   <div className="flex flex-col justify-center">
                      <span className={`text-[8px] font-black px-2 py-1 rounded-lg uppercase w-fit mb-2 ${member.role === 'Driver' ? 'bg-indigo-50 text-indigo-600' : 'bg-emerald-50 text-emerald-600'}`}>
                        {member.role}
                      </span>
                      <h4 className="text-xl font-black text-slate-900 leading-tight">{member.name}</h4>
                      <p className="text-[10px] text-slate-400 font-bold uppercase mt-1">ID: {member.id}</p>
                   </div>
                </div>

                <div className="space-y-4">
                   <div className="flex justify-between items-center text-sm font-medium">
                      <span className="text-slate-400">Experience</span>
                      <span className="text-slate-900 font-black">{member.experience}</span>
                   </div>
                   <div className="flex justify-between items-center text-sm font-medium">
                      <span className="text-slate-400">Phone</span>
                      <span className="text-slate-900 font-black">{member.phone}</span>
                   </div>
                   {member.licenseNo && (
                     <div className="p-4 bg-slate-50 border border-slate-100 rounded-2xl flex items-center justify-between">
                        <div className="flex items-center gap-3">
                           <ShieldCheck size={20} className="text-emerald-500" />
                           <div className="text-left">
                              <p className="text-[9px] font-black text-slate-400 uppercase">License Verified</p>
                              <p className="text-xs font-black text-slate-900">{member.licenseNo}</p>
                           </div>
                        </div>
                        <FileText size={18} className="text-slate-300 hover:text-indigo-600 cursor-pointer transition-colors" />
                     </div>
                   )}
                </div>

                <div className="mt-8 pt-8 border-t border-slate-50 grid grid-cols-2 gap-4">
                   <button className="py-3 text-xs font-black bg-slate-900 text-white rounded-xl shadow-lg shadow-slate-900/20">Staff ID Card</button>
                   <button className="py-3 text-xs font-black border-2 border-slate-100 rounded-xl text-slate-500 hover:bg-slate-50">Personnel File</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'fees' && (
        <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-300">
           <div className="bg-white p-12 rounded-[3rem] border border-slate-100 shadow-sm relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-50 rounded-full blur-3xl -translate-y-32 translate-x-32"></div>
              <h3 className="text-3xl font-black text-slate-900 mb-8 flex items-center gap-4">
                <Settings className="text-indigo-600" size={32}/> Fee Calculation Logic
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                 <div className="space-y-6">
                    <div className="space-y-2">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Base Subscription Fee (₹)</label>
                       <div className="relative">
                          <Wallet className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                          <input 
                            type="number" 
                            value={feeConfig.baseRate}
                            onChange={(e) => setFeeConfig({...feeConfig, baseRate: parseInt(e.target.value) || 0})}
                            className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-black text-lg outline-none focus:bg-white focus:border-indigo-500 transition-all" 
                          />
                       </div>
                    </div>

                    <div className="space-y-2">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Rate Per KM Travelled (₹)</label>
                       <div className="relative">
                          <Navigation className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                          <input 
                            type="number" 
                            value={feeConfig.ratePerKm}
                            onChange={(e) => setFeeConfig({...feeConfig, ratePerKm: parseInt(e.target.value) || 0})}
                            className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-black text-lg outline-none focus:bg-white focus:border-indigo-500 transition-all" 
                          />
                       </div>
                    </div>
                 </div>

                 <div className="p-8 bg-slate-900 rounded-[2.5rem] text-white flex flex-col justify-between shadow-2xl relative">
                    <div>
                       <h4 className="text-xl font-black mb-4 flex items-center gap-2">Calculation Model</h4>
                       <p className="text-sm text-slate-400 leading-relaxed font-medium mb-6">Fee = Base + (Distance × KM Rate)</p>
                       <div className="space-y-4">
                          <div className="flex justify-between text-sm">
                             <span className="text-slate-500">Fixed Cost</span>
                             <span className="font-mono">₹{feeConfig.baseRate}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                             <span className="text-slate-500">Variable (10 KM)</span>
                             <span className="font-mono">₹{10 * feeConfig.ratePerKm}</span>
                          </div>
                          <div className="pt-4 border-t border-white/10 flex justify-between">
                             <span className="font-black text-indigo-400 uppercase text-xs">Total for 10KM</span>
                             <span className="text-2xl font-black text-white">₹{feeConfig.baseRate + (10 * feeConfig.ratePerKm)}</span>
                          </div>
                       </div>
                    </div>
                    <button className="mt-10 w-full py-4 bg-indigo-600 text-white rounded-2xl font-black text-xs hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-500/20">Apply Global Rule</button>
                 </div>
              </div>
           </div>
        </div>
      )}

      {showAddModal === 'staff' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-md p-4 no-print animate-in fade-in">
          <div className="bg-white rounded-[3rem] p-10 max-w-xl w-full shadow-2xl relative overflow-hidden">
             <div className="absolute top-0 left-0 w-3 h-full bg-indigo-600"></div>
             <div className="flex justify-between items-center mb-10">
                <h3 className="text-3xl font-black text-slate-900">Onboard Crew Member</h3>
                <button onClick={() => setShowAddModal(null)} className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-400"><X size={24}/></button>
             </div>
             <form onSubmit={handleAddStaff} className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                   <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Legal Name</label>
                      <input name="name" required className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl font-black outline-none focus:border-indigo-500" />
                   </div>
                   <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Designation</label>
                      <select name="role" required className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl font-black outline-none">
                        <option value="Driver">Bus Driver</option>
                        <option value="Conductor">Bus Conductor</option>
                      </select>
                   </div>
                   <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Mobile Number</label>
                      <input name="phone" required className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl font-black outline-none" />
                   </div>
                   <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Experience (Years)</label>
                      <input name="exp" required className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl font-black outline-none" />
                   </div>
                </div>
                <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Commercial License Number</label>
                   <input name="license" className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl font-black outline-none" placeholder="Required for Driver role..." />
                </div>
                
                <div className="pt-6 border-t border-slate-100 grid grid-cols-2 gap-4">
                   <div className="space-y-2 text-center">
                      <label className="text-[9px] font-black text-slate-400 uppercase">Profile Photo</label>
                      <div className="aspect-square bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl flex flex-col items-center justify-center gap-2 text-slate-400 hover:border-indigo-500 hover:text-indigo-600 transition-all cursor-pointer relative">
                         <Camera size={24}/>
                         <span className="text-[9px] font-black uppercase">Upload</span>
                      </div>
                   </div>
                   <div className="space-y-2 text-center">
                      <label className="text-[9px] font-black text-slate-400 uppercase">Documents</label>
                      <div className="aspect-square bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl flex flex-col items-center justify-center gap-2 text-slate-400 hover:border-indigo-500 hover:text-indigo-600 transition-all cursor-pointer relative">
                         <Upload size={24}/>
                         <span className="text-[9px] font-black uppercase">Attach</span>
                      </div>
                   </div>
                </div>

                <button type="submit" className="w-full py-5 bg-indigo-600 text-white rounded-[2rem] font-black text-lg shadow-2xl shadow-indigo-500/30">Complete Personnel Entry</button>
             </form>
          </div>
        </div>
      )}

      {showAddModal === 'bus' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-md p-4 no-print animate-in fade-in">
          <div className="bg-white rounded-[3rem] p-10 max-w-md w-full shadow-2xl">
             <div className="flex justify-between items-center mb-8">
                <h3 className="text-2xl font-black text-slate-900">Vehicle Registration</h3>
                <button onClick={() => setShowAddModal(null)} className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-400"><X size={24}/></button>
             </div>
             <form onSubmit={handleAddBus} className="space-y-6">
                <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Plate Number (Reg No.)</label>
                   <input name="regNo" required className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl font-black outline-none focus:border-indigo-500" placeholder="DL XX AT XXXX" />
                </div>
                <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Make & Model</label>
                   <input name="model" required className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl font-black outline-none focus:border-indigo-500" />
                </div>
                <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Passenger Capacity</label>
                   <input name="capacity" type="number" required className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl font-black outline-none focus:border-indigo-500" />
                </div>
                <button type="submit" className="w-full py-5 bg-slate-900 text-white rounded-[2rem] font-black text-lg shadow-2xl">Register Vehicle</button>
             </form>
          </div>
        </div>
      )}

      {showAddModal === 'route' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-md p-4 no-print animate-in fade-in">
          <div className="bg-white rounded-[3rem] p-10 max-w-2xl w-full shadow-2xl relative overflow-hidden">
             <div className="flex justify-between items-center mb-10">
                <h3 className="text-3xl font-black text-slate-900">Configure Transport Route</h3>
                <button onClick={() => setShowAddModal(null)} className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-400"><X size={24}/></button>
             </div>
             <form onSubmit={handleAddRoute} className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                   <div className="space-y-6">
                      <div className="space-y-2">
                         <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Route Label</label>
                         <input name="name" required className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl font-black outline-none focus:border-indigo-500" placeholder="e.g. South End Express" />
                      </div>
                      <div className="space-y-2">
                         <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">One-Way Distance (KM)</label>
                         <input name="distance" type="number" step="0.1" required className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl font-black outline-none focus:border-indigo-500" />
                      </div>
                      <div className="space-y-2">
                         <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Stops (Comma separated)</label>
                         <textarea name="stops" required className="w-full h-24 p-4 bg-slate-50 border border-slate-200 rounded-2xl font-black outline-none resize-none focus:border-indigo-500" placeholder="Gate 1, Metro St, Square Mall..."></textarea>
                      </div>
                   </div>
                   
                   <div className="space-y-6">
                      <div className="space-y-2">
                         <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Designated Vehicle</label>
                         <select name="busId" required className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl font-black outline-none">
                            {fleet.map(b => <option key={b.id} value={b.id}>{b.regNo} ({b.model})</option>)}
                         </select>
                      </div>
                      <div className="space-y-2">
                         <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Driver Assignment</label>
                         <select name="driverId" required className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl font-black outline-none">
                            {staff.filter(s => s.role === 'Driver').map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                         </select>
                      </div>
                      <div className="space-y-2">
                         <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Conductor Assignment</label>
                         <select name="conductorId" className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl font-black outline-none">
                            <option value="">None / Unassigned</option>
                            {staff.filter(s => s.role === 'Conductor').map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                         </select>
                      </div>
                   </div>
                </div>
                <button type="submit" className="w-full py-5 bg-indigo-600 text-white rounded-[2rem] font-black text-lg shadow-2xl shadow-indigo-500/30">Deploy Logistics Route</button>
             </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default TransportManagement;