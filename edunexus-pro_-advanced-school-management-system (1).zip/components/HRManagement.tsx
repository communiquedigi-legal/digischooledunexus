
import React, { useState, useMemo, useEffect } from 'react';
import { EmploymentCategory, Staff, SalaryStructure, LeaveType, LeaveStatus, LeaveRequest } from '../types';
import { supabase } from '../lib/supabase';
import { 
  Wallet, Users, Receipt, Calculator, Percent, ShieldCheck, ChevronDown, Plus, 
  MoreVertical, ShieldAlert, Save, Edit3, X, Camera, Upload, Briefcase, 
  CheckCircle2, Printer, Eye, TrendingUp, Landmark, Phone, Mail, MapPin, 
  FileText, User, UserPlus, FileCheck, Heart, Search, Filter, 
  CreditCard, Activity, GraduationCap, Building2, Smartphone, 
  Trash2, Info, ArrowUpRight, ArrowDownRight, DollarSign, Lock, Shield, Loader2,
  FileBadge, FileSignature, ArrowRight, ArrowLeft, DownloadCloud, QrCode,
  BadgePercent, Coins, UserCheck, Scale, Settings2, AlertTriangle, ChevronRight,
  IndianRupee, CalendarCheck, CalendarX, Clock4, FileQuestion
} from 'lucide-react';

const HRManagement: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'directory' | 'payroll' | 'leave' | 'compliance' | 'add_staff'>('directory');
  const [formStep, setFormStep] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState('All');
  const [staffList, setStaffList] = useState<Staff[]>([]);
  const [leaveRequests, setLeaveRequests] = useState<LeaveRequest[]>([
    { id: 'LR1', staffId: 'ST1001', staffName: 'Priya Verma', type: LeaveType.CASUAL, startDate: '2025-05-10', endDate: '2025-05-12', reason: 'Family Function', status: LeaveStatus.PENDING, appliedAt: '2025-05-01' },
    { id: 'LR2', staffId: 'ST1002', staffName: 'Amit Gupta', type: LeaveType.SICK, startDate: '2025-05-15', endDate: '2025-05-16', reason: 'Fever', status: LeaveStatus.APPROVED, appliedAt: '2025-05-10' },
  ]);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showApplyLeave, setShowApplyLeave] = useState(false);

  // Global Compliance State (Editable by Admin)
  const [complianceConfig, setComplianceConfig] = useState({
    pf_rate: 12.0,
    pf_threshold: 15000,
    esi_emp_rate: 0.75,
    esi_empr_rate: 3.25,
    esi_gross_limit: 21000,
    pt_standard: 200,
    gratuity_rate: 4.81, // 15/26 days per year
    lwf_amount: 10
  });

  const [selectedStaff, setSelectedStaff] = useState<Staff | null>(null);
  const [modalMode, setModalMode] = useState<'profile' | 'payslip' | null>(null);

  useEffect(() => { fetchStaff(); }, []);

  const fetchStaff = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.from('staff').select('*').order('name');
      if (error) throw error;
      setStaffList(data || []);
    } catch (err) { console.error(err); } finally { setLoading(false); }
  };

  const calculateFullSalary = (basic: number, category: EmploymentCategory, extras: any = {}): SalaryStructure => {
    const da = Math.round(basic * 0.15); 
    const hra = Math.round(basic * 0.40); 
    const conveyance = category === EmploymentCategory.REGULAR ? 1600 : 800;
    const medical = category === EmploymentCategory.REGULAR ? 1250 : 0;
    const special = extras.special || 5000;
    const incentive = extras.incentive || 0;
    const bonus = category === EmploymentCategory.REGULAR ? Math.round(basic * 0.0833) : 0;

    const gross = basic + da + hra + conveyance + medical + special + incentive + bonus;

    const pf_wage = Math.min(basic + da, complianceConfig.pf_threshold);
    const pf_emp = category === EmploymentCategory.CONTRACT ? 0 : Math.round(pf_wage * (complianceConfig.pf_rate / 100));
    const pf_empr = pf_emp;

    const isEsi = gross <= complianceConfig.esi_gross_limit;
    const esi_emp = isEsi ? Math.ceil(gross * (complianceConfig.esi_emp_rate / 100)) : 0;
    const esi_empr = isEsi ? Math.ceil(gross * (complianceConfig.esi_empr_rate / 100)) : 0;

    const pt = gross > 15000 ? complianceConfig.pt_standard : 0;
    const lwf = category === EmploymentCategory.REGULAR ? complianceConfig.lwf_amount : 0;

    const gratuity = category === EmploymentCategory.REGULAR ? Math.round((basic + da) * (complianceConfig.gratuity_rate / 100)) : 0;
    const insurance = category === EmploymentCategory.REGULAR ? 500 : 0;

    const net = gross - (pf_emp + esi_emp + pt + lwf + (extras.tds || 0));
    const ctc = gross + pf_empr + esi_empr + gratuity + insurance;

    return {
      category,
      earnings: { basic, da, hra, conveyance, medical, special, incentive, bonus_statutory: bonus, ex_gratia: 0 },
      deductions: { pf_emp, pf_empr, esi_emp, esi_empr, pt, tds: extras.tds || 0, loan_recovery: 0, lwf },
      provisions: { gratuity, insurance },
      gross, net, ctc
    };
  };

  const handleOnboarding = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    const fd = new FormData(e.currentTarget);
    
    const basic = Number(fd.get('basicPay'));
    const category = fd.get('employmentType') as EmploymentCategory;
    const salary = calculateFullSalary(basic, category);

    const record = {
      id: (fd.get('empId') as string) || `ST${Date.now().toString().slice(-4)}`,
      name: fd.get('fullName'),
      designation: fd.get('designation'),
      department: fd.get('department'),
      employment_type: category,
      doj: fd.get('doj'),
      email: fd.get('email'),
      phone: fd.get('phone'),
      bank_name: fd.get('bankName'),
      bank_account_number: fd.get('accountNumber'),
      bank_ifsc: fd.get('ifsc'),
      salary,
      photo_url: `https://picsum.photos/seed/${fd.get('fullName')}/200`,
      role: fd.get('roleCategory') === 'Teaching Staff' ? 'TEACHER' : 'STAFF',
    };

    try {
      const { error } = await supabase.from('staff').insert([record]);
      if (error) throw error;
      alert('Node Deployed: Employee Integrated with Statutory Ledger.');
      fetchStaff();
      setActiveTab('directory');
    } catch (err: any) { alert(err.message); } finally { setIsSubmitting(false); }
  };

  const handleLeaveAction = (id: string, action: LeaveStatus) => {
    setLeaveRequests(prev => prev.map(req => req.id === id ? { ...req, status: action } : req));
  };

  const handleApplyLeaveSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const newReq: LeaveRequest = {
      id: `LR${Date.now()}`,
      staffId: fd.get('staffId') as string,
      staffName: staffList.find(s => s.id === fd.get('staffId'))?.name || 'Unknown',
      type: fd.get('type') as LeaveType,
      startDate: fd.get('start') as string,
      endDate: fd.get('end') as string,
      reason: fd.get('reason') as string,
      status: LeaveStatus.PENDING,
      appliedAt: new Date().toISOString().split('T')[0]
    };
    setLeaveRequests([newReq, ...leaveRequests]);
    setShowApplyLeave(false);
  };

  const amountToWords = (price: number) => {
    const s_number = price.toString();
    const split = s_number.split('.');
    const amt = split[0];
    return "Rupees " + Number(amt).toLocaleString('en-IN') + " Only";
  };

  const filteredStaff = useMemo(() => staffList.filter(s => 
    s.name?.toLowerCase().includes(searchQuery.toLowerCase()) || s.id?.toLowerCase().includes(searchQuery.toLowerCase())
  ), [staffList, searchQuery]);

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-7xl mx-auto min-h-screen relative pb-24">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-6 no-print">
        <div>
          <h1 className="text-3xl md:text-5xl font-black text-slate-900 italic uppercase tracking-tighter leading-none">Human Capital Node</h1>
          <p className="text-slate-500 font-medium uppercase text-[10px] tracking-widest mt-1">Institutional Workforce & Statutory Engine</p>
        </div>
        <div className="flex bg-white p-1.5 rounded-[2rem] border border-slate-200 shadow-sm overflow-x-auto scrollbar-hide">
          <button onClick={() => setActiveTab('directory')} className={`px-6 py-3 rounded-[1.5rem] text-[10px] font-black transition-all uppercase tracking-widest ${activeTab === 'directory' ? 'bg-slate-900 text-white shadow-xl' : 'text-slate-400 hover:bg-slate-50'}`}>Directory</button>
          <button onClick={() => setActiveTab('payroll')} className={`px-6 py-3 rounded-[1.5rem] text-[10px] font-black transition-all uppercase tracking-widest ${activeTab === 'payroll' ? 'bg-indigo-600 text-white shadow-xl' : 'text-slate-400 hover:bg-slate-50'}`}>Payroll Hub</button>
          <button onClick={() => setActiveTab('leave')} className={`px-6 py-3 rounded-[1.5rem] text-[10px] font-black transition-all uppercase tracking-widest ${activeTab === 'leave' ? 'bg-rose-600 text-white shadow-xl' : 'text-slate-400 hover:bg-slate-50'}`}>Leave Matrix</button>
          <button onClick={() => setActiveTab('compliance')} className={`px-6 py-3 rounded-[1.5rem] text-[10px] font-black transition-all uppercase tracking-widest ${activeTab === 'compliance' ? 'bg-amber-50 text-white shadow-xl' : 'text-slate-400 hover:bg-slate-50'}`}>Compliance Master</button>
          <button onClick={() => { setFormStep(1); setActiveTab('add_staff'); }} className={`px-6 py-3 rounded-[1.5rem] text-[10px] font-black transition-all uppercase tracking-widest ${activeTab === 'add_staff' ? 'bg-emerald-600 text-white shadow-xl' : 'text-slate-400 hover:bg-slate-50'}`}>Recruitment</button>
        </div>
      </div>

      {activeTab === 'directory' && (
        <div className="space-y-8 animate-in fade-in">
           <div className="flex flex-col lg:flex-row justify-between items-center bg-white p-6 rounded-[3rem] border border-slate-100 shadow-sm gap-6 no-print">
              <div className="flex-1 relative w-full group">
                 <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-600 transition-colors" size={24} />
                 <input 
                  type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} 
                  placeholder="Query Personnel by UID or Identity..." 
                  className="w-full pl-16 pr-8 py-5 bg-slate-50 border-2 border-transparent focus:bg-white focus:border-indigo-500 rounded-[2.5rem] text-sm outline-none transition-all font-black shadow-inner" 
                 />
              </div>
              <button onClick={() => setActiveTab('add_staff')} className="px-10 py-5 bg-indigo-600 text-white rounded-[2rem] font-black text-xs uppercase tracking-widest flex items-center justify-center gap-3 shadow-2xl hover:scale-105 transition-all">
                <UserPlus size={20} /> Deploy New Node
              </button>
           </div>

           <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredStaff.map(staff => (
                <div key={staff.id} className="bg-white p-8 rounded-[3.5rem] border border-slate-100 hover:shadow-2xl transition-all group relative overflow-hidden">
                   <div className="absolute top-0 right-0 p-8 opacity-5 rotate-12 group-hover:scale-110 transition-transform"><GraduationCap size={100}/></div>
                   <div className="flex items-center gap-6 relative z-10">
                      <img src={staff.photo_url} className="w-20 h-20 rounded-[2.5rem] object-cover border-4 border-white shadow-lg" alt="" />
                      <div>
                        <h4 className="text-xl font-black text-slate-900 leading-tight truncate max-w-[160px]">{staff.name}</h4>
                        <p className="text-[10px] font-black text-indigo-600 uppercase tracking-widest mt-1.5">{staff.designation}</p>
                        <span className={`mt-2 inline-block px-3 py-1 rounded-full text-[8px] font-black uppercase ${
                            staff.employment_type === EmploymentCategory.REGULAR ? 'bg-emerald-50 text-emerald-600' :
                            staff.employment_type === EmploymentCategory.TEMPORARY ? 'bg-amber-50 text-amber-600' : 'bg-rose-50 text-rose-600'
                        }`}>{staff.employment_type}</span>
                      </div>
                   </div>
                   <div className="mt-8 pt-8 border-t border-slate-50 grid grid-cols-2 gap-4">
                      <button onClick={() => { setSelectedStaff(staff); setModalMode('profile'); }} className="py-3 bg-slate-50 text-[10px] font-black uppercase text-slate-400 rounded-2xl hover:bg-slate-100">View Node</button>
                      <button onClick={() => { setSelectedStaff(staff); setModalMode('payslip'); }} className="py-3 bg-indigo-50 text-[10px] font-black uppercase text-indigo-600 rounded-2xl hover:bg-indigo-600 hover:text-white transition-all flex items-center justify-center gap-2"><CreditCard size={14}/> Payslip</button>
                   </div>
                </div>
              ))}
              {filteredStaff.length === 0 && (
                <div className="col-span-full py-20 text-center bg-white rounded-[3rem] border-2 border-dashed border-slate-100">
                   <Users size={48} className="mx-auto text-slate-200 mb-4" />
                   <p className="text-sm font-black text-slate-300 uppercase italic">No Registered Nodes in Current Ledger</p>
                </div>
              )}
           </div>
        </div>
      )}

      {activeTab === 'payroll' && (
        <div className="space-y-10 animate-in fade-in">
           <div className="bg-slate-900 p-10 md:p-16 rounded-[4rem] text-white flex flex-col lg:flex-row justify-between items-center gap-12 relative overflow-hidden shadow-2xl">
              <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-indigo-500/10 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2"></div>
              <div className="relative z-10 space-y-6">
                 <div className="bg-indigo-500/20 text-indigo-400 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] inline-block border border-white/5">Payroll Master Engine</div>
                 <h2 className="text-4xl md:text-6xl font-black italic uppercase tracking-tighter leading-none">Fiscal Ledger</h2>
                 <p className="text-slate-400 max-w-xl font-medium">Processing cycle for current month. All statutory deductions are automatically computed based on the Compliance Master configuration.</p>
              </div>
              <div className="flex flex-col gap-4 relative z-10 w-full lg:w-auto">
                 <button className="px-12 py-6 bg-indigo-600 text-white rounded-[2.5rem] font-black text-sm uppercase tracking-widest shadow-2xl flex items-center justify-center gap-4 hover:bg-indigo-500 transition-all active:scale-95">
                    <BadgePercent size={24}/> RUN PAYROLL CYCLE
                 </button>
                 <button className="px-12 py-6 bg-white/5 border border-white/10 text-white rounded-[2.5rem] font-black text-sm uppercase tracking-widest flex items-center justify-center gap-4 hover:bg-white/10 transition-all">
                    <DownloadCloud size={20}/> BANK DISBURSAL SHEET
                 </button>
              </div>
           </div>

           <div className="bg-white rounded-[3.5rem] border border-slate-100 shadow-sm overflow-hidden">
              <div className="p-8 border-b border-slate-50 flex justify-between items-center bg-slate-50/50">
                 <h3 className="text-xl font-black text-slate-900 uppercase italic">Employee Pay Matrix</h3>
              </div>
              <div className="overflow-x-auto">
                 <table className="w-full text-left whitespace-nowrap">
                    <thead className="bg-slate-50 text-slate-400 text-[9px] font-black uppercase tracking-[0.2em] border-b border-slate-100">
                       <tr>
                          <th className="px-10 py-7">Personnel Identity</th>
                          <th className="px-10 py-7">Gross Pay (₹)</th>
                          <th className="px-10 py-7">Stat. Deductions</th>
                          <th className="px-10 py-7">Net Disbursed</th>
                          <th className="px-10 py-7 text-right">Operations</th>
                       </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                       {staffList.map(staff => (
                         <tr key={staff.id} className="hover:bg-slate-50/50 transition-colors group">
                            <td className="px-10 py-7">
                               <div className="flex items-center gap-4">
                                  <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600 font-black text-sm">{staff.name?.[0] || '?'}</div>
                                  <div>
                                     <p className="font-black text-slate-900 text-sm">{staff.name}</p>
                                     <p className="text-[9px] font-bold text-slate-400 uppercase">UID: {staff.id}</p>
                                  </div>
                               </div>
                            </td>
                            <td className="px-10 py-7 font-black text-slate-700">₹{staff.salary?.gross?.toLocaleString() || '0'}</td>
                            <td className="px-10 py-7">
                               <div className="flex items-center gap-2 text-rose-500 font-black text-xs">
                                  <ArrowDownRight size={14}/> ₹{staff.salary ? (staff.salary.gross - staff.salary.net).toLocaleString() : '0'}
                               </div>
                            </td>
                            <td className="px-10 py-7 font-black text-emerald-600 text-base">₹{staff.salary?.net?.toLocaleString() || '0'}</td>
                            <td className="px-10 py-7 text-right">
                               <button onClick={() => { setSelectedStaff(staff); setModalMode('payslip'); }} className="p-3 bg-white border border-slate-200 text-slate-400 hover:text-indigo-600 rounded-xl shadow-sm transition-all"><Receipt size={18}/></button>
                            </td>
                         </tr>
                       ))}
                    </tbody>
                 </table>
              </div>
           </div>
        </div>
      )}

      {activeTab === 'leave' && (
        <div className="space-y-10 animate-in fade-in">
           <div className="bg-rose-600 p-10 md:p-16 rounded-[4rem] text-white flex flex-col lg:flex-row justify-between items-center gap-12 relative overflow-hidden shadow-2xl">
              <div className="absolute top-0 right-0 p-10 opacity-10 rotate-12"><CalendarCheck size={200}/></div>
              <div className="relative z-10 space-y-6">
                 <div className="bg-white/20 text-white px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] inline-block border border-white/5">Attendance Lifecycle</div>
                 <h2 className="text-4xl md:text-6xl font-black italic uppercase tracking-tighter leading-none">Leave Matrix</h2>
                 <p className="text-rose-100 max-w-xl font-medium">Manage institutional leave protocols. Approve, reject, or track staff availability for seamless academic operations.</p>
              </div>
              <button onClick={() => setShowApplyLeave(true)} className="relative z-10 px-10 py-5 bg-white text-rose-600 rounded-[2rem] font-black text-xs uppercase tracking-widest flex items-center gap-3 shadow-2xl hover:scale-105 active:scale-95 transition-all">
                 <Plus size={20}/> New Leave Request
              </button>
           </div>

           <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                { label: 'Pending Requests', value: leaveRequests.filter(r => r.status === LeaveStatus.PENDING).length, color: 'text-amber-600', icon: <Clock4 size={20}/> },
                { label: 'On Leave Today', value: 3, color: 'text-rose-600', icon: <CalendarX size={20}/> },
                { label: 'Approval Rate', value: '92%', color: 'text-emerald-600', icon: <CheckCircle2 size={20}/> }
              ].map((stat, idx) => (
                <div key={idx} className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm flex items-center justify-between group hover:shadow-lg transition-all">
                  <div>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{stat.label}</p>
                    <h3 className={`text-3xl font-black ${stat.color}`}>{stat.value}</h3>
                  </div>
                  <div className={`p-4 rounded-2xl bg-slate-50 ${stat.color} group-hover:scale-110 transition-transform`}>{stat.icon}</div>
                </div>
              ))}
           </div>

           <div className="bg-white rounded-[3.5rem] border border-slate-100 shadow-sm overflow-hidden">
              <div className="p-8 border-b border-slate-50 bg-slate-50/50 flex justify-between items-center">
                 <h3 className="text-xl font-black text-slate-900 uppercase italic">Personnel Leave Ledger</h3>
              </div>
              <div className="overflow-x-auto">
                 <table className="w-full text-left whitespace-nowrap">
                    <thead className="bg-slate-50 text-slate-400 text-[9px] font-black uppercase tracking-[0.2em] border-b border-slate-100">
                       <tr>
                          <th className="px-10 py-7">Staff Context</th>
                          <th className="px-10 py-7">Timeline</th>
                          <th className="px-10 py-7">Classification</th>
                          <th className="px-10 py-7">Registry Status</th>
                          <th className="px-10 py-7 text-right">Authority</th>
                       </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                       {leaveRequests.map(req => (
                         <tr key={req.id} className="hover:bg-slate-50/50 transition-colors group">
                            <td className="px-10 py-7">
                               <div className="flex items-center gap-4">
                                  <div className="w-10 h-10 bg-rose-50 rounded-xl flex items-center justify-center text-rose-600 font-black text-sm">{req.staffName?.[0] || '?'}</div>
                                  <div>
                                     <p className="font-black text-slate-900 text-sm">{req.staffName}</p>
                                     <p className="text-[9px] font-bold text-slate-400 uppercase">UID: {req.staffId}</p>
                                  </div>
                               </div>
                            </td>
                            <td className="px-10 py-7">
                               <p className="text-xs font-black text-slate-700">{req.startDate} <span className="text-slate-300 font-medium">to</span> {req.endDate}</p>
                               <p className="text-[9px] font-bold text-slate-400 uppercase mt-1 italic">Applied: {req.appliedAt}</p>
                            </td>
                            <td className="px-10 py-7">
                               <span className="px-3 py-1 bg-slate-100 text-slate-600 rounded-lg text-[9px] font-black uppercase tracking-widest border border-slate-200">{req.type}</span>
                               <p className="text-[9px] text-slate-400 mt-1 truncate max-w-[150px]">{req.reason}</p>
                            </td>
                            <td className="px-10 py-7">
                               <span className={`px-4 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest ${
                                 req.status === LeaveStatus.APPROVED ? 'bg-emerald-50 text-emerald-600' :
                                 req.status === LeaveStatus.REJECTED ? 'bg-rose-50 text-rose-600' :
                                 'bg-amber-50 text-amber-600'
                               }`}>{req.status}</span>
                            </td>
                            <td className="px-10 py-7 text-right">
                               {req.status === LeaveStatus.PENDING ? (
                                 <div className="flex justify-end gap-2">
                                    <button onClick={() => handleLeaveAction(req.id, LeaveStatus.APPROVED)} className="p-2.5 bg-emerald-50 text-emerald-600 rounded-xl hover:bg-emerald-600 hover:text-white transition-all shadow-sm"><CheckCircle2 size={18}/></button>
                                    <button onClick={() => handleLeaveAction(req.id, LeaveStatus.REJECTED)} className="p-2.5 bg-rose-50 text-rose-600 rounded-xl hover:bg-rose-600 hover:text-white transition-all shadow-sm"><X size={18}/></button>
                                 </div>
                               ) : (
                                 <span className="text-[10px] font-black text-slate-300 uppercase italic">Settled Node</span>
                               )}
                            </td>
                         </tr>
                       ))}
                    </tbody>
                 </table>
              </div>
           </div>
        </div>
      )}

      {activeTab === 'compliance' && (
        <div className="space-y-10 animate-in fade-in duration-300">
           <div className="bg-slate-900 p-10 md:p-16 rounded-[4rem] text-white relative overflow-hidden shadow-2xl">
              <div className="absolute top-0 right-0 p-10 opacity-10 rotate-12"><Scale size={200}/></div>
              <div className="relative z-10">
                 <div className="bg-indigo-500/20 text-indigo-400 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] inline-block border border-white/5 mb-6">Statutory Configuration Hub</div>
                 <h2 className="text-4xl md:text-6xl font-black italic uppercase tracking-tighter leading-none mb-4">Labour Law Master</h2>
                 <p className="text-slate-400 max-w-2xl font-medium">Define global percentages and wage thresholds for PF, ESI, Gratuity, and Professional Tax as per the latest Central/State mandates.</p>
              </div>
           </div>

           <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
              <div className="bg-white p-10 rounded-[3.5rem] border border-slate-100 shadow-sm">
                 <h3 className="text-2xl font-black text-slate-900 mb-10 flex items-center gap-4"><Landmark className="text-indigo-600"/> Provident Fund & ESI</h3>
                 <div className="space-y-8">
                    <div className="grid grid-cols-2 gap-8">
                       <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-3">PF Rate (Employer/Employee %)</label>
                          <input type="number" value={complianceConfig.pf_rate} onChange={(e) => setComplianceConfig({...complianceConfig, pf_rate: Number(e.target.value)})} className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-lg outline-none focus:bg-white" />
                       </div>
                       <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-3">PF Wage Ceiling (₹)</label>
                          <input type="number" value={complianceConfig.pf_threshold} onChange={(e) => setComplianceConfig({...complianceConfig, pf_threshold: Number(e.target.value)})} className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-lg outline-none focus:bg-white" />
                       </div>
                    </div>
                    <div className="grid grid-cols-3 gap-6">
                       <div className="space-y-2">
                          <label className="text-[9px] font-black text-slate-400 uppercase tracking-tight px-2">ESI Emp Rate (%)</label>
                          <input type="number" step="0.01" value={complianceConfig.esi_emp_rate} onChange={(e) => setComplianceConfig({...complianceConfig, esi_emp_rate: Number(e.target.value)})} className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-sm outline-none" />
                       </div>
                       <div className="space-y-2">
                          <label className="text-[9px] font-black text-slate-400 uppercase tracking-tight px-2">ESI Empr Rate (%)</label>
                          <input type="number" step="0.01" value={complianceConfig.esi_empr_rate} onChange={(e) => setComplianceConfig({...complianceConfig, esi_empr_rate: Number(e.target.value)})} className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-sm outline-none" />
                       </div>
                       <div className="space-y-2">
                          <label className="text-[9px] font-black text-slate-400 uppercase tracking-tight px-2">ESI Gross Limit (₹)</label>
                          <input type="number" value={complianceConfig.esi_gross_limit} onChange={(e) => setComplianceConfig({...complianceConfig, esi_gross_limit: Number(e.target.value)})} className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-sm outline-none" />
                       </div>
                    </div>
                 </div>
              </div>

              <div className="bg-white p-10 rounded-[3.5rem] border border-slate-100 shadow-sm">
                 <h3 className="text-2xl font-black text-slate-900 mb-10 flex items-center gap-4"><Coins className="text-amber-500"/> Retirals & Taxes</h3>
                 <div className="space-y-8">
                    <div className="grid grid-cols-2 gap-8">
                       <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-3">Gratuity Prov. Rate (%)</label>
                          <input type="number" step="0.01" value={complianceConfig.gratuity_rate} onChange={(e) => setComplianceConfig({...complianceConfig, gratuity_rate: Number(e.target.value)})} className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-lg outline-none" />
                       </div>
                       <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-3">Professional Tax Slab (₹)</label>
                          <input type="number" value={complianceConfig.pt_standard} onChange={(e) => setComplianceConfig({...complianceConfig, pt_standard: Number(e.target.value)})} className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-lg outline-none" />
                       </div>
                    </div>
                    <div className="p-8 bg-amber-50 rounded-[2rem] border border-amber-100 flex items-start gap-5">
                       <div className="p-3 bg-white rounded-xl shadow-sm text-amber-600"><AlertTriangle size={24}/></div>
                       <p className="text-[11px] font-medium text-amber-800 leading-relaxed italic">Changes to these settings will retrospectively affect salary calculations for the next payroll run. Ensure these match your State's specific PT and LWF slabs.</p>
                    </div>
                 </div>
              </div>
           </div>
        </div>
      )}

      {activeTab === 'add_staff' && (
        <div className="max-w-6xl mx-auto bg-white rounded-[4rem] border border-slate-100 shadow-2xl relative overflow-hidden animate-in zoom-in-95">
           <div className="absolute top-0 left-0 w-3 h-full bg-emerald-600"></div>
           <div className="p-10 md:p-20">
              <div className="flex justify-between items-start mb-16">
                 <div>
                    <h2 className="text-4xl md:text-6xl font-black text-slate-900 italic uppercase tracking-tighter leading-none">Recruitment</h2>
                    <p className="text-slate-400 font-bold uppercase text-[10px] md:text-sm tracking-widest mt-2">Institutional Onboarding Protocol • Step {formStep} of 4</p>
                 </div>
                 <button onClick={() => setActiveTab('directory')} className="p-4 hover:bg-slate-50 rounded-full text-slate-300 transition-colors"><X size={40}/></button>
              </div>

              <div className="flex gap-4 mb-20">
                 {[1, 2, 3, 4].map(s => (
                   <div key={s} className="flex-1">
                      <div className={`h-1.5 rounded-full mb-4 transition-all duration-500 ${formStep >= s ? 'bg-emerald-600' : 'bg-slate-100'}`}></div>
                      <span className={`text-[9px] font-black uppercase tracking-widest ${formStep === s ? 'text-slate-900' : 'text-slate-300'}`}>Phase {s}</span>
                   </div>
                 ))}
              </div>

              <form onSubmit={handleOnboarding} className="space-y-12">
                 {formStep === 1 && (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 animate-in fade-in">
                       <div className="space-y-3">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Full Legal Name</label>
                          <input name="fullName" required className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none focus:bg-white focus:border-emerald-500 shadow-inner" />
                       </div>
                       <div className="space-y-3">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Employee ID (Optional)</label>
                          <input name="empId" placeholder="Auto-generated" className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none shadow-inner" />
                       </div>
                       <div className="space-y-3">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Role Category</label>
                          <select name="roleCategory" className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none">
                             <option value="Teaching Staff">Faculty (Teaching)</option>
                             <option value="Non-Teaching Staff">Operations (Non-Teaching)</option>
                          </select>
                       </div>
                       <button type="button" onClick={() => setFormStep(2)} className="col-span-full py-6 bg-slate-900 text-white rounded-[2.5rem] font-black text-sm uppercase tracking-widest flex items-center justify-center gap-3 shadow-2xl mt-10">Next Phase <ArrowRight size={20}/></button>
                    </div>
                 )}

                 {formStep === 2 && (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 animate-in fade-in">
                       <div className="space-y-3">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Tier Policy</label>
                          <select name="employmentType" className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none focus:border-emerald-500">
                             <option value={EmploymentCategory.REGULAR}>Regular (Full Statutory)</option>
                             <option value={EmploymentCategory.TEMPORARY}>Temporary / Ad-hoc</option>
                             <option value={EmploymentCategory.CONTRACT}>Contract (Consolidated)</option>
                          </select>
                       </div>
                       <div className="space-y-3">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Designation</label>
                          <input name="designation" required placeholder="e.g. Senior Lecturer" className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none shadow-inner" />
                       </div>
                       <div className="space-y-3">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Date of Joining</label>
                          <input name="doj" type="date" required className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none shadow-inner" />
                       </div>
                       <div className="col-span-full flex gap-4 mt-10">
                          <button type="button" onClick={() => setFormStep(1)} className="flex-1 py-6 bg-slate-50 text-slate-400 rounded-[2.5rem] font-black text-sm uppercase tracking-widest flex items-center justify-center gap-3 shadow-sm"><ArrowLeft size={20}/> Back</button>
                          <button type="button" onClick={() => setFormStep(3)} className="flex-[2] py-6 bg-slate-900 text-white rounded-[2.5rem] font-black text-sm uppercase tracking-widest flex items-center justify-center gap-3 shadow-2xl">Structure Salary <ArrowRight size={20}/></button>
                       </div>
                    </div>
                 )}

                 {formStep === 3 && (
                    <div className="space-y-12 animate-in fade-in">
                       <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                          <div className="space-y-8">
                             <h4 className="text-2xl font-black text-slate-900 italic">Salary Component Architect</h4>
                             <div className="space-y-4">
                                <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest px-2">Monthly Basic Salary (₹)</label>
                                <div className="relative">
                                   <IndianRupee className="absolute left-6 top-1/2 -translate-y-1/2 text-emerald-600" size={24}/>
                                   <input name="basicPay" type="number" required placeholder="45000" className="w-full pl-16 pr-6 py-8 bg-emerald-50 border-2 border-emerald-100 rounded-[3rem] font-black text-4xl outline-none focus:bg-white focus:border-emerald-500 shadow-inner text-emerald-900" />
                                </div>
                                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter px-4">*Standard DA (15%) and HRA (40%) will be auto-calculated upon registry.</p>
                             </div>
                          </div>
                          <div className="bg-slate-900 p-10 rounded-[4rem] text-white shadow-2xl relative overflow-hidden">
                             <div className="absolute top-0 right-0 p-8 opacity-10"><ShieldCheck size={120}/></div>
                             <h4 className="text-xl font-black mb-8 flex items-center gap-3"><Landmark size={24} className="text-indigo-400"/> Compliance Auto-Bind</h4>
                             <div className="space-y-6">
                                <div className="flex justify-between items-center text-xs font-bold text-slate-400"><span className="uppercase">Provident Fund (PF)</span><span className="font-black text-white">{complianceConfig.pf_rate}% (Employer/Employee)</span></div>
                                <div className="flex justify-between items-center text-xs font-bold text-slate-400"><span className="uppercase">ESI Insurance</span><span className="font-black text-white">{complianceConfig.esi_emp_rate}% (Employee)</span></div>
                                <div className="flex justify-between items-center text-xs font-bold text-slate-400"><span className="uppercase">Gratuity Scheme</span><span className="font-black text-white">4.81% Accrual (Monthly)</span></div>
                                <div className="flex justify-between items-center text-xs font-bold text-slate-400"><span className="uppercase">Professional Tax</span><span className="font-black text-white">₹{complianceConfig.pt_standard}/mo Slab</span></div>
                             </div>
                          </div>
                       </div>
                       <div className="flex gap-4 mt-10">
                          <button type="button" onClick={() => setFormStep(2)} className="flex-1 py-6 bg-slate-50 text-slate-400 rounded-[2.5rem] font-black text-sm uppercase tracking-widest flex items-center justify-center gap-3"><ArrowLeft size={20}/> Back</button>
                          <button type="button" onClick={() => setFormStep(4)} className="flex-[2] py-6 bg-slate-900 text-white rounded-[2.5rem] font-black text-sm uppercase tracking-widest flex items-center justify-center gap-3 shadow-2xl">Banking Details <ArrowRight size={20}/></button>
                       </div>
                    </div>
                 )}

                 {formStep === 4 && (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 animate-in fade-in">
                       <div className="space-y-3">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Bank Designation</label>
                          <input name="bankName" required placeholder="HDFC Bank" className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none shadow-inner" />
                       </div>
                       <div className="space-y-3">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Account Number</label>
                          <input name="accountNumber" required className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none shadow-inner" />
                       </div>
                       <div className="space-y-3">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">IFSC Identification</label>
                          <input name="ifsc" required className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none shadow-inner uppercase" />
                       </div>
                       <div className="col-span-full bg-emerald-50 p-12 rounded-[4rem] border-2 border-emerald-100 text-center relative overflow-hidden mt-10">
                          <div className="absolute top-0 right-0 p-8 opacity-10"><CheckCircle2 size={120} className="text-emerald-600"/></div>
                          <h3 className="text-3xl font-black text-emerald-900 italic mb-4">Registry Ready</h3>
                          <button type="submit" disabled={isSubmitting} className="px-16 py-8 bg-emerald-600 text-white rounded-[3rem] font-black text-xl uppercase tracking-widest shadow-2xl hover:bg-emerald-700 transition-all flex items-center justify-center gap-4 mx-auto active:scale-95">
                             {isSubmitting ? <Loader2 className="animate-spin"/> : <ShieldCheck size={28}/>} AUTHORIZE EMPLOYMENT
                          </button>
                       </div>
                    </div>
                 )}
              </form>
           </div>
        </div>
      )}

      {/* PAYSLIP MODAL (Print Ready) */}
      {modalMode === 'payslip' && selectedStaff && (
         <div className="fixed inset-0 z-[150] flex items-center justify-center bg-slate-950/90 backdrop-blur-xl p-4 no-print animate-in zoom-in-95" onClick={() => setModalMode(null)}>
            <div className="bg-white rounded-[3rem] p-10 md:p-20 max-w-4xl w-full shadow-2xl relative overflow-y-auto max-h-[95vh]" onClick={(e) => e.stopPropagation()}>
               <button onClick={() => setModalMode(null)} className="absolute top-10 right-10 p-3 text-slate-400 hover:bg-slate-100 rounded-full transition-all"><X size={36}/></button>
               
               {/* Print Header */}
               <div className="flex justify-between items-start mb-12 border-b-2 border-slate-900 pb-8">
                  <div className="flex items-center gap-6">
                     <div className="w-16 h-16 bg-slate-900 text-white rounded-[1.5rem] flex items-center justify-center font-black text-2xl italic shadow-xl shadow-indigo-500/20">EN</div>
                     <div>
                        <h2 className="text-3xl font-black uppercase tracking-tighter leading-none">EduNexus Global</h2>
                        <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] mt-2">Institutional Payroll Transcript • verified node</p>
                     </div>
                  </div>
                  <div className="text-right">
                     <h3 className="text-2xl font-black text-indigo-600 italic uppercase leading-none">Salary Slip</h3>
                     <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Cycle: {new Date().toLocaleString('default', { month: 'long', year: 'numeric' })}</p>
                  </div>
               </div>

               {/* Personnel Grid */}
               <div className="grid grid-cols-2 gap-x-12 gap-y-6 mb-12 text-[11px] font-bold text-slate-600 bg-slate-50 p-10 rounded-[3rem] border border-slate-100">
                  <div className="space-y-4">
                     <div className="flex justify-between border-b border-slate-200 pb-2">
                        <span className="uppercase text-slate-400 tracking-tighter">Personnel Name</span>
                        <span className="text-slate-900 uppercase font-black">{selectedStaff.name}</span>
                     </div>
                     <div className="flex justify-between border-b border-slate-200 pb-2">
                        <span className="uppercase text-slate-400 tracking-tighter">Cloud ID</span>
                        <span className="text-slate-900 uppercase font-black font-mono">{selectedStaff.id}</span>
                     </div>
                     <div className="flex justify-between border-b border-slate-200 pb-2">
                        <span className="uppercase text-slate-400 tracking-tighter">Tier Type</span>
                        <span className="text-indigo-600 uppercase font-black">{selectedStaff.employment_type}</span>
                     </div>
                  </div>
                  <div className="space-y-4">
                     <div className="flex justify-between border-b border-slate-200 pb-2">
                        <span className="uppercase text-slate-400 tracking-tighter">Bank Ledger</span>
                        <span className="text-slate-900 uppercase font-black">**** {selectedStaff.bank_account_number?.slice(-4)}</span>
                     </div>
                     <div className="flex justify-between border-b border-slate-200 pb-2">
                        <span className="uppercase text-slate-400 tracking-tighter">IFSC Identification</span>
                        <span className="text-slate-900 uppercase font-black">{selectedStaff.bank_ifsc}</span>
                     </div>
                     <div className="flex justify-between border-b border-slate-200 pb-2">
                        <span className="uppercase text-slate-400 tracking-tighter">Designation</span>
                        <span className="text-slate-900 uppercase font-black">{selectedStaff.designation}</span>
                     </div>
                  </div>
               </div>

               {/* Earnings/Deductions Matrix */}
               <div className="grid grid-cols-2 border-2 border-slate-900 rounded-[2.5rem] overflow-hidden mb-12 shadow-2xl">
                  <div className="border-r-2 border-slate-900">
                     <div className="bg-slate-900 p-5 text-white text-[10px] font-black uppercase text-center tracking-[0.3em]">Earnings Manifest</div>
                     <div className="p-8 space-y-4 text-xs font-bold">
                        {selectedStaff.salary && Object.entries(selectedStaff.salary.earnings).map(([key, val]: [string, any]) => (
                          val > 0 && (
                            <div key={key} className="flex justify-between uppercase">
                               <span className="text-slate-400">{key.replace('_', ' ')}</span>
                               <span className="text-slate-900">₹{val.toLocaleString()}</span>
                            </div>
                          )
                        ))}
                     </div>
                     <div className="p-8 bg-slate-50 border-t-2 border-slate-900 flex justify-between items-center">
                        <span className="text-[11px] font-black uppercase text-slate-400">Gross Emoluments</span>
                        <span className="text-2xl font-black text-slate-900">₹{selectedStaff.salary?.gross?.toLocaleString() || '0'}</span>
                     </div>
                  </div>
                  <div>
                     <div className="bg-rose-600 p-5 text-white text-[10px] font-black uppercase text-center tracking-[0.3em]">Compliance Deductions</div>
                     <div className="p-8 space-y-4 text-xs font-bold">
                        {selectedStaff.salary && Object.entries(selectedStaff.salary.deductions).map(([key, val]: [string, any]) => (
                          val > 0 && (
                            <div key={key} className="flex justify-between uppercase">
                               <span className="text-slate-400">{key.replace('_', ' ')}</span>
                               <span className="text-rose-600">₹{val.toLocaleString()}</span>
                            </div>
                          )
                        ))}
                     </div>
                     <div className="p-8 bg-slate-50 border-t-2 border-slate-900 flex justify-between items-center">
                        <span className="text-[11px] font-black uppercase text-slate-400">Total Statutory Recovery</span>
                        <span className="text-2xl font-black text-rose-600">₹{selectedStaff.salary ? (selectedStaff.salary.gross - selectedStaff.salary.net).toLocaleString() : '0'}</span>
                     </div>
                  </div>
               </div>

               {/* Retirals Provision Section */}
               <div className="bg-indigo-50 border border-indigo-100 rounded-[2.5rem] p-8 mb-12 flex justify-between items-center">
                  <div className="flex items-center gap-6">
                     <div className="p-4 bg-white rounded-2xl text-indigo-600 shadow-sm"><Shield size={32}/></div>
                     <div>
                        <h4 className="text-sm font-black text-slate-900 uppercase">Employer Statutory Provisions (CTC Contribution)</h4>
                        <p className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter mt-1">These amounts are credited to your social security accounts.</p>
                     </div>
                  </div>
                  <div className="text-right">
                     <p className="text-xs font-black text-indigo-600 uppercase">Total: ₹{selectedStaff.salary ? (selectedStaff.salary.ctc - selectedStaff.salary.gross).toLocaleString() : '0'}</p>
                     <p className="text-[9px] text-slate-400 font-bold uppercase mt-1">Incl. Gratuity & Empr PF</p>
                  </div>
               </div>

               {/* Net Disbursal Footer */}
               <div className="bg-indigo-600 p-10 rounded-[3rem] text-white flex justify-between items-center shadow-[0_40px_80px_-20px_rgba(79,70,229,0.5)]">
                  <div>
                     <p className="text-[11px] font-black uppercase tracking-widest text-indigo-200 mb-2">Net Disbursed to Bank Account</p>
                     <p className="text-5xl font-black italic tracking-tighter">₹{selectedStaff.salary?.net?.toLocaleString() || '0'}</p>
                     <p className="text-[10px] font-bold uppercase mt-4 text-indigo-100 flex items-center gap-2"><FileSignature size={14}/> {amountToWords(selectedStaff.salary?.net || 0)}</p>
                  </div>
                  <div className="text-right">
                     <QrCode size={100} className="text-indigo-400 opacity-50 ml-auto mb-4" />
                     <p className="text-[9px] font-black text-indigo-200 uppercase leading-tight">Ledger Registry Node<br/>Verified & Encrypted</p>
                  </div>
               </div>

               {/* Signatures */}
               <div className="mt-20 flex justify-between px-10">
                  <div className="text-center">
                     <div className="w-56 h-12 flex items-center justify-center italic text-slate-300 font-serif">Sign: Acct. Node</div>
                     <div className="w-56 border-b-2 border-slate-200 mb-3"></div>
                     <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Accounts Authority</p>
                  </div>
                  <div className="text-center">
                     <div className="w-56 h-12 flex items-center justify-center italic text-indigo-900 font-serif opacity-40 text-xl">EduNexus Global Academy</div>
                     <div className="w-56 border-b-2 border-slate-200 mb-3"></div>
                     <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Principal / Director</p>
                  </div>
               </div>

               <div className="mt-20 flex justify-center no-print">
                  <button onClick={() => window.print()} className="px-16 py-6 bg-slate-900 text-white rounded-[2.5rem] font-black text-sm uppercase tracking-widest flex items-center justify-center gap-4 shadow-2xl hover:scale-105 active:scale-95 transition-all">
                     <Printer size={24}/> EXECUTE PRINT COMMAND
                  </button>
               </div>
            </div>
         </div>
      )}

      {/* LEAVE APPLICATION MODAL */}
      {showApplyLeave && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in" onClick={() => setShowApplyLeave(false)}>
           <div className="bg-white rounded-[4rem] p-10 md:p-14 max-w-2xl w-full shadow-2xl relative overflow-hidden" onClick={(e) => e.stopPropagation()}>
              <div className="absolute top-0 left-0 w-3 h-full bg-rose-600"></div>
              <div className="flex justify-between items-start mb-10">
                 <div>
                   <h3 className="text-4xl font-black text-slate-900 tracking-tighter uppercase italic leading-none">Apply for Leave</h3>
                   <p className="text-sm font-medium text-slate-400 mt-2 uppercase tracking-widest">Submit request to institutional authority</p>
                 </div>
                 <button onClick={() => setShowApplyLeave(false)} className="p-3 hover:bg-slate-100 rounded-full text-slate-400 transition-colors"><X size={36}/></button>
              </div>

              <form onSubmit={handleApplyLeaveSubmit} className="space-y-8">
                 <div className="space-y-3">
                    <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest px-3">Personnel Selection</label>
                    <select name="staffId" required className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none focus:bg-white focus:border-rose-500 transition-all">
                       <option value="">Select Identity...</option>
                       {staffList.map(s => <option key={s.id} value={s.id}>{s.name} ({s.id})</option>)}
                    </select>
                 </div>

                 <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-3">
                       <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest px-3">Leave Category</label>
                       <select name="type" required className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none focus:bg-white focus:border-rose-500 transition-all">
                          {Object.values(LeaveType).map(t => <option key={t} value={t}>{t}</option>)}
                       </select>
                    </div>
                    <div className="space-y-3 flex items-center gap-4 pt-10">
                       <div className="p-4 bg-rose-50 rounded-2xl text-rose-500 border border-rose-100 shadow-sm"><FileQuestion size={24}/></div>
                       <p className="text-[10px] font-black text-slate-400 leading-tight uppercase">Ensure backup faculty sync is notified</p>
                    </div>
                 </div>

                 <div className="grid grid-cols-2 gap-8">
                    <div className="space-y-3">
                       <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest px-3">Start Date</label>
                       <input name="start" type="date" required className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none focus:bg-white shadow-inner" />
                    </div>
                    <div className="space-y-3">
                       <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest px-3">End Date</label>
                       <input name="end" type="date" required className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-sm outline-none focus:bg-white shadow-inner" />
                    </div>
                 </div>

                 <div className="space-y-3">
                    <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest px-3">Primary Motive (Reason)</label>
                    <textarea name="reason" required rows={3} placeholder="Draft clear intent for leave..." className="w-full p-6 bg-slate-50 border-2 border-slate-100 rounded-[2.5rem] font-black text-sm outline-none focus:bg-white resize-none transition-all shadow-inner"></textarea>
                 </div>

                 <button type="submit" className="w-full py-8 bg-rose-600 text-white rounded-[3rem] font-black text-xl shadow-[0_30px_60px_-15px_rgba(225,29,72,0.5)] hover:scale-105 active:scale-95 transition-all">
                    SUBMIT REQUEST TO VAULT §
                 </button>
              </form>
           </div>
        </div>
      )}

      {/* Profile Modal */}
      {modalMode === 'profile' && selectedStaff && (
         <div className="fixed inset-0 z-[150] flex items-center justify-center bg-slate-900/60 backdrop-blur-md p-4 no-print animate-in fade-in" onClick={() => setModalMode(null)}>
            <div className="bg-white rounded-[4rem] p-10 md:p-16 max-w-4xl w-full shadow-2xl relative overflow-y-auto max-h-[90vh]" onClick={(e) => e.stopPropagation()}>
               <div className="flex justify-between items-start mb-12">
                  <div className="flex items-center gap-6">
                     <img src={selectedStaff.photo_url} className="w-24 h-24 rounded-[2rem] object-cover border-4 border-indigo-50 shadow-xl" />
                     <div>
                        <h2 className="text-4xl font-black text-slate-900 tracking-tighter italic uppercase leading-none">{selectedStaff.name}</h2>
                        <p className="text-indigo-600 font-bold uppercase text-[10px] tracking-[0.2em] flex items-center gap-2 mt-3">
                        <ShieldCheck size={16}/> {selectedStaff.designation} • UID: {selectedStaff.id}
                        </p>
                     </div>
                  </div>
                  <button onClick={() => setModalMode(null)} className="p-3 hover:bg-slate-100 rounded-full text-slate-400 transition-colors"><X size={36}/></button>
               </div>
               <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                  <div className="space-y-8">
                     <section className="bg-slate-50 p-8 rounded-[2.5rem]">
                        <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100 pb-2 mb-4">Identity Context</h4>
                        <div className="grid grid-cols-2 gap-y-4">
                           <div><p className="text-[9px] font-bold text-slate-400 uppercase">Employment</p><p className="text-sm font-black text-emerald-600 uppercase">{selectedStaff.employment_type}</p></div>
                           <div><p className="text-[9px] font-bold text-slate-400 uppercase">Joining</p><p className="text-sm font-black text-slate-700">{selectedStaff.doj}</p></div>
                           <div><p className="text-[9px] font-bold text-slate-400 uppercase">Department</p><p className="text-sm font-black text-slate-700">{selectedStaff.department}</p></div>
                        </div>
                     </section>
                  </div>
                  <div className="space-y-8">
                     <section className="bg-slate-900 p-8 rounded-[2.5rem] text-white shadow-xl relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-4 opacity-10"><Landmark size={64}/></div>
                        <h4 className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-6">Banking Node</h4>
                        <div className="space-y-4">
                           <div className="flex justify-between items-center border-b border-white/5 pb-2"><span className="text-[10px] font-bold uppercase opacity-60">Bank</span><span className="font-black text-indigo-400">{selectedStaff.bank_name}</span></div>
                           <div className="flex justify-between items-center border-b border-white/5 pb-2"><span className="text-[10px] font-bold uppercase opacity-60">Account</span><span className="font-mono text-sm tracking-tighter">**** {selectedStaff.bank_account_number?.slice(-4)}</span></div>
                           <div className="flex justify-between items-center"><span className="text-[10px] font-bold uppercase opacity-60">IFSC</span><span className="font-black">{selectedStaff.bank_ifsc}</span></div>
                        </div>
                     </section>
                  </div>
               </div>
            </div>
         </div>
      )}

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #e2e8f0; border-radius: 10px; }
        @media print {
           .no-print { display: none !important; }
           body { background: white !important; }
           .p-4, .p-8 { padding: 0 !important; }
           .fixed { position: relative !important; inset: 0 !important; background: white !important; backdrop-filter: none !important; }
           .shadow-2xl { box-shadow: none !important; }
           .max-h-[95vh] { max-height: none !important; overflow: visible !important; }
        }
      `}</style>
    </div>
  );
};

export default HRManagement;
