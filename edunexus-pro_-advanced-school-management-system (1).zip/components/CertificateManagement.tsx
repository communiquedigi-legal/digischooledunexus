import React, { useState } from 'react';
import { 
  FileText, CreditCard, User, Printer, Download, Eye, ShieldCheck, 
  GraduationCap, CheckCircle2, X, QrCode, Calendar, Clock, MapPin, 
  PenTool, BarChart2 
} from 'lucide-react';
import { MOCK_STUDENTS } from '../constants';
import { AcademicSession } from '../types';

interface CertificateManagementProps {
  session?: AcademicSession;
}

const CertificateManagement: React.FC<CertificateManagementProps> = ({ session }) => {
  const [previewType, setPreviewType] = useState<string | null>(null);
  const [selectedStudent, setSelectedStudent] = useState(MOCK_STUDENTS[0]);
  const [isHubActive, setIsHubActive] = useState(false);

  const currentSessionLabel = session?.label.split(' ')[0] || '2025-26';

  const CertificatePreview = () => (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-md p-4 animate-in fade-in no-print" onClick={() => setPreviewType(null)}>
      <div className="bg-white rounded-[3rem] p-12 max-w-4xl w-full shadow-2xl max-h-[90vh] overflow-y-auto relative" onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-12 border-b border-slate-100 pb-8">
          <div>
            <h3 className="text-4xl font-black text-slate-900 leading-tight">{previewType}</h3>
            <p className="text-slate-500 font-medium mt-1 tracking-tight">Verified Digital Transcript • Academic Session {currentSessionLabel}</p>
          </div>
          <div className="flex gap-4">
             <button className="px-8 py-4 bg-indigo-600 text-white rounded-2xl font-black text-sm flex items-center gap-2 shadow-2xl shadow-indigo-500/20 hover:bg-indigo-700 transition-all" onClick={() => window.print()}>
               <Printer size={20} /> Print Document
             </button>
             <button onClick={() => setPreviewType(null)} className="p-3 bg-slate-100 hover:bg-slate-200 rounded-full text-slate-400 transition-colors">
               <X size={32}/>
             </button>
          </div>
        </div>

        <div className="bg-slate-50 p-12 rounded-[3.5rem] border border-slate-200 flex flex-col items-center justify-center print:bg-white print:border-none print:p-0">
          {previewType === 'Identity Cards' ? (
            <div className="w-[3.5in] h-[2.2in] bg-white border border-slate-300 rounded-[2.5rem] shadow-2xl p-6 flex gap-6 relative overflow-hidden">
               <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-600 rotate-45 translate-x-16 -translate-y-16"></div>
               <div className="w-1/3 flex flex-col items-center gap-4">
                  <img src={selectedStudent.photoUrl} className="w-28 h-28 rounded-3xl object-cover border-4 border-indigo-50 shadow-inner" alt="" />
                  <span className="text-[10px] font-black text-white bg-slate-900 px-4 py-1.5 rounded-full uppercase tracking-[0.2em]">STUDENT</span>
               </div>
               <div className="flex-1 flex flex-col justify-between py-2">
                  <div>
                    <h4 className="text-2xl font-black text-slate-900 leading-tight">{selectedStudent.name}</h4>
                    <p className="text-sm text-indigo-600 font-black uppercase tracking-widest mt-1">Grade {selectedStudent.class}-{selectedStudent.section}</p>
                  </div>
                  <div className="space-y-1 text-[11px] font-bold text-slate-600">
                    <p><span className="text-slate-400 uppercase tracking-tighter">ID NO:</span> {selectedStudent.id}</p>
                    <p><span className="text-slate-400 uppercase tracking-tighter">ROLL:</span> {selectedStudent.rollNo}</p>
                    <p><span className="text-slate-400 uppercase tracking-tighter">BLOOD:</span> {selectedStudent.bloodGroup}</p>
                  </div>
                  <div className="flex justify-between items-end">
                     <QrCode size={40} className="text-slate-300" />
                     <div className="text-[9px] font-black italic text-indigo-400 tracking-tight uppercase">EduNexus Pro</div>
                  </div>
               </div>
            </div>
          ) : previewType === 'Admit Cards' ? (
             <div className="w-[6in] h-[4in] bg-white border-2 border-slate-900 p-8 rounded-2xl relative overflow-hidden shadow-xl">
                <div className="absolute inset-0 opacity-[0.03] pointer-events-none flex items-center justify-center"><GraduationCap size={400}/></div>
                <div className="flex justify-between border-b-2 border-slate-900 pb-4 mb-6">
                   <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-slate-900 text-white rounded-xl flex items-center justify-center font-black text-lg">E</div>
                      <div>
                         <h2 className="text-lg font-black uppercase leading-none">EduNexus Global</h2>
                         <p className="text-[10px] font-bold uppercase tracking-widest">Half-Yearly Examination {currentSessionLabel.split('-')[0]}</p>
                      </div>
                   </div>
                   <div className="text-right">
                      <h3 className="text-lg font-black uppercase text-indigo-600 underline underline-offset-4">ADMIT CARD</h3>
                   </div>
                </div>
                <div className="grid grid-cols-4 gap-6">
                   <div className="col-span-1">
                      <img src={selectedStudent.photoUrl} className="w-full aspect-square object-cover border-2 border-slate-900 rounded-lg p-1" alt="" />
                      <div className="mt-4 border-t border-slate-400 pt-1 text-center">
                        <p className="text-[8px] font-black uppercase text-slate-400">Auth Signature</p>
                      </div>
                   </div>
                   <div className="col-span-3 grid grid-cols-2 gap-y-6 gap-x-12 px-4">
                      <div>
                         <p className="text-[10px] font-black text-slate-400 uppercase tracking-tighter mb-0.5">Student Name</p>
                         <p className="text-sm font-black text-slate-900 border-b border-slate-200 pb-1">{selectedStudent.name}</p>
                      </div>
                      <div>
                         <p className="text-[10px] font-black text-slate-400 uppercase tracking-tighter mb-0.5">Roll Number</p>
                         <p className="text-sm font-black text-slate-900 border-b border-slate-200 pb-1">{selectedStudent.rollNo}</p>
                      </div>
                      <div>
                         <p className="text-[10px] font-black text-slate-400 uppercase tracking-tighter mb-0.5">Class & Section</p>
                         <p className="text-sm font-black text-slate-900 border-b border-slate-200 pb-1">{selectedStudent.class}-{selectedStudent.section}</p>
                      </div>
                      <div>
                         <p className="text-[10px] font-black text-slate-400 uppercase tracking-tighter mb-0.5">Exam Center</p>
                         <p className="text-sm font-black text-slate-900 border-b border-slate-200 pb-1">EduNexus Main Campus</p>
                      </div>
                   </div>
                </div>
                <div className="mt-10 border-t-2 border-slate-900 pt-4 flex justify-between items-center">
                   <div className="flex gap-6">
                      <div className="flex items-center gap-2 text-[10px] font-black text-slate-600 uppercase">
                         <Calendar size={14}/> Starts: 15 Oct
                      </div>
                      <div className="flex items-center gap-2 text-[10px] font-black text-slate-600 uppercase">
                         <Clock size={14}/> Time: 09:30 AM
                      </div>
                   </div>
                   <div className="flex items-center gap-4">
                      <p className="text-[8px] font-black text-slate-400 max-w-[120px] leading-tight">Bring this card & valid School ID to the hall.</p>
                      <QrCode size={40} className="text-slate-900" />
                   </div>
                </div>
             </div>
          ) : (
            <div className="w-full aspect-[1.41/1] bg-white border-[20px] border-double border-indigo-50 rounded-xl p-16 text-center relative shadow-inner overflow-hidden">
               <div className="absolute top-0 left-0 w-full h-full opacity-[0.02] pointer-events-none flex items-center justify-center scale-[3]"><ShieldCheck size={200}/></div>
               
               <h2 className="text-6xl font-serif font-black text-indigo-900 mb-2 uppercase tracking-[0.1em] underline decoration-indigo-200 underline-offset-[16px]">Certificate of Excellence</h2>
               <p className="text-xl font-bold text-slate-400 mt-10 tracking-[0.4em] uppercase">EduNexus Global Academy</p>
               
               <div className="my-16">
                  <p className="text-2xl text-slate-400 font-medium italic mb-8">This is to certify that</p>
                  <h3 className="text-7xl font-serif font-bold text-slate-900 py-4 border-b-4 border-slate-100 inline-block px-24 mb-10">{selectedStudent.name}</h3>
                  <p className="text-xl text-slate-600 max-w-2xl mx-auto leading-relaxed font-medium">
                    has demonstrated outstanding academic prowess and exemplary leadership during the <strong>Academic Session {currentSessionLabel}</strong> in <strong>Grade {selectedStudent.class}</strong>, achieving high distinction in all core assessments.
                  </p>
               </div>

               <div className="mt-24 flex justify-between px-20">
                  <div className="text-center">
                    <div className="w-56 h-12 flex items-center justify-center italic text-indigo-900 font-serif opacity-30 text-xl">Sign: Cord.</div>
                    <div className="w-56 border-b-2 border-slate-300 mb-3"></div>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Section Coordinator</p>
                  </div>
                  <div className="text-center">
                    <div className="w-56 h-12 flex items-center justify-center italic text-indigo-900 font-serif opacity-30 text-xl">Sign: Prin.</div>
                    <div className="w-56 border-b-2 border-slate-300 mb-3"></div>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Institution Principal</p>
                  </div>
               </div>
               <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center">
                  <QrCode size={64} className="text-indigo-100 mb-2" />
                  <p className="text-[9px] font-black text-slate-300 uppercase tracking-tighter">Verified Digital Record ID: EN-CERT-{selectedStudent.id}</p>
               </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-6">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Automated Document Center</h1>
          <p className="text-slate-500">Generate high-security ID cards, admit cards, and verified transcripts.</p>
        </div>
        <div className="flex items-center gap-4 bg-white p-2 rounded-2xl border border-slate-200 shadow-sm">
           <div className="flex items-center gap-3 px-3">
              <User size={18} className="text-slate-400" />
              <span className="text-xs font-black text-slate-400 uppercase">Context</span>
           </div>
           <select 
            value={selectedStudent.id} 
            onChange={(e) => setSelectedStudent(MOCK_STUDENTS.find(s => s.id === e.target.value) || MOCK_STUDENTS[0])}
            className="px-6 py-2 bg-slate-50 border-none rounded-xl text-sm font-black outline-none focus:ring-2 focus:ring-indigo-500/20"
           >
              {MOCK_STUDENTS.map(s => <option key={s.id} value={s.id}>{s.name} ({s.id})</option>)}
           </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {[
          { 
            title: 'Identity Cards', 
            desc: 'Secure ID cards with QR-based digital twin integration.', 
            icon: <CreditCard className="text-indigo-600" size={32} />,
            actions: ['Generate Student ID', 'Generate Staff ID']
          },
          { 
            title: 'Admit Cards', 
            desc: 'Examination hall tickets with timetable integration.', 
            icon: <FileText className="text-rose-600" size={32} />,
            actions: ['Term-1 Admit Card', 'Final Year Admit Card']
          },
          { 
            title: 'Performance Reports', 
            desc: 'Consolidated report cards with analytics & graphs.', 
            icon: <BarChart2 className="text-emerald-600" size={32} />,
            actions: ['Full Report Card', 'Subject-wise Rank']
          },
          { 
            title: 'Official Certs', 
            desc: 'Transfer certificates and merit completion docs.', 
            icon: <GraduationCap className="text-amber-600" size={32} />,
            actions: ['Transfer Cert (TC)', 'Character Certificate']
          }
        ].map((mod, idx) => (
          <div key={idx} className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm flex flex-col gap-6 hover:shadow-2xl hover:scale-[1.02] transition-all duration-300 group">
            <div className="flex items-center justify-between">
              <div className="p-4 bg-slate-50 rounded-2xl group-hover:bg-indigo-50 transition-colors">{mod.icon}</div>
              <div className="w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center"><ShieldCheck className="text-slate-200 group-hover:text-indigo-400" size={18} /></div>
            </div>
            <div>
              <h3 className="text-2xl font-black text-slate-900 mb-2 leading-none">{mod.title}</h3>
              <p className="text-sm text-slate-500 leading-relaxed font-medium">{mod.desc}</p>
            </div>
            <div className="space-y-2 mt-auto">
              {mod.actions.map(act => (
                <button 
                  key={act} 
                  onClick={() => setPreviewType(mod.title)}
                  className="w-full p-4 bg-slate-50 hover:bg-slate-900 hover:text-white rounded-2xl text-xs font-black text-slate-700 flex items-center justify-between transition-all group/btn"
                >
                  {act}
                  <Eye size={18} className="text-slate-400 group-hover/btn:text-indigo-400" />
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="bg-slate-900 p-16 rounded-[4rem] text-white relative overflow-hidden shadow-[0_50px_100px_-20px_rgba(0,0,0,0.5)]">
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-indigo-500/10 rounded-full blur-[120px] -translate-y-48 translate-x-48"></div>
        <div className="flex flex-col lg:flex-row items-center justify-between gap-16">
          <div className="max-w-2xl">
            <div className="bg-indigo-500/20 text-indigo-400 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] inline-block mb-6">Security Module Active</div>
            <h3 className="text-5xl font-black mb-8 leading-[1.1]">Blockchain-Secured Institutional Transcripts</h3>
            <p className="text-slate-400 text-xl leading-relaxed mb-12 font-medium">Protect your school's reputation from document forgery. Our engine generates unique QR signatures for every TC and Report Card, allowing instant verification by universities worldwide.</p>
            <div className="flex flex-wrap gap-6">
              <button 
                onClick={() => { setIsHubActive(!isHubActive); alert(isHubActive ? 'Hub Deactivated' : 'Blockchain Verification Hub Active'); }}
                className={`px-10 py-5 rounded-[2rem] font-black text-sm shadow-2xl transition-all hover:scale-105 uppercase tracking-widest ${isHubActive ? 'bg-emerald-600 text-white shadow-emerald-500/30' : 'bg-indigo-600 text-white shadow-indigo-500/30'}`}
              >
                {isHubActive ? 'Hub Active' : 'Activate Verification Hub'}
              </button>
              <button className="px-10 py-5 bg-white/10 text-white rounded-[2rem] font-black text-sm hover:bg-white/20 transition-all uppercase tracking-widest">Developer API Docs</button>
            </div>
          </div>
          <div className="w-full lg:w-[400px] aspect-[4/5] bg-white/5 border border-white/10 rounded-[3.5rem] p-10 backdrop-blur-xl flex flex-col group hover:border-indigo-500/50 transition-all shadow-2xl">
             <div className="w-full h-1/2 bg-slate-800/50 rounded-[2.5rem] mb-10 flex items-center justify-center border border-white/5 shadow-inner group-hover:bg-slate-800 transition-colors overflow-hidden">
                <Printer size={100} className="text-slate-700 group-hover:text-indigo-400 transition-all group-hover:scale-110" />
             </div>
             <div className="space-y-4">
                <div className="h-4 w-3/4 bg-slate-700/50 rounded-full"></div>
                <div className="h-4 w-1/2 bg-slate-700/30 rounded-full"></div>
                <div className="h-4 w-5/6 bg-slate-700/20 rounded-full"></div>
             </div>
             <div className="mt-auto pt-10 border-t border-white/10 flex justify-between items-center">
                <Download size={32} className="text-indigo-400 hover:text-white cursor-pointer transition-all" />
                <div className="flex items-center gap-3">
                   <span className="text-xs font-black text-emerald-400 uppercase tracking-widest">Encrypted</span>
                   <div className="w-12 h-12 bg-emerald-500/20 rounded-2xl flex items-center justify-center shadow-lg shadow-emerald-500/10"><CheckCircle2 size={24} className="text-emerald-500" /></div>
                </div>
             </div>
          </div>
        </div>
      </div>

      {previewType && <CertificatePreview />}
    </div>
  );
};

export default CertificateManagement;